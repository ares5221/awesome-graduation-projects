package TankWar;

import java.awt.*; 

import java.awt.event.*; 
import java.io.File;
import java.util.*; 

import java.util.List; 
import javax.sound.sampled.*;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;




/*
 * �������ڴ�����Ϸ���� 
 * @author Magci 
 *
 */ 

public class TankClient extends Frame implements ActionListener { 
	public  boolean  ss=false;
	//*****************
	JPanel jp=null;
	//����һ������Ҫ�Ĳ˵�
	MenuBar jmb=null;
	Menu jm1=null;
	//��ʼ��Ϸ
	
	MenuItem jmi1=null;
	MenuItem jmi2=null;
	//*****************
    public static final int WINDOW_Y = 100; 

   
     //������� 
    public static final int WINDOW_WIDTH = 800; 

  
     // ����߶�     
    public static final int WINDOW_HEIGHT = 600; 

 
     // ̹����ʼλ�����Ͻ�X����      
    public static final int Tank_X = 400; 

  
     // ̹����ʼλ�����Ͻ�Y����   
    public static final int Tank_Y = 540; 

          
     // ����ˢ����      
    public static final int REFRESH_RATE = 50; 

    
    //ǽ��ʼ��X���� 
    public static final int WALL_X = 4; 

   
    // ǽ��ʼ��Y���� 
    public static int WALL_Y =  75; 

     

    //�������Ͻ�X���� 
    private int windowX = 0; 

    //�������Ͻ�Y���� 
    private int windowY = 0; 

    //�з�̹�������� 
    private int tankAllNum; 

    //�з�̹��ͬʱ���ֵ�������� 
    private int tankMaxNum; 

    //��ǰ�з�̹������ 
    private int tankNum = 0; 

    //�ҷ�̹�������� 
    private int myTankNum; 

    //����˫�����ͼƬ 
    Image offScreenImage = null; 

    //�ҷ�̹�� 
    Tank myTank = null;     //��ŵз�̹�˵����� 

    List<Tank> enemyTanks = new ArrayList<Tank>(); 

    //����ڵ������� 
    List<Missile> missiles = new ArrayList<Missile>(); 

    //��ű�ը������ 
    List<Explode> explodes = new ArrayList<Explode>(); 

    //��ű�ը������ 
    List<Wall> walls = new ArrayList<Wall>(); 

    //���� 
    Treasure trea = null; 

    //������������� 
    Random rand = new Random(); 

    public static void main(String[] args) { 

        // ����һ������ 
        new TankClient("TankClient", 20, 5, 3); 
        AePlayWave1 apw=new AePlayWave1("E://song.wav");
        apw.start();
    } 

 

    /** 
     * ���ݱ��⣬����̹����������һ������ 
     * @param title ������� 
     * @param tankAllNum �з�̹�������� 
     * @param tankMaxNum �з�̹��ͬʱ���ֵ�������� 
     * @param myTankNum �ҷ�̹�������� 
     */ 
    public TankClient(String title, int tankAllNum, int tankMaxNum, int myTankNum) { 

    	  super(title); 
    	//********************
    	  jp=new JPanel();
    	  jmb=new MenuBar();
    	  jm1=new Menu("��Ϸ(G)");
  		  jmi1=new MenuItem("��ʼ��Ϸ��N��");
  		  jmi1.addActionListener( this);
		  jmi2=new MenuItem("�˳���Ϸ��E��");
		  jmi2.addActionListener(this);
  		  jmb.add(jm1);
  		  jm1.add(jmi1);
  		  jm1.add(jmi2);
  		 this.setMenuBar(jmb);
  		 this.setVisible(true);	
    	//*********************
              
        this.tankAllNum = tankAllNum; 
        this.tankMaxNum = tankMaxNum; 
        this.myTankNum = myTankNum; 
        windowX = Integer.parseInt(PropertyMgr.getProperty("windowX")); 
        windowY = Integer.parseInt(PropertyMgr.getProperty("windowY")); 
        this.setBounds(windowX, windowY, WINDOW_WIDTH, WINDOW_HEIGHT); 
        this.setResizable(false); 
        this.setBackground(Color.RED); 
        //this.setIconImages("images/tankL.gif");
        this.addWindowListener(new WindowAdapter() { 
        	public void windowClosing(WindowEvent e) { 
                setVisible(false); 
                System.exit(0); 
            } 
        }); 
        this.addKeyListener(new KeyMonitor()); 
        this.setVisible(true); 
       
        //����з�̹�� 
        
        	 myTank = new Tank(Tank_X, Tank_Y, 4, true, this); 
        for (int i = 0; i < tankMaxNum; i++) { 
            Tank enemyTank = new Tank(22 + 180 * i, 40, 4, false, this); 
            enemyTanks.add(enemyTank); 
            this.tankNum ++; 
        } 
        
        //����ǽ 
        String sytle = null; 
        for (int i = 0; i < 29; i++) { 
            for (int j = 0; j < 44; j++) { 
                if (i == 0) {                     
                	if (j % 10 == 1 || j % 10 == 2) { 
                        Wall wall = new Wall(WALL_X + j * 18, WALL_Y + i * 18, "stone", this); 
                        walls.add(wall); 
                    } 
                } 
                if (i > 0 && i < 10) { 
                    if (j != 4 && j != 5 && j != 20 && j != 21 && j != 39 && j != 40) { 
                        Wall wall = new Wall(WALL_X + j * 18, WALL_Y + i * 18, "tile", this); 
                        walls.add(wall); 
                    } 
                } 
                if (i >= 10 && i < 12) { 
                    Wall wall = new Wall(WALL_X + j * 18, WALL_Y + i * 18, "grass", this); 
                    walls.add(wall); 
                } 
                if (i >= 12 && i < 14) { 
                    if (j > 10 && j < 34) { 
                        Wall wall = new Wall(WALL_X + j * 18, WALL_Y + i * 18, "river", this); 
                        walls.add(wall); 
                    } else { 
                        Wall wall = new Wall(WALL_X + j * 18, WALL_Y + i * 18, "grass", this); 
                        walls.add(wall); 
                    } 
                } 
                if (i >= 14 && i < 16) { 
                    if (j == 0 || j == 1 || j == 42 || j == 43) { 
                        Wall wall = new Wall(WALL_X + j * 18, WALL_Y + i * 18, "stone", this); 
                        walls.add(wall);                     } 
                } 
                if (i >= 16 && i < 18) { 
                    if (j % 8 < 4) { 
                        Wall wall = new Wall(WALL_X + j * 18, WALL_Y + i * 18, "stone", this); 
                        walls.add(wall); 
                   } 
                } 
                if (i >= 18 && i < 25) { 
                    if (j % 10 < 8) { 
                        Wall wall = new Wall(WALL_X + j * 18, WALL_Y + i * 18, "tile", this); 
                        walls.add(wall); 
                    } 
                } 
                if (i >= 25 && i < 29) { 
                    if (j < 8) { 
                        Wall wall = new Wall(WALL_X + j * 18, WALL_Y + i * 18, "grass", this); 
                        walls.add(wall); 
                    } 
                    if (j > 35) { 
                        Wall wall = new Wall(WALL_X + j * 18, WALL_Y + i * 18, "river", this); 
                        walls.add(wall); 
                    } 
                    if (i > 26 && (j == 16 || j == 17 || j == 28 || j == 29)) { 
                        Wall wall = new Wall(WALL_X + j * 18, WALL_Y + i * 18, "tile", this); 
                        walls.add(wall); 
                    } 
                }           
              } 
        } 
        
        
        // �����ػ��߳� 
        PaintThread pt = new PaintThread(); 
        Thread t = new Thread(pt); 
        t.start(); 
    } 

 

    /* 
     * �ڴ����л�����Ϸ���� 
     */ 

    private void setIconImages(String string) {
		// TODO Auto-generated method stub
		
	}



	public void paint(Graphics g) {
    	
    	if(this.ss==true){
    		if (this == null)  
            return; 
        	Color c = g.getColor(); 
        	g.setColor(Color.RED);
        	
        	if (!myTank.isLive()) { 
            	if (-- this.myTankNum > 0) { 
                	myTank = new Tank(Tank_X, Tank_Y, 4, true, this); 
            	}else { 
            		//this.ss=false;
                	g.drawString("GameOver!", 350, 280); 
                	g.drawString("��F2�����¿�ʼ..", 340, 300); 
                	return; 
           		} 
        	} 
        	if (tankAllNum == 0) { 
        		
            	g.drawString(".:��ϲ����!:.", 350, 280); 
            	g.drawString("��F2�����¿�ʼ..", 340, 300);
            	//this.ss=false;
            	return; 
        	} 
        	g.setColor(c); 
        	this.reinforceTank(); 
        	this.drawMissiles(g); 
        	this.drawMyTank(g); 
        	this.drawEnemyTanks(g); 
        	this.drawWalls(g); 
        	this.drawExplodes(g); 
        	this.drawTreasure(g); 
        	this.drawMessage(g); 
        	//this.ss=false;
    	}
    	System.out.println(this.ss);
    }
   

    /* 
     * ��дupdate����,�Ƚ������ϵ�ͼ�λ���ͼƬ�����ϣ���һ������ʾ 
     */ 

    public void update(Graphics g) { 
        if (offScreenImage == null) { 
            offScreenImage = this.createImage(WINDOW_WIDTH, WINDOW_HEIGHT); 
        } 

        Graphics gImage = offScreenImage.getGraphics(); 
        Color c = gImage.getColor(); 
        gImage.setColor(Color.BLACK); 
        gImage.fillRect(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT); 
        gImage.setColor(c); 
        //g.drawString("GameOver!", 350, 280);
        paint(gImage); 
        g.drawImage(offScreenImage, 0, 0, null); 
    }  

    /* 
     * ���߳��ػ���ÿ��һ��ʱ���ػ����� 
     * @author Magci 
     * 
     */ 

    private class PaintThread implements Runnable { 

        /*
         * ÿ��REFRESH_RATE�����ػ�һ�δ��� 
         */ 
        public void run() { 
            while (true) { 
                repaint(); 
                try { 
                    Thread.sleep(REFRESH_RATE); 
                } catch (InterruptedException e) { 
                    e.printStackTrace(); 
                } 
            } 
        } 
    } 

 

    /* 
     * ���������¼��������������̹���ƶ� 
     * @author Magci 
     * 
     */    
    private class KeyMonitor extends KeyAdapter { 

        /* 
         * ���������������¼� 
         */ 

        public void keyPressed(KeyEvent e) { 

            myTank.keyPressed(e); 

        } 

        /* 
         * �����������ɿ��¼� 
         */ 

        public void keyReleased(KeyEvent e) { 

           myTank.keyReleased(e); 

        } 
    } 

    /* 
     * �з�̹����Ԯ 
     */ 

    public void reinforceTank() { 
        if (tankNum < tankMaxNum && tankAllNum > tankNum) { 
            int i = rand.nextInt(10); 
            Tank enemyTank = new Tank(50 + 150 * i, 40, 4, false, this); 
            if (!enemyTank.collidesWithTank(myTank, true) && !enemyTank.collidesWithTanks(enemyTanks, true)) { 
                enemyTanks.add(enemyTank); 
                this.tankNum ++; 
            }     
        } 
    } 

 

    /** 
     * ����ǽ 
     * @param g Graphics���� 
     */ 

    public void drawWalls(Graphics g) { 
        for (int i = 0; i < walls.size(); i++) { 
            Wall wall = walls.get(i); 
            wall.draw(g); 
        } 
    } 

     

    /* 
     * ���ҷ�̹�� 
     * @param g Graphics���� 
     */ 

    public void drawMyTank(Graphics g) { 
        if (myTank != null) { 
            myTank.draw(g); 
            if (trea != null) 
            myTank.eatTreasure(trea); 
        } 
    } 

     

    /* 
     * ���з�̹��      * @param g Graphics���� 
     */ 

    public void drawEnemyTanks(Graphics g) { 
        for (int i = 0; i < enemyTanks.size(); i++) { 
            	Tank enemyTank = enemyTanks.get(i); 
                enemyTank.draw(g); 
                enemyTank.collidesWithTank(myTank, false); 
                enemyTank.collidesWithTanks(enemyTanks, false); 
        } 
    } 

     

    /* 
     * ���ڵ� 
     * @param g Graphics���� 
     */ 

    public void drawMissiles(Graphics g) { 
        for (int i = 0; i < missiles.size(); i++) { 
            Missile m = missiles.get(i); 
            if (m != null) { 
                m.draw(g); 
                m.hitTanks(enemyTanks); 
                m.hitTank(myTank); 
                m.hitMissiles(missiles); 
            } 
        } 
    } 

     

    /*     
     * ���뱬ը  
     * @param g Graphics���� 
     */ 
    public void drawExplodes(Graphics g) { 
        for (int i=0; i < explodes.size(); i++) { 
            Explode e = explodes.get(i); 
            e.draw(g); 
        } 
    } 

     

    /* 
     * ���ֱ��� 
     * @param g Graphics���� 
     */ 

    public void drawTreasure(Graphics g) { 
        if (rand.nextInt(100) == 0) 
            trea = null; 
        if (rand.nextInt(300) == 0) { 
            int x = rand.nextInt(785); 
            int y = rand.nextInt(555); 
            trea = new Treasure(x, y, this); 
        } 
        if (trea != null) { 
            trea.collidesWithWalls(walls); 
            trea.draw(g); 
        } 
    } 

     /* 
     * ��ӡ��Ϣ 
     * @param g Graphics���� 
     */ 

    public void drawMessage(Graphics g) { 
        Color c = g.getColor(); 
        g.setColor(Color.YELLOW); 
        g.drawString("EnemyTanks Count: " + enemyTanks.size(), 10, 50); 
        g.drawString("All EnemyTanks Count: " + this.tankAllNum, 10, 70); 
        g.drawString("MyTank Count: " + this.myTankNum, 10, 90); 
        g.drawString("MyTank Life: " + myTank.getLife(), 10, 110); 
        g.setColor(c); 
    } 

 

    /* 
     * ���صз�̹�������� 
     * @return �з�̹�������� 
     */ 

    public int getTankAllNum() { 

        return tankAllNum; 

    } 


    /** 
     * ���õз�̹�������� 
     * @param tankAllNum �з�̹�������� 
     */ 

    public void setTankAllNum(int tankAllNum) {        
    	this.tankAllNum = tankAllNum; 

    } 

 

    /** 
     * ���ص�ǰ�з�̹������ 
     * @return ���ص�ǰ�з�̹������ 
     */ 

    public int getTankNum() { 

        return tankNum; 

    } 


    /** 
     * ���õ�ǰ�з�̹������ 
     * @param tankNum ��ǰ�з�̹������ 
     */ 

    public void setTankNum(int tankNum) { 

        this.tankNum = tankNum; 

    }



	public void actionPerformed(ActionEvent e) {
		
		// TODO Auto-generated method stub
		if(e.getActionCommand().equals("��ʼ��Ϸ��N��")){
			this.ss=true;
			
		}
		if(e.getActionCommand().equals("�˳���Ϸ��E��")){
			//dispose();
			 System.exit(0); 
		}
		
	} 

     

} 

 