package TankWar;

import java.awt.*; 



/** 
 * �������ڴ�����ը 
 * @author Magci 
 * 
 */ 

public class Explode { 

 

    private int x, y; 
    private int step = 0; 
    private boolean live = true; 
    private int radius = 10; 
    TankClient tc; 
    private static Toolkit tk = Toolkit.getDefaultToolkit(); 
    private static Image[] imgs = { 

        tk.getImage(Explode.class.getClassLoader().getResource("images/0.gif")), 
        tk.getImage(Explode.class.getClassLoader().getResource("images/1.gif")), 
        tk.getImage(Explode.class.getClassLoader().getResource("images/2.gif")), 
        tk.getImage(Explode.class.getClassLoader().getResource("images/3.gif")), 
        tk.getImage(Explode.class.getClassLoader().getResource("images/4.gif")), 
        tk.getImage(Explode.class.getClassLoader().getResource("images/5.gif"))     }; 

    private boolean init = false; 

 

    /** 
     * ������ײλ�ô�����ը 
     * @param x ��ײλ��X���� 
     * @param y ��ײλ��Y���� 
     * @param tc ��ǰ���� 
     */ 

    public Explode(int x, int y, TankClient tc) { 

        this.x = x; 
        this.y = y; 
        this.tc = tc; 

    } 

 

    /** 
     * �ڴ����ϻ�����ը 
     * @param g Graphics���� 
     */ 

    public void draw(Graphics g) { 

        if (!init) { 
            for(int i = 0; i < imgs.length; i++) 
                g.drawImage(imgs[i], -100, -100, null); 
            init = true; 
        } 
        if (!this.live) { 
            tc.explodes.remove(this); 
            return;         
         } 
        if (step > 5) { 
            this.live = false; 
            step = 0; 
            return; 
        } 

        int eW = imgs[step].getWidth(null); 
        int eH = imgs[step].getHeight(null); 
        int midX = x - eW / 2; 
        int midY = y - eH / 2; 
        g.drawImage(imgs[step], midX, midY, null); 
        step ++; 

    } 

} 

 