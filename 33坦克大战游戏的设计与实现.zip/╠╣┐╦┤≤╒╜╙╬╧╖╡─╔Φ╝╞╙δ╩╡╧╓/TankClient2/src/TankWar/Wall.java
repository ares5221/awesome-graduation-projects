package TankWar;




import java.awt.*; 
import java.util.List; 
import java.util.*; 
	 

/** 
 * �������ڴ���ǽ 
 * @author Magci 
 **/ 

public class Wall { 

	    /** 
	     * ǽ�Ŀ��� 
	     */ 
	   public static final int WIDTH = 15; 
	    /** 
	     * ǽ�ĸ߶� 
	     */ 
	   public static final int HEIGHT = 15; 
 
	    private int x, y; 
	    private String style; 
	    private TankClient tc; 
	    private boolean live = true; 
	    private boolean init = false;
	    private int step = 0; 
	    private String wallStyle = null; 
	    private static Toolkit tk = Toolkit.getDefaultToolkit(); 
	    private static Image[] wallImgs; 
	    private static Map<String, Image> imgs = new HashMap<String, Image>(); 
	     
	    static { 

	        wallImgs = new Image[] { 

	                tk.getImage(Wall.class.getClassLoader().getResource("images/stone.gif")), 
	                tk.getImage(Wall.class.getClassLoader().getResource("images/tile.gif")), 
	                tk.getImage(Wall.class.getClassLoader().getResource("images/grass.gif")),                
	                tk.getImage(Wall.class.getClassLoader().getResource("images/river1.gif")), 
                    tk.getImage(Wall.class.getClassLoader().getResource("images/river2.gif")) 
	        	
	        }; 

	         

	        imgs.put("stone", wallImgs[0]); 
	        imgs.put("tile", wallImgs[1]); 
	        imgs.put("grass", wallImgs[2]); 
	        imgs.put("river1", wallImgs[3]); 
	        imgs.put("river2", wallImgs[4]); 

	                 

	    } 

	 

	    /** 
	     * ����ǽ���Ͻ����ꡢ���͡���ǰ���崴��ǽ 
	     * @param x ǽ���Ͻ�X���� 
	     * @param y ǽ���Ͻ�Y���� 
	     * @param style ǽ������ 
	     * @param tc ��ǰ���� 
	     */ 

	    public Wall(int x, int y, String style, TankClient tc) { 

	        this.x = x; 
	        this.y = y; 
	        this.style = style; 
	        this.tc = tc; 

	    } 

	     

	    /** 
	     * �ڴ����л���ǽ      * @param g Graphics���� 
	     */ 

	    public void draw(Graphics g) { 
	        if (!this.live) { 
	           tc.walls.remove(this); 
	           return; 
	        } 
	        if (!init) { 
	            for(int i = 0; i < wallImgs.length; i++) 
	                g.drawImage(wallImgs[i], -100, -100, null); 
	            init = true; 
	        } 

	        if ("river".equals(style)) { 
	            if (step == 10) 
	                step = 0; 
	            if (step < 5) { 
	                wallStyle = "river1"; 
	            } else { 
	                wallStyle = "river2"; 
	            } 
	            step ++; 
	        } else { 
	            wallStyle = style; 
	        } 
	        g.drawImage(imgs.get(wallStyle), x, y, null); 
	        if ("stone".equals(style)) { 
	            this.coolidesWithMissiles(tc.missiles); 
	            this.collidesWithTank(tc.myTank);             
	            this.collidesWithTanks(tc.enemyTanks); 
	        } 
	        else if ("tile".equals(style)) { 
	            this.coolidesWithMissiles(tc.missiles); 
	            this.collidesWithTank(tc.myTank); 
	            this.collidesWithTanks(tc.enemyTanks); 
	        } 
	        else if ("river".equals(style)) { 
	            this.collidesWithTank(tc.myTank); 
	            this.collidesWithTanks(tc.enemyTanks); 
	        } 

	         

	    } 

	 

	    /** 
	     * ����ǽ�ľ�����ײ���� 
	     * @return ǽ�ľ�����ײ���� 
	     */ 

	    public Rectangle getRect() { 
	        Rectangle rect = new Rectangle(x, y, this.WIDTH, this.HEIGHT); 
	        return rect; 
	    } 

	 

	    /** 
	     * �ж�ǽ���ڵ����� 
	     * @param missile �ڵ� 
	     * @return ǽ���ڵ����� 
	     */     
	    public boolean collidesWithMissile(Missile missile) { 
	        if (this.live && missile.isLive() && this.getRect().intersects(missile.getRect())) { 
	            if ("tile".equals(style)) { 
	                this.live = false; 
	                Explode e = new Explode(x, y, tc); 
	                tc.explodes.add(e); 
	            } 
	            missile.setLive(false); 
	            return true; 
	        } 
	        return false; 
	    } 

	     

	    /** 
	     * �����ж����е��ڵ��Ƿ����ǽ 
	     * @param missiles ����ڵ������� 
	     * @return �ڵ��Ƿ����ǽ 
	     */ 

	    public boolean coolidesWithMissiles(List<Missile> missiles) { 
	        for (int i = 0; i < missiles.size(); i++) { 
	            Missile missile = missiles.get(i); 
	            if (collidesWithMissile(missile)) 
	               return true; 
	        } 
	        return false; 
	    } 

	     

	    /**     
	     * 
	     *   �ж�ǽ�Ƿ񱻸�̹������ 
	     * @param tank ̹�� 
	     * @return ǽ�Ƿ񱻸�̹������ 
	     */ 

	    public boolean collidesWithTank(Tank tank) { 
	        if (this.live && tank.isLive() && this.getRect().intersects(tank.getRect())) { 
	           tank.stay(); 
	            return true; 
	        } 
	        return false; 
	    } 

	     

	    /** 
	     * �����ж����е�ǽ�Ƿ񱻸�̹������ 
	     * @param tanks ���̹�˵����� 
	     * @return ǽ�Ƿ񱻸�̹������ 
	     */ 

	    public boolean collidesWithTanks(List<Tank> tanks) { 
	        for (int i = 0; i < tanks.size(); i++) { 
	            Tank tank = tanks.get(i); 
	            if (collidesWithTank(tank)) 
	               return true; 
	        } 
	        return false; 
	    } 

	 

	    public String getStyle() { 
	       return style;     
	    } 
	} 


