/*
Navicat MySQL Data Transfer

Source Server         : ares
Source Server Version : 50132
Source Host           : localhost:3306
Source Database       : product

Target Server Type    : MYSQL
Target Server Version : 50132
File Encoding         : 65001

Date: 2015-04-20 17:20:45
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `product`
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `ProductId` int(11) NOT NULL AUTO_INCREMENT,
  `ProductName` varchar(100) NOT NULL,
  `ProductNo` varchar(100) NOT NULL,
  PRIMARY KEY (`ProductId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES ('1', '洗发水', 'utf-8');
INSERT INTO `product` VALUES ('2', '沐浴液', '12314444');
INSERT INTO `product` VALUES ('6', '护发素', '45376376');

-- ----------------------------
-- Table structure for `sellnote`
-- ----------------------------
DROP TABLE IF EXISTS `sellnote`;
CREATE TABLE `sellnote` (
  `SnId` int(11) NOT NULL AUTO_INCREMENT,
  `OrderFormNo` varchar(100) NOT NULL,
  `ProductId` int(11) NOT NULL,
  `Pnumber` int(11) NOT NULL,
  `PactSum` varchar(10) NOT NULL,
  `SignDate` date NOT NULL,
  PRIMARY KEY (`SnId`),
  KEY `ProductId` (`ProductId`),
  CONSTRAINT `sellnote_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `product` (`ProductId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sellnote
-- ----------------------------
INSERT INTO `sellnote` VALUES ('3', '155555', '2', '200', '99999', '2015-04-14');
INSERT INTO `sellnote` VALUES ('4', '12341', '1', '222', '3323223', '2015-04-13');
INSERT INTO `sellnote` VALUES ('5', '1234132', '2', '3434', '2342343', '2015-02-10');
INSERT INTO `sellnote` VALUES ('6', '3454236', '6', '3413', '2314', '2015-04-07');

-- ----------------------------
-- Table structure for `users`
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `UserId` int(8) NOT NULL,
  `UserName` varchar(30) DEFAULT NULL,
  `Account` varchar(30) DEFAULT NULL,
  `Password` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', '管理员', 'admin', '111111');
