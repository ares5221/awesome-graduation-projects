package com.product.product;

public class Product extends AbstractProduct implements java.io.Serializable{

	public Product(){}

}
