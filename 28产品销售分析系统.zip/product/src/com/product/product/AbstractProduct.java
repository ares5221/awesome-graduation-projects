package com.product.product;

public class AbstractProduct implements java.io.Serializable{
	
	private Integer productId;
	private String  productName;
	private String productNo;
	
	public AbstractProduct(){}

	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductNo() {
		return productNo;
	}
	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}

}
