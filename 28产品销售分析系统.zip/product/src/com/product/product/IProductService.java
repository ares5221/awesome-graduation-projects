package com.product.product;

import java.util.List;


public interface IProductService {
	public void 	addProducts(Product product)throws Exception;
	public void 	updateProducts(Product product)throws Exception;
	public List 	getProductList()throws Exception;
	public Product  getProductById(String productId)throws Exception;
	public void 	delProduct(String productId)throws Exception;
}
