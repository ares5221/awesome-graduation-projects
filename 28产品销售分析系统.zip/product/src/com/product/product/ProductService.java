package com.product.product;

import java.util.List;


public class ProductService implements IProductService {
	private IProductDao productDao;
	
	public IProductDao getProductDao() {
		return productDao;
	}
	//	Spring通过下面的setter注入DAO组件
	public void setProductDao(IProductDao productDao) {
		this.productDao = productDao;
	}

	public ProductService(){}
	//处理产品添加功能
	public void addProducts(Product product)throws Exception{
		productDao.insertProduct(product);
	}
	//处理产品修改功能
	public void updateProducts(Product product)throws Exception{
		productDao.updateProduct(product);
	}
	//获取产品列表
	public List getProductList()throws Exception{
		return productDao.getProductList();
	}
	//根据ID获取产品对象
	public Product  getProductById(String productId)throws Exception{
		return productDao.getProductById(productId);
	}
	//删除特定产品记录
	public void delProduct(String productId)throws Exception{
		productDao.delProduct(productId);
	}
}
