package com.product.product;

import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;


public class ProductDao extends SqlMapClientDaoSupport implements IProductDao {
	//实现产品信息插入操作
	public void insertProduct(Product product){
		this.getSqlMapClientTemplate().insert("insertProduct", product);
	}
	//实现产品信息修改操作
	public void updateProduct(Product product){
		this.getSqlMapClientTemplate().update("updateProduct",product);
	}
	//获取产品信息列表
	public List getProductList(){
		return this.getSqlMapClientTemplate().queryForList("getProductList");
	}
	//通过ID获取产品对象
	public Product getProductById(String productId){
		Product product  =(Product) this.getSqlMapClientTemplate().queryForObject("getProductById",productId);
		return product;
	}
	//根据ID删除产品记录
	public void delProduct(String productId){
		this.getSqlMapClientTemplate().delete("delProduct",productId);
	}
}
