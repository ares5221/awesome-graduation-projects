package com.product.product;

import java.util.List;


public interface IProductDao {
	public void insertProduct(Product product);
	public void updateProduct(Product product);
	public List getProductList();
	public Product getProductById(String productId);
	public void delProduct(String productId);
}
