package com.product.sellnote;

import java.util.Date;

import com.product.product.Product;

public class AbstractSellNote implements java.io.Serializable{
	
	private Integer snId;//ID
	private String  orderFormNo;//订单编号
	private Integer productId;//产品ID
	private Integer pnumber;//产品数量
	private String  pactSum;//合同金额
	private Date    signDate;//签单日期
    private Product product;//产品对象
	
    
	public AbstractSellNote(){}

	public String getOrderFormNo() {
		return orderFormNo;
	}
	public void setOrderFormNo(String orderFormNo) {
		this.orderFormNo = orderFormNo;
	}
	public String getPactSum() {
		return pactSum;
	}
	public void setPactSum(String pactSum) {
		this.pactSum = pactSum;
	}
	public Integer getPnumber() {
		return pnumber;
	}
	public void setPnumber(Integer pnumber) {
		this.pnumber = pnumber;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public Date getSignDate() {
		return signDate;
	}
	public void setSignDate(Date signDate) {
		this.signDate = signDate;
	}
	public Integer getSnId() {
		return snId;
	}
	public void setSnId(Integer snId) {
		this.snId = snId;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	
}
