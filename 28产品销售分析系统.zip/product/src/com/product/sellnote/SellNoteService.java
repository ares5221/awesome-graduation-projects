package com.product.sellnote;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class SellNoteService implements ISellNoteService {
	private ISellNoteDao sellNoteDao;

	public ISellNoteDao getSellNoteDao() {
		return sellNoteDao;
	}
	//Spring通过下面的setter注入DAO组件
	public void setSellNoteDao(ISellNoteDao sellNoteDao) {
		this.sellNoteDao = sellNoteDao;
	}

	public SellNoteService(){}
	//处理添加订单记录业务
	public void addSellNotes(SellNote sellNote)throws Exception{
		sellNoteDao.insertSellNote(sellNote);
	}
	//处理订单修改业务
	public void updateSellNotes(SellNote sellNote)throws Exception{
		sellNoteDao.updateSellNote(sellNote);
	}
	//处理获取订单列表业务
	public List getSellNoteList()throws Exception{
		return sellNoteDao.getSellNoteList();
	}
	//根据ID获取订单信息
	public SellNote  getSellNoteById(String snId)throws Exception{
		return sellNoteDao.getSellNoteById(snId);
	}
	//处理订单删除业务
	public void delSellNote(String snId)throws Exception{
		sellNoteDao.delSellNote(snId);
	}
	//处理获取产品销量业务
	public List  getProductNameSumPnumber()throws Exception{
		return sellNoteDao.getProductNameSumPnumber();
	}
	//处理获取产品销售额业务
	public List  getProductNameSumPactSum()	throws Exception{
		return sellNoteDao.getProductNameSumPactSum();
	}
}
