package com.product.sellnote;


public class SellNote extends AbstractSellNote implements java.io.Serializable{
	//产品名称
    private String  productName;
    //产品销量
    private String  sumPnumber;
    //产品销售额
    private String  sumPactSum;
    
	public SellNote(){}

	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getSumPnumber() {
		return sumPnumber;
	}
	public void setSumPnumber(String sumPnumber) {
		this.sumPnumber = sumPnumber;
	}
	public String getSumPactSum() {
		return sumPactSum;
	}
	public void setSumPactSum(String sumPactSum) {
		this.sumPactSum = sumPactSum;
	}

}
