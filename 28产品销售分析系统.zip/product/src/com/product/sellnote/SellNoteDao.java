package com.product.sellnote;

import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;


public class SellNoteDao extends SqlMapClientDaoSupport implements ISellNoteDao {
	//插入订单记录
	public void insertSellNote(SellNote sellNote){
		this.getSqlMapClientTemplate().insert("insertSellNote", sellNote);
	}
	//修改订单记录
	public void updateSellNote(SellNote sellNote){
		this.getSqlMapClientTemplate().update("updateSellNote",sellNote);
	}
	//获取订单列表
	public List getSellNoteList(){
		return this.getSqlMapClientTemplate().queryForList("getSellNoteList");
	}
	//根据ID获取订单记录
	public SellNote getSellNoteById(String snId){
		SellNote sellNote  =(SellNote) this.getSqlMapClientTemplate().queryForObject("getSellNoteById",snId);
		return sellNote;
	}
	//删除订单记录
	public void delSellNote(String snId){
		this.getSqlMapClientTemplate().delete("delSellNote",snId);
	}
	//获取每种产品的相应销量
	public List getProductNameSumPnumber(){
		return this.getSqlMapClientTemplate().queryForList("getProductNameSumPnumber");
	}
	//获取每种产品的相应销售额
	public List getProductNameSumPactSum(){
		return this.getSqlMapClientTemplate().queryForList("getProductNameSumPactSum");
	}
}
