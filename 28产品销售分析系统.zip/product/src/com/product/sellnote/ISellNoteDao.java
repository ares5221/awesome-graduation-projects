package com.product.sellnote;

import java.util.List;


public interface ISellNoteDao {
	public void insertSellNote(SellNote sellNote);
	public void updateSellNote(SellNote sellNote);
	public List getSellNoteList();
	public SellNote getSellNoteById(String snId);
	public void delSellNote(String snId);
	public List getProductNameSumPnumber();
	public List getProductNameSumPactSum();
}
