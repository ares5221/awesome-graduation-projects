package com.product.sellnote;

import java.util.List;


public interface ISellNoteService {
	public void 	 addSellNotes(SellNote sellNote)	throws Exception;
	public void 	 updateSellNotes(SellNote sellNote)	throws Exception;
	public List 	 getSellNoteList()					throws Exception;
	public SellNote  getSellNoteById(String snId)		throws Exception;
	public void 	 delSellNote(String snId)			throws Exception;
	public List      getProductNameSumPnumber()			throws Exception;
	public List      getProductNameSumPactSum()			throws Exception;
}
