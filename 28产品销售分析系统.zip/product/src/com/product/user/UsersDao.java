package com.product.user;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class UsersDao extends SqlMapClientDaoSupport implements IUsersDao {
	public Users getUserByAccount(String account){
		Users user  =(Users) this.getSqlMapClientTemplate().queryForObject("getUserByAccount",account);
		return user;
	}

}
