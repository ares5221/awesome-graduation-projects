package com.product.user;

import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



public class UsersService implements IUsersService {
	private static Log log = LogFactory.getLog(UsersService.class);
	private IUsersDao usersdao;
	public void setUsersdao(IUsersDao usersdao) {
		this.usersdao = usersdao;
	}

	public IUsersDao getUsersdao() {
		return usersdao;
	}
	public UsersService(){}
  
	
	public Users  getUserByAccount(String account)	throws Exception{
		return (Users)usersdao.getUserByAccount(account);
	}
}
