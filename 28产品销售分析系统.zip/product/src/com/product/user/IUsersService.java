package com.product.user;


public interface IUsersService {
	public Users  getUserByAccount(String account)		throws Exception;
}
