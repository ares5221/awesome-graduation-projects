package com.product.user;



public interface IUsersDao {
	public Users getUserByAccount(String account);
}
