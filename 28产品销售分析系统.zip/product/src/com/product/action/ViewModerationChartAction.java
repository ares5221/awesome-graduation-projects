package com.product.action;

import org.apache.commons.lang.math.RandomUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.chart.ChartFactory;

public class ViewModerationChartAction extends  AbstractAction {

	private JFreeChart chart;

	public String viewChart() throws Exception {
		// chart creation logic...
		XYSeries dataSeries = new XYSeries(new Integer(1)); //pass a key for this serie
		for (int i = 0; i <= 100; i++) {
			dataSeries.add(i, RandomUtils.nextInt());
		}
		XYSeriesCollection xyDataset = new XYSeriesCollection(dataSeries);

		ValueAxis xAxis = new NumberAxis("Raw Marks");
		ValueAxis yAxis = new NumberAxis("Moderated Marks");

		// set my chart variable
		chart =
			new JFreeChart(
				"Moderation Function",
				JFreeChart.DEFAULT_TITLE_FONT,
				new XYPlot(
					xyDataset,
					xAxis,
					yAxis,
					new StandardXYItemRenderer(StandardXYItemRenderer.LINES)),
				false);
		chart.setBackgroundPaint(java.awt.Color.white);

		return super.SUCCESS;
	}
	public String createChart1()throws Exception{
		chart = ChartFactory.createPieChart("产品销售统计图", getDataSet(),true, false, false);
		
		return super.SUCCESS;
	}
	public String createChart2()throws Exception{
		chart = ChartFactory.createBarChart3D("产品销售统计柱图", "产品", "销量", getDataSet2(), PlotOrientation.VERTICAL, false, false, false);
		
		return super.SUCCESS;
	}
	public DefaultPieDataset getDataSet(){
		DefaultPieDataset dataset = new DefaultPieDataset();
		dataset.setValue("spring2", 47000);
		dataset.setValue("J2EE", 38000);
		dataset.setValue("Ajax", 31000);
		dataset.setValue("JavaScript", 29000);
		dataset.setValue("Struts2", 52000);
		
		return dataset;
	}
	public CategoryDataset getDataSet2(){
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		dataset.addValue(47000, "", "Spring2");
		dataset.addValue(38000, "", "J2EE");
		dataset.addValue(31000, "", "Ajax");
		dataset.addValue(29000, "", "JavaScript");
		dataset.addValue(52000, "", "Struts2");
		
		return dataset;
	}
	public JFreeChart getChart() {
		return chart;
	}

}

