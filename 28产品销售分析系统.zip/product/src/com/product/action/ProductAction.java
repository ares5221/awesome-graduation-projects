package com.product.action;


import java.util.Collection;

import com.product.product.IProductService;
import com.product.product.Product;


public class ProductAction extends AbstractAction {

	private IProductService productservice;
	
	public 	Product product;
	private String productId;
	
	protected Collection availableItems;
	//获取产品列表信息
	public String list() throws Exception {
		availableItems = productservice.getProductList();
		return SUCCESS;		 
	}
	//编辑产品信息
	public String edit() throws Exception {
		product = productservice.getProductById(productId);
	    return SUCCESS;
	}
	//保存或修改产品信息
	public String save() throws Exception {
		if(this.getProduct().getProductId()==null)
			productservice.addProducts(this.getProduct());
		else
			productservice.updateProducts(this.getProduct());
	    return SUCCESS;
	}
	//删除产品信息
	public String delete() throws Exception{
		productservice.delProduct(this.getProductId());
		return super.SUCCESS;
	}
	
	
	
	public Collection getAvailableItems() {
		return availableItems;
	}
	public void setAvailableItems(Collection availableItems) {
		this.availableItems = availableItems;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public IProductService getProductservice() {
		return productservice;
	}
	public void setProductservice(IProductService productservice) {
		this.productservice = productservice;
	}

}
