package com.product.action;


import java.util.Collection;
import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import com.product.product.IProductService;
import com.product.sellnote.ISellNoteService;
import com.product.sellnote.SellNote;


public class SellNoteAction extends AbstractAction {

	private ISellNoteService sellNoteservice;
	private IProductService productservice;
	
	public 	SellNote sellNote;
	private String snId;
	private List productList;
	//图形结果
	private JFreeChart chart;
	//图形URL
	private String chartUrl;
	//1:产品销量统计圆柱图	2:产品销量统计圆饼图 3:产品营业额统计折线图
	private String chartNum;
	
	protected Collection availableItems;
	//获取订单列表
	public String list() throws Exception {
		availableItems = sellNoteservice.getSellNoteList();
        
		return SUCCESS;		 
	}
	//编辑订单信息
	public String edit() throws Exception {
		productList = productservice.getProductList();
		sellNote = sellNoteservice.getSellNoteById(snId);
	    return SUCCESS;
	}
	//保存一份订单
	public String save() throws Exception {
		if(this.getSellNote().getSnId()==null)
			sellNoteservice.addSellNotes(this.getSellNote());
		else
			sellNoteservice.updateSellNotes(this.getSellNote());
	    return SUCCESS;
	}
	//删除订单
	public String delete() throws Exception{
		sellNoteservice.delSellNote(this.getSnId());
		return super.SUCCESS;
	}
	//生成产品销量圆柱图
	public String getYuanZhuChart() throws Exception{
		chart = ChartFactory.createBarChart3D("产品销量统计圆柱图", "产品", "销量", getDataSetTwo(), PlotOrientation.VERTICAL, false, false, false);
		return super.SUCCESS;
	}
	//获取圆柱图数据对象
	public DefaultPieDataset getDataSetOne()throws Exception{
		DefaultPieDataset dataset = new DefaultPieDataset();
		List list = sellNoteservice.getProductNameSumPnumber();
		for(int i=0;i<list.size();i++){
			SellNote sellNote = (SellNote)list.get(i);
			dataset.setValue(sellNote.getProductName(), new Integer(sellNote.getSumPnumber()));
		}
		return dataset;
	}
	//生成产品销量圆饼图
	public String getYuanBingChart() throws Exception{
		chart = ChartFactory.createPieChart("产品销量统计圆饼图", getDataSetOne(),true, false, false);
		return super.SUCCESS;
	}
	//获取圆饼图数据对象
	public CategoryDataset getDataSetTwo() throws Exception{
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		List list = sellNoteservice.getProductNameSumPnumber();
		for(int i=0;i<list.size();i++){
			SellNote sellNote = (SellNote)list.get(i);
			dataset.addValue( new Integer(sellNote.getSumPnumber()),"",sellNote.getProductName());
		}
		return dataset;
	}
	//生成产品营业额折线图
	public String getZheXianChart() throws Exception{
		chart = ChartFactory.createLineChart3D("产品营业额统计折线图", "产品", "金额", getDataSetThree(), PlotOrientation.VERTICAL, false, false, false);
		return super.SUCCESS;
	}
	//	获取折线图数据对象
	public CategoryDataset getDataSetThree() throws Exception{
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		List list = sellNoteservice.getProductNameSumPactSum();
		for(int i=0;i<list.size();i++){
			SellNote sellNote = (SellNote)list.get(i);
			dataset.addValue( new Double(sellNote.getSumPactSum()),"",sellNote.getProductName());
		}
		return dataset;
	}
	//选择产品销售分析图
	public String selectChart() throws Exception{
		if(chartNum.equals("1"))
			this.setChartUrl("/product/sellNote/getYuanZhuChart.kemp");
		if(chartNum.equals("2"))
			this.setChartUrl("/product/sellNote/getYuanBingChart.kemp");
		if(chartNum.equals("3"))
			this.setChartUrl("/product/sellNote/getZheXianChart.kemp");
		return super.SUCCESS;
	}
	
	
	public Collection getAvailableItems() {
		return availableItems;
	}
	public void setAvailableItems(Collection availableItems) {
		this.availableItems = availableItems;
	}
	public SellNote getSellNote() {
		return sellNote;
	}
	public void setSellNote(SellNote sellNote) {
		this.sellNote = sellNote;
	}
	public ISellNoteService getSellNoteservice() {
		return sellNoteservice;
	}
	public void setSellNoteservice(ISellNoteService sellNoteservice) {
		this.sellNoteservice = sellNoteservice;
	}
	public String getSnId() {
		return snId;
	}
	public void setSnId(String snId) {
		this.snId = snId;
	}
	public IProductService getProductservice() {
		return productservice;
	}
	public void setProductservice(IProductService productservice) {
		this.productservice = productservice;
	}
	public List getProductList() {
		return productList;
	}
	public void setProductList(List productList) {
		this.productList = productList;
	}
	public JFreeChart getChart() {
		return chart;
	}
	public void setChart(JFreeChart chart) {
		this.chart = chart;
	}
	public String getChartNum() {
		return chartNum;
	}
	public void setChartNum(String chartNum) {
		this.chartNum = chartNum;
	}
	public String getChartUrl() {
		return chartUrl;
	}
	public void setChartUrl(String chartUrl) {
		this.chartUrl = chartUrl;
	}
}
