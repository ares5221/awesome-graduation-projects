package com.product.action;

import com.opensymphony.xwork2.ActionSupport;

public class AbstractAction extends ActionSupport {
	
	protected String where = "";
	
	
	public String getWhere() {
		return where;
	}

	public void setWhere(String where) {
		this.where = where;
	}

}
