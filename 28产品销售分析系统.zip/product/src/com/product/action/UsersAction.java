package com.product.action;

import com.product.user.IUsersService;
import com.product.user.Users;

public class UsersAction extends AbstractAction{
	
	private IUsersService usersService;
	private Users users;
	
	public String login() throws Exception{
		//从数据库获取用户密码
		String password = ((Users)usersService.getUserByAccount(users.getAccount())).getPassword();
		//进行密码匹配
		if(password.equals(users.getPassword()))
			return super.SUCCESS;
		else{
			this.addFieldError("login.error", "<font color=red>账号或密码有误！请重试！</font>");
			return "input";
		}
	}
	
	
	public IUsersService getUsersService() {
		return usersService;
	}
	public void setUsersService(IUsersService usersService) {
		this.usersService = usersService;
	}
	public Users getUsers() {
		return users;
	}
	public void setUsers(Users users) {
		this.users = users;
	}

}
