
function y2k(number)
{
  return (number < 1000) ? number + 1900 : number;
}

function getdate()
{
  var now = new Date();
  var dd = now.getDate() , mt = now.getMonth() + 1 , yy = y2k(now.getYear()) , weekVal = now.getDay();
  var msg="";
  if (weekVal==0)
     msg="������";
  else if (weekVal==1)
     msg="����һ";
  else if (weekVal==2)
     msg="���ڶ�";
  else if (weekVal==3)
     msg="������";
  else if (weekVal==4)
     msg="������";
  else if (weekVal==5)
     msg="������";
  else if (weekVal==6)
     msg="������";
  document.write(yy+"��"+mt+"��"+dd+"��"+"&nbsp;&nbsp;&nbsp;"+msg);
}
function getdatestring()
{
  var retvalue="";
  var now = new Date();
  var dd = now.getDate() , mt = now.getMonth() + 1 , yy = y2k(now.getYear()) , weekVal = now.getDay();
  var hours = now.getHours();
  var minutes = now.getMinutes();
  var seconds = now.getSeconds();
  retvalue=yy+"-"+mt+"-"+dd+"-"+hours+"-"+minutes+"-"+seconds;
  return retvalue;
}