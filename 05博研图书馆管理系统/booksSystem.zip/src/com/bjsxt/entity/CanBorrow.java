package com.bjsxt.entity;

import java.util.Date;

public class CanBorrow {
	private Date borrowTime;
	private Date backTime;
	private String bname;
	private String publishName;
	private String bcname;
	private double price;
	private int days;
	private int bid;
	private int id;
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public CanBorrow(Date backTime, String bname, String publishName,
			String bcname, double price, int days) {
		super();
		this.backTime = backTime;
		this.bname = bname;
		this.publishName = publishName;
		this.bcname = bcname;
		this.price = price;
		this.days = days;
	}
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
	public CanBorrow(int id, Date borrowTime, Date backTime, String bname,
			String publishName, String bcname, double price) {
		super();
		this.borrowTime = borrowTime;
		this.backTime = backTime;
		this.bname = bname;
		this.publishName = publishName;
		this.bcname = bcname;
		this.price = price;
		this.bid=bid;
		this.id=id;
	}
	public CanBorrow() {
		super();
	}
	
	public CanBorrow(Date borrowTime, Date backTime, String bname,
			String publishName, String bcname, double price, int days, int bid) {
		super();
		this.borrowTime = borrowTime;
		this.backTime = backTime;
		this.bname = bname;
		this.publishName = publishName;
		this.bcname = bcname;
		this.price = price;
		this.days = days;
		this.bid = bid;
	}
	public Date getBorrowTime() {
		return borrowTime;
	}
	public void setBorrowTime(Date borrowTime) {
		this.borrowTime = borrowTime;
	}
	public Date getBackTime() {
		return backTime;
	}
	public void setBackTime(Date backTime) {
		this.backTime = backTime;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getPublishName() {
		return publishName;
	}
	public void setPublishName(String publishName) {
		this.publishName = publishName;
	}
	public String getBcname() {
		return bcname;
	}
	public void setBcname(String bcname) {
		this.bcname = bcname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
