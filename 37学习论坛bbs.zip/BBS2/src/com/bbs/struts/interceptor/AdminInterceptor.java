package com.bbs.struts.interceptor;

import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class AdminInterceptor extends AbstractInterceptor {

	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		ActionContext context = invocation.getInvocationContext();
		Map map = context.getSession();
		if (!map.containsKey("adminName")) {
			return "adminlogin";
		} else
			return invocation.invoke(); // �û��ѵ��룬����
	}

}
