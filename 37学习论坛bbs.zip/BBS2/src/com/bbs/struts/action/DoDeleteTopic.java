package com.bbs.struts.action;

import com.bbs.struts.DAO.TopicListDAO;
import com.opensymphony.xwork2.ActionSupport;

public class DoDeleteTopic extends ActionSupport {
	private int id;
	private String result;
	public String execute() {
		if(TopicListDAO.DelRecord(id)){
			result="��ϲ���ɹ�ɾ��!";
		}
		else
			result="ɾ��ʧ�ܣ������⻹������ûɾ��!";
		return SUCCESS;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
}
