package com.bbs.struts.action;

import com.bbs.struts.DAO.Login;
import com.bbs.struts.DAO.LoginDAO;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class DoLogin extends ActionSupport {
	private Login login = new Login();

	@Override
	public String execute(){
		if (LoginDAO.login(login.getUsername(), login.getPassword())) {
			ActionContext.getContext().getSession().put("name",
					login.getUsername());
			ActionContext.getContext().getSession().put("islogin", 1);
			return SUCCESS;
		} else {
			ActionContext.getContext().getSession().put("islogin", 0);
			this.addFieldError("userlogin", "��������û����������������������");
			return ERROR;
		}
	}

	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}

}
