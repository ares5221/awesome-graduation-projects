package com.bbs.struts.action;

import java.util.List;

import com.bbs.struts.DAO.TopicList;
import com.bbs.struts.DAO.TopicListDAO;
import com.opensymphony.xwork2.ActionSupport;

public class DotopicList extends ActionSupport {
	private int forumid;
	private List<TopicList> topicList = null;
	private int page;
	private int iflogin;
	private int pageCount;

	public String execute() {
		try {
			topicList = TopicListDAO.search(page, forumid);
			pageCount = TopicListDAO.getPageCount(forumid);
		} catch (Exception e) {
			topicList = null;
			pageCount = 0;
		}
		return SUCCESS;
	}

	public int getPageCount() {
		return pageCount;
	}

	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}

	public int getIflogin() {
		return iflogin;
	}

	public void setIflogin(int iflogin) {
		this.iflogin = iflogin;
	}

	public int getForumid() {
		return forumid;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public void setForumid(int forumid) {
		this.forumid = forumid;
	}

	public List<TopicList> getTopicList() {
		return topicList;
	}

	public void setTopicList(List<TopicList> topicList) {
		this.topicList = topicList;
	}

}
