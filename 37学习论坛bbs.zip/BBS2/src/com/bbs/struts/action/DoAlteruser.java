package com.bbs.struts.action;

import com.bbs.struts.DAO.Login;
import com.opensymphony.xwork2.ActionSupport;

public class DoAlteruser extends ActionSupport {
	private Login user;
	private String result; 
	public String execute() {
		if(com.bbs.struts.DAO.LoginDAO.UpdateRecord(user.getUsername(), user.getGrade()))
			result="�޸ĳɹ���";
		else
			result="�޸�ʧ�ܣ�";
		return SUCCESS;
	}

	public Login getUser() {
		return user;
	}

	public void setUser(Login user) {
		this.user = user;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
