package com.bbs.struts.action;

import com.bbs.struts.DAO.ResponseDAO;
import com.opensymphony.xwork2.ActionSupport;

public class DoDeleteReponse extends ActionSupport {
	private int id;
	private String result;

	public String execute() {
		if (ResponseDAO.deleResponse(id)) {
			result = "��ϲ���ɹ�ɾ��!";
		} else
			result = "ɾ��ʧ��,���Ժ�����!";
		return SUCCESS;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
