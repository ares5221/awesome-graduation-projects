package com.bbs.struts.action;

import com.bbs.struts.DAO.ForumDao;
import com.opensymphony.xwork2.ActionSupport;

public class DoDeleteForum extends ActionSupport {
	private int id;
	private String result;
	public String execute() {
		if(ForumDao.deleteRecord(id)){
			result="��ϲ���ɹ�ɾ��!";
		}
		else
			result="ɾ��ʧ�ܣ��ð滹������ûɾ��!";
		return SUCCESS;
	}
	
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
