package com.bbs.struts.action;

import java.sql.SQLException;
import java.util.List;

import com.bbs.struts.DAO.ForumDao;
import com.bbs.struts.DAO.LoginDAO;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class DoMain extends ActionSupport {
	

	public String execute() {

		try {
			List<String>	username = LoginDAO.getUserName();
			 List<String>	formname = ForumDao.getForumName();
			
			ActionContext.getContext().getSession().put("username", username);
			ActionContext.getContext().getSession().put("formname", formname);
		} catch (SQLException e) {
		}
		return SUCCESS;
	}

	

}
