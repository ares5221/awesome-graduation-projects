package com.bbs.struts.action;

import com.bbs.struts.DAO.Login;
import com.bbs.struts.DAO.LoginDAO;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class Doadminlogin extends ActionSupport {
	private Login login = new Login();

	public String execute() throws Exception {
		if (LoginDAO.adminlogin(login.getUsername(), login.getPassword())) {
			ActionContext.getContext().getSession().put("adminName",
					login.getUsername());
			return SUCCESS;
		} else {
			this.addFieldError("adminlogin", "��������û����������������������");
			return ERROR;
		}
	}

	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}
	
}
