package com.bbs.struts.action;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class Dologinoff extends ActionSupport {
	public String execute() {
		ActionContext.getContext().getSession().clear();
		return SUCCESS;
	}
}
