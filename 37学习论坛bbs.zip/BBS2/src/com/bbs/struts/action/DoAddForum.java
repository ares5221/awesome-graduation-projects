package com.bbs.struts.action;

import com.bbs.struts.DAO.ForumDao;
import com.opensymphony.xwork2.ActionSupport;

public class DoAddForum extends ActionSupport {
	private String forumname;
	private String manager;
	private String result;
	public String execute() {
		if(ForumDao.AddRecord(forumname,manager)){
			result="��ϲ���ɹ����Ӱ��!";
		}
		else
			result="�Բ��𣬰������ʧ�ܣ����Ժ����ԡ�";
		return SUCCESS;
	}
	
	public String getForumname() {
		return forumname;
	}
	public void setForumname(String forumname) {
		this.forumname = forumname;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
}
