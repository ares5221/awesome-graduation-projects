package com.bbs.struts.action;

import com.bbs.struts.DAO.TopicList;
import com.bbs.struts.DAO.TopicListDAO;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class DoNewtopic extends ActionSupport {
	private TopicList t = new TopicList();
	private int forumid;

	public String execute() {
		String name = (String) ActionContext.getContext().getSession().get(
				"name");
		forumid = t.getForumid();
		t.setAuthor(name);
		t.setForumname(getForumname(forumid));
		ActionContext.getContext().getSession().put("forumid", forumid);
		if (TopicListDAO.InsertData(t))
			return SUCCESS;
		else {
			addFieldError("newtopicError", "����д����Ϣ�����޷����������ʵ�����ύ");
			return ERROR;
		}
	}

	public int getForumid() {
		return forumid;
	}

	public TopicList getT() {
		return t;
	}

	public void setT(TopicList t) {
		this.t = t;
	}

	private String getForumname(int i) {

		switch (i) {
		case 1:
			return "ASP";
		case 2:
			return "PHP";
		case 3:
			return "C#";
		case 4:
			return ".NET";
		case 5:
			return "VB";
		case 6:
			return "JSP";
		default:
			return "0";
		}
	}

}
