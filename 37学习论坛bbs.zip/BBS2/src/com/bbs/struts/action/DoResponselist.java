package com.bbs.struts.action;

import java.sql.SQLException;
import java.util.List;

import com.bbs.struts.DAO.Responseview;
import com.bbs.struts.DAO.ResponseviewDAO;
import com.bbs.struts.DAO.Topicview;
import com.bbs.struts.DAO.TopicviewDAO;
import com.opensymphony.xwork2.ActionSupport;

public class DoResponselist extends ActionSupport {
	private int topicid;
	private String topicname;
	private List<Responseview> responseList = null;
	private int forumid;
	private Topicview tview = null;

	public String execute() {

		try {
			tview = TopicviewDAO.getTopicview(topicid);
			topicname = tview.getTitle();
			responseList = ResponseviewDAO.getResponseview(topicid);
		} catch (SQLException e) {
			responseList = null;
			e.printStackTrace();
		}
		return SUCCESS;
	}

	public String getTopicname() {
		return topicname;
	}

	public void setTopicname(String topicname) {
		this.topicname = topicname;
	}

	public Topicview getTview() {
		return tview;
	}

	public void setTview(Topicview tview) {
		this.tview = tview;
	}

	public int getTopicid() {
		return topicid;
	}

	public void setTopicid(int topicid) {
		this.topicid = topicid;
	}

	public List<Responseview> getResponseList() {
		return responseList;
	}

	public void setResponseList(List<Responseview> responseList) {
		this.responseList = responseList;
	}

	public int getForumid() {
		return forumid;
	}

	public void setForumid(int forumid) {
		this.forumid = forumid;
	}
}
