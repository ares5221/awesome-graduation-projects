package com.bbs.struts.action;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;

import com.bbs.struts.DAO.Login;
import com.bbs.struts.DAO.LoginDAO;
import com.bbs.struts.DAO.Response;
import com.bbs.struts.DAO.ResponseDAO;
import com.bbs.struts.util.Time;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class DoResponse extends ActionSupport {
	private Response rp = new Response();
	private String result;

	public String execute() {
		String name = (String) ActionContext.getContext().getSession().get(
				"name");
		rp.setAuthor(name);
		ResponseDAO.InsertResponseRecord(rp);
		Login user = null;
		try {
			user = LoginDAO.getRecordForUser(name);
		} catch (SQLException e) {
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("content", rp.getContent());
		map.put("xq", rp.getXq());
		map.put("author", rp.getAuthor());
		map.put("submittime", Time.getCurrentTime());
		if (name == null) {
			map.put("email", "");
			map.put("tx", "0.gif");
			map.put("qq", "");
		} else {
			map.put("email", user.getEmail());
			map.put("tx", user.getTx());
			map.put("qq", user.getOicq());
		}
		JSONObject jo = JSONObject.fromObject(map);
		result = jo.toString();

		return SUCCESS;
	}

	public Response getRp() {
		return rp;
	}

	public void setRp(Response rp) {
		this.rp = rp;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
