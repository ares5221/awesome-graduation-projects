package com.bbs.struts.action;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.bbs.struts.DAO.Database;
import com.opensymphony.xwork2.ActionSupport;

public class DoCheckuser extends ActionSupport {
	private String username;
	private boolean check = false;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public boolean isCheck() {
		return check;
	}

	public void setCheck(boolean check) {
		this.check = check;
	}

	@Override
	public String execute() {
		String sql = "SELECT id FROM tb_user WHERE username=?";
		Database db = Database.getDatebase();
		ResultSet rs = db.OpenPreStatement(sql, new Object[] { username });
		try {
			if (rs.next()) {
				this.addFieldError("checkuser", "���û�����ʹ�ã����������û���");
				check = false;
			} else {
				this.addFieldError("checkuser", "���û�������ʹ��");
				check = true;
			}
			rs.close();
			db.colse();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("username " + username);
		System.out.println("check " + check);
		return SUCCESS;
	}
}
