package com.bbs.struts.action;

import com.bbs.struts.DAO.ForumDao;
import com.opensymphony.xwork2.ActionSupport;

//������̳�İ���
public class DoForumedit extends ActionSupport {
	private String formname;
	private String username;
	private String result;
	public String execute() {
		if (ForumDao.updateRecord(formname, username)) {
			result="��ϲ���������ĳɹ�!";
		} else {
			result="������˼���޸�ʧ��!";
		}
		return SUCCESS;
	}

	public String getFormname() {
		return formname;
	}

	public void setFormname(String formname) {
		this.formname = formname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
