package com.bbs.struts.action;

import com.opensymphony.xwork2.ActionSupport;

public class DoDeleteuser extends ActionSupport {
	private String username;
	private String result; 
	public String execute() {
		if(com.bbs.struts.DAO.LoginDAO.deleteRecord(username))
			result="ɾ���ɹ���";
		else
			result="ɾ��ʧ�ܣ�";
		return SUCCESS;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}

}
