package com.bbs.struts.tl;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import com.bbs.struts.DAO.ForumDao;

public class DisplayCount extends TagSupport {
	public int doEndTag() throws JspException {
		JspWriter out = pageContext.getOut();
		int ztcount = ForumDao.getCount();
		int todaycount = ForumDao.getTodayResponseCount();
		int ztAndResponseCount = ForumDao.getZtAndResponseCount();
		try {
			out.println("<table width='100%' border='0'>");
			out.println("<tr class='whitezi'>");
			out.println("<td width='22%' height='20'>");
			out.println("���⣺" + ztcount + "ƪ</td>");
			out
					.println("<td width='25%'>���£�" + ztAndResponseCount
							+ "ƪ</td>");
			out.println("<td width='25%'>����: " + ztAndResponseCount
					+ "ƪ</td>");
			out.println("<td>��������: " + todaycount + " ��</td></tr></table>");
		} catch (IOException e) {

		}
		return super.doEndTag();
	}

}
