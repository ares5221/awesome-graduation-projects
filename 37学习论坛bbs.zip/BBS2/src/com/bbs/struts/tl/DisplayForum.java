package com.bbs.struts.tl;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import com.bbs.struts.DAO.Forum;
import com.bbs.struts.DAO.ForumDao;

public class DisplayForum extends TagSupport {
	public int doEndTag() throws JspException {
		JspWriter out = pageContext.getOut();
		List<Forum> list = ForumDao.getRecord();
		Iterator<Forum> it = list.iterator();
		while (it.hasNext()) {
			Forum f = it.next();
			try {
				out.println("<TR id='"+f.getId()+"'><TD WIDTH=808 HEIGHT=34 background='images/gl_3_3.gif'><table width='100%'  height='34' border='0' cellspacing='0' cellpadding='0'>");
				out.println("<tr align='center' class='zczi'>");
				out.println("<td width='16%'>" + f.getId() + "</td>");
				out.println("<td width='12%'>" + f.getForumnname() + "</td>");
				if (f.getForumnname() == null) {
					out.println("<td>��ʱ�ް���</td>");
				} else {
					out.println("<td>" + f.getManager() + "</td>");
				}
				out.println("<td width='32%'>" + f.getCreatetime() + "</td>");
				out.println("<td width='16%'><a href='#' onClick='deleteForum("+f.getId()+")'>ɾ��</a></td></tr>");
				out.print("</table></TD></TR>");
			} catch (IOException e) {
			}
		}
		return super.doEndTag();
	}
}
