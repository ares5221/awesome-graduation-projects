package com.bbs.struts.tl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import com.bbs.struts.DAO.Login;


public class DisplaySearchUser extends TagSupport{
	public int doEndTag() throws JspException
	{
		JspWriter out = pageContext.getOut();
		HttpServletRequest request=(HttpServletRequest)pageContext.getRequest();
	        HttpSession session = pageContext.getSession();
	        List listsearchname=(List)session.getAttribute("listsearchname");
	        try{
	        	if(listsearchname!=null){
	        		for(int i=0;i<listsearchname.size();i++){
		        		Login login=(Login)listsearchname.get(i);{
		        			out.println("<tr>");
							out.println("<td width='804' height='67' valign='top' background='images/um_03.gif'>");
							out.println("<table width='100%'  border='0' height='67'>");
							out.println("<tr align='center'>");
							out.println("<td width='16%' align='center' valign='top'><img src='images/touxiang/"+login.getTx()+"' width='60' height='58'></td>");
							out.println("<td width='11%' class='zczi'>"+login.getUsername()+"</td>");
							if(login.getGrade().equals("admin"))
								out.println("<td width='24%' class='zczi'>����Ա</td>");
							if(login.getGrade().equals("user"))
								out.println("<td width='24%' class='zczi'>��ͨ�û�</td>");
							if(login.getGrade().equals("bz"))
								out.println("<td width='24%' class='zczi'>����</td>");
							out.println("<td width='32%' class='zczi'><a href='userdeit.do?id="+login.getId()+"&name="+login.getUsername()+"' class='zczi'>�༭</a></td>");
							out.println("<td width='17%' class='zczi'><a href='userdelete.do?id="+login.getId()+"&name="+login.getUsername()+"' class='zczi'>ɾ��</a></td>");
							out.println("</tr>");
							out.println("</table></td></tr>");
		        		}
	        		}
	        	}
	        }catch(Exception e){
	        	e.printStackTrace();
	        }
	        return super.doEndTag();
	}
}


