package com.bbs.struts.tl;

import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import com.bbs.struts.DAO.Forum;
import com.bbs.struts.DAO.ForumDao;



public class Display extends TagSupport{
	public int doEndTag() throws JspException
	{
		JspWriter out = pageContext.getOut();
	    try{
	    	
	    	 List<Forum>  l=ForumDao.getRecord();
	        	for(int i=0;i<l.size();i++){
	        		Forum f=(Forum)l.get(i);	

	        		  
	        		out.println("<tr>");
					out.println("<td colspan='2'  height='64'>");
					if(i%2==0){
						out.println("<table width='100%' height='64' border='0' background='images/06.gif'>");
					}
					else
						out.println("<table width='100%' height='64' border='0' background='images/061.gif'>");
					out.println("<tr>");
					out.println("<td></td>");
					out.println("<td  colspan='2'><span class='zczi'>�Ƽ���˾�����</span><span class='zczi'>[<a href=dotopicList.action?forumid="+ f.getId() + "&forumname=" + (f.getForumnname()) +" class='zczi'>"+(f.getForumnname())+"</a> ]</span><span class='zczi'>������ר��</span></td>");	
					out.println("<td width='13%' valign='bottom' class='zi'>"+f.getCreatetime()+"</td>");
					out.println("</tr>");
					out.println("<tr>");
					out.println("<td width='11%' height='21'>&nbsp;</td>");
					out.println("<td width='5%'  class='zczi'>������</td>");
	        		if(f.getManager()!=null){
	        			out.println("<td width='71%'  class='zczi'>"+(f.getManager())+"</td>");
	        		}
	        		else{
	        			out.println("<td width='71%'  class='zczi'>����̳��ʱû�а���</td>");
	        		}
					out.println("<td class='zi' valign='bottom'>"+f.getCount()+"</td>");
					out.println("</tr>");
					out.println("</table>");
					out.println("</td>");
					out.println("</tr>");
	        		  
	        	}
	    	

		}catch(Exception e){
			e.printStackTrace();
		}
	    
		return super.doEndTag();
	}
}