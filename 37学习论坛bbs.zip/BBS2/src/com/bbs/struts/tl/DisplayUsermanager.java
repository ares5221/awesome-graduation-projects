package com.bbs.struts.tl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import com.bbs.struts.DAO.Login;

//��ʾ�û�����
public class DisplayUsermanager extends TagSupport {
	public int doEndTag() throws JspException {
		JspWriter out = pageContext.getOut();
		HttpServletRequest request = (HttpServletRequest) pageContext
				.getRequest();
		int  pageid=Integer.parseInt(request.getParameter("pageid"));
		List<Login> listuser=com.bbs.struts.DAO.LoginDAO.getTotalRecord(pageid);
		try {
			if (listuser != null) {
				for (int i = 0; i < listuser.size(); i++) {
					Login login = (Login) listuser.get(i);
					out.println("<tr>");
					out
							.println("<td width='804' height='67' valign='top' background='images/um_03.gif'>");
					out.println("<table width='100%'  border='0' height='67'>");
					out.println("<tr align='center'>");
					out
							.println("<td width='16%' align='center' valign='top'><img src='images/touxiang/"
									+ login.getTx()
									+ "' width='60' height='58'></td>");
					out.println("<td width='11%' class='zczi'>"
							+(login.getUsername()) + "</td>");
					if (login.getGrade().equals("admin"))
						out.println("<td width='24%' class='zczi'>����Ա</td>");
					if (login.getGrade().equals("user"))
						out.println("<td width='24%' class='zczi'>��ͨ�û�</td>");
					if (login.getGrade().equals("bz"))
						out.println("<td width='24%' class='zczi'>����</td>");
					// out.println("<td width='32%' class='zczi'><a href='useredit.do?id="+login.getId()+"&name="+login.getUsername()+"' class='zczi'>�༭</a></td>");
					// out.println("<td width='32%' class='zczi'><a href='#' onclick=window.open('useredit.do?id="+login.getId()+"&name="+login.getUsername()+"') class='zczi'>�༭</a></td>");
					if (login.getUsername().equals("TSoft")) {// ��֤ϵͳʼ���и������û���ʹ����ΪTSoft���û����ɱ༭��ɾ����
						out.println("<td width='32%' class='zczi'>�༭</td>");
						out.println("<td width='17%' class='zczi'>ɾ��</td>");
					} else {
						out
								.println("<td width='32%' class='zczi'><a href='alteruser.jsp?username="+login.getUsername()+"&grade="+login.getGrade()+"'>�༭</a></td>");
						out
								.println("<td width='17%' class='zczi'><a  onClick='confirm(\"��ȷ��Ҫɾ�����û���\")' href='dodeleteuser.action?username="+login.getUsername()+"'>ɾ��</a></td>");
					}
					out.println("</tr>");
					out.println("</table></td></tr>");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return super.doEndTag();
	}

}
