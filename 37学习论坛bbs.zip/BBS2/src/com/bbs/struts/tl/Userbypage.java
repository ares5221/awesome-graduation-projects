package com.bbs.struts.tl;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class Userbypage  extends TagSupport {
	public int doEndTag() throws JspException {
		JspWriter out = pageContext.getOut();
		try {
			out.println("<table width='811' border='0'>");
			out.println("<tr>");
			out.println("<td width='223'>&nbsp;</td>");
			out.println("<td width='83' align='center' class='fyzi'><a href='<%=url_fir %>' class='fyzi'>��ҳ</a></td>");
		    out.println("<td width='75' align='center' class='fyzi'><a href='<%=url_pre %>' class='fyzi'>��һҳ</a></td>");
			out.println("<td width='76' align='center' class='fyzi'><a href='<%=url_next %>'  class='fyzi'>��һҳ</a></td>");
			out.println("<td width='332' align='left' class='fyzi'><a href='<%=url_last %>' class='fyzi'>βҳ</a></td>");
			out.println("</tr></table>");
		} catch (IOException e) {
			
		}
		return super.doEndTag();
	}
}
