package com.bbs.struts.tl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import com.bbs.struts.DAO.TopicList;
import com.bbs.struts.DAO.TopicListDAO;

public class DisplayTopic extends TagSupport {
	private ArrayList<TopicList> topicList = new ArrayList<TopicList>();
	private int page=0;
	private int pageCount=0;
	public int doEndTag() throws JspException {
		try {
			pageCount=TopicListDAO.getPageCount();
		} catch (SQLException e1) {
			
		}
		page=Integer.parseInt(pageContext.getRequest().getParameter("page"));
		JspWriter out = pageContext.getOut();
		topicList = (ArrayList<TopicList>) TopicListDAO.getTotalRecordTopic(page);
		Iterator<TopicList> topic = topicList.iterator();
		while (topic.hasNext()) {
			TopicList t = topic.next();

			try {
				out
						.println("<tr id="+t.getId()+"><td width='810' height='37' valign='top' background='images/zt2_02.gif'><table width='100%'  height='37' border='0'>");
				out.println("<tr align='center' class='zczi'>");
				out.println("<td width='16%'><img src='images/xq/" + t.getXq()
						+ "'></td>");
				out.println("<td width='12%'>" + t.getForumname() + "</td>");
				out.println("<td width='12%'>" + t.getAuthor() + "</td>");
				out
						.println("<td width='11%'><a class='navlink' style='CURSOR:hand' href='responsetopic.jsp?topicid="+t.getId()+"&pageid=0'>"
								+ t.getTitle() + "</a></td>");
				out.println("<td width='32%'>" + t.getSubmittime() + "</td>");
				out
						.println("<td width='17%'><a href='#' onClick='deletetopic("+t.getId()+")'>ɾ��</a></td>");
				out.println("</tr></table></td></tr>");
			} catch (IOException e) {
			}
		}
		return super.doEndTag();
	}

	public ArrayList<TopicList> getTopicList() {
		return topicList;
	}

	public void setTopicList(ArrayList<TopicList> topicList) {
		this.topicList = topicList;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageCount() {
		return pageCount;
	}

	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}
	

}
