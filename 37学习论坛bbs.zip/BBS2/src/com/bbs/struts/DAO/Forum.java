package com.bbs.struts.DAO;

import java.sql.ResultSet;

public class Forum {
	private int id;
	private String forumnname;
	private String manager;
	private String createtime;
	private int count;// ÿ����̳�����������
	private int ztcount;// �ܵ�������
	private int ztAndResponseCount;// �������������������ӻظ�������
	private int todaycount;// �������������

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getForumnname() {
		return forumnname;
	}

	public void setForumnname(String forumnname) {
		this.forumnname = forumnname;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getZtcount() {
		return ztcount;
	}

	public void setZtcount(int ztcount) {
		this.ztcount = ztcount;
	}

	public int getZtAndResponseCount() {
		return ztAndResponseCount;
	}

	public void setZtAndResponseCount(int ztAndResponseCount) {
		this.ztAndResponseCount = ztAndResponseCount;
	}

	public int getTodaycount() {
		return todaycount;
	}

	public void setTodaycount(int todaycount) {
		this.todaycount = todaycount;
	}

}
