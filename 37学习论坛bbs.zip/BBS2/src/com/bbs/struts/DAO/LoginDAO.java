package com.bbs.struts.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LoginDAO {
	private static Database db = Database.getDatebase();

	public static boolean login(String name, String password) {
		ResultSet rs = null;
		boolean b = false;
		db.getCon();
		try {
			String sql = "select * from tb_user where username =? and password=?";
			rs = db.OpenPreStatement(sql, new Object[] { name, password });
			while (rs.next()) {
				if (rs.getString(1) != null || rs.getString(1).length() != 0) {
					b = true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		db.colse();
		return b;
	}

	public static boolean adminlogin(String name, String password) {
		ResultSet rs = null;
		boolean b = false;
		db.getCon();
		try {

			String sql = "select * from tb_user where username =? and password=? and grade=?";
			rs = db.OpenPreStatement(sql, new Object[] { name, password,
					"admin" });
			while (rs.next()) {
				if (rs.getString(1) != null || rs.getString(1).length() != 0) {
					b = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		db.colse();
		return b;
	}

	public static Login getRecordForUser(String name) throws SQLException {
		Login login = new Login();
		ResultSet rs = null;
		db.getCon();
		String sql = "select * from tb_user where username='" + name + "'";
		rs = db.openStatement(sql);
		while (rs.next()) {
			login.setId(rs.getInt("id"));
			login.setUsername(rs.getString("username"));
			login.setPassword(rs.getString("password"));
			login.setSex(rs.getString("sex"));
			login.setEmail(rs.getString("email"));
			login.setOicq(rs.getString("oicq"));
			login.setSignature(rs.getString("signature"));
			login.setGrade(rs.getString("grade"));
			login.setLxdz(rs.getString("lxdz"));
			login.setTx(rs.getString("tx"));
			login.setGrzy(rs.getString("grzy"));
			login.setRealname(rs.getString("realname"));
		}
		rs.close();
		db.colse();
		return login;
	}

	public static List<String> getUserName() throws SQLException { // ��������û����û���
		List<String> l = new ArrayList<String>();
		ResultSet rs = null;
		db.getCon();
		String sql = "select username from tb_user ";

		rs = db.openStatement(sql);
		while (rs.next()) {
			l.add(rs.getString("username"));
		}
		rs.close();
		db.colse();
		return l;
	}

	public static List<Login> getTotalRecord(int pageid) {
		List<Login> l = new ArrayList<Login>();
		ResultSet rs = null;
		db.getCon();
		String sql = "select * from tb_user order by id asc limit " + pageid
				* Constants.TOPIC_PAGE_SIZE + "," + Constants.TOPIC_PAGE_SIZE;
		Login login = null;
		try {
			rs = db.openStatement(sql);
			while (rs.next()) {
				login = new Login();
				login.setId(rs.getInt("id"));
				login.setUsername(rs.getString("username"));
				login.setPassword(rs.getString("password"));
				login.setSex(rs.getString("sex"));
				login.setEmail(rs.getString("email"));
				login.setOicq(rs.getString("oicq"));
				login.setSignature(rs.getString("signature"));
				login.setGrade(rs.getString("grade"));
				login.setLxdz(rs.getString("lxdz"));
				login.setTx(rs.getString("tx"));
				login.setGrzy(rs.getString("grzy"));
				login.setRealname(rs.getString("realname"));
				l.add(login);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.colse();
		return l;
	}

	public static boolean UpdateRecord( String name, String grade) {
		boolean b;
		db.getCon();
		String sql = "update tb_user set grade='"
				+ grade + "' where username='" + name + "'";
		b = db.openUpateStatement(sql);
		db.colse();
		return b;
	}

	public static boolean deleteRecord(String name) {
		boolean b;
		db.getCon();
		String sql = "delete  from tb_user where username='" + name + "'";
		b = db.openUpateStatement(sql);
		db.colse();
		return b;
	}

	public int CheckUser(String username) {
		int i = 0;
		db.getCon();
		String sql = "select username from tb_user where username='" + username
				+ "'";
		ResultSet rs = db.openStatement(sql);
		try {
			while (rs.next()) {
				Login login = new Login();
				login.setUsername(rs.getString(1));
				if (login.getUsername() != null) {
					i = 1;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public static int getPageCount() throws SQLException {
		String sql = "select count(*) from tb_user ";
		ResultSet rs = db.openStatement(sql);
		int count = 0;
		while (rs.next()) {
			count = rs.getInt(1);
		}
		return count % Constants.TOPIC_PAGE_SIZE == 0 ? count
				/ Constants.TOPIC_PAGE_SIZE : count / Constants.TOPIC_PAGE_SIZE
				+ 1;
	}
}
