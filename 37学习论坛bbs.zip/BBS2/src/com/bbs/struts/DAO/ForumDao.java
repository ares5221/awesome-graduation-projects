package com.bbs.struts.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ForumDao {
	private static Database db = Database.getDatebase();

	public static List<Forum> getRecord(String id) { // ���ָ�� ����Ϣ
		ResultSet rs = null;

		List<Forum> l = new ArrayList<Forum>();
		try {
			db.getCon();

			String sql = "select * from tb_forum where id='" + id + "'";
			rs = db.openStatement(sql);

			while (rs.next()) {
				Forum f = new Forum();
				f.setId(rs.getInt("id"));
				f.setForumnname(rs.getString("forumname"));
				f.setManager(rs.getString("manager"));
				f.setCreatetime(rs.getString("createtime"));
				l.add(f);
			}
			rs = null;
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.colse();
		return l;
	}

	public static List<Forum> getRecord() {// �ս���ϵͳʱ��ʹ�õĲ�ѯ��������ø�����Ϣ
		ResultSet rs = null;
		List<Forum> l = new ArrayList<Forum>();
		db.getCon();
		try {
			String sql = "select * from tb_forum";
			rs = db.openStatement(sql);
			while (rs.next()) {
				Forum f = new Forum();
				f.setId(rs.getInt("id"));
				f.setForumnname(rs.getString("forumname"));
				f.setManager(rs.getString("manager"));
				f.setCreatetime(rs.getString("createtime"));
				l.add(f);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		db.colse();
		return l;
	}

	public static List<String> getForumName() throws SQLException { // ��ø��������
		ResultSet rs = null;
		List<String> l = new ArrayList<String>();
		db.getCon();
		String sql = "select forumname from tb_forum";
		rs = db.openStatement(sql);
		while (rs.next()) {
			l.add(rs.getString("forumname"));
		}
		rs.close();
		db.colse();
		return l;
	}

	public static int getCount() { // �����������
		ResultSet rs = null;
		db.getCon();

		int i = 0;
		try {
			String sql = "select count(*) from tb_topic ";
			rs = db.openStatement(sql);
			while (rs.next()) {
				i = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.colse();
		return i;
	}

	public static int getCount(int forumid) { // ���ָ�����������
		ResultSet rs = null;

		db.getCon();
		int i = 0;
		try {
			String sql = "select count(*) from tb_topic where forumid='"
					+ forumid + "'";
			rs = db.openStatement(sql);
			while (rs.next()) {
				i = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.colse();
		return i;
	}

	public static int getResponseCount() {// ȡ��������
		ResultSet rs = null;
		db.getCon();
		int i = 0;
		try {
			String sql = "select count(*) from tb_response ";
			rs = db.openStatement(sql);
			while (rs.next()) {
				i = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.colse();
		return i;
	}

	public static int getZtAndResponseCount() {// ȡ����������
		return getResponseCount() + getCount();
	}

	public static int gettodayTopicCount() {// ȡ�������������
		ResultSet rs = null;
		db.getCon();
		int i = 0;
		try {
			String sql = "select count(*) from tb_topic where (TO_DAYS(submittime)-TO_DAYS(now())=0)";
			rs = db.openStatement(sql);
			while (rs.next()) {
				i = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.colse();
		return i;
	}

	public static int getTodayResponseCount() {// ȡ����ظ����������
		ResultSet rs = null;
		db.getCon();
		int i = 0;
		try {
			String sql = "select count(*) from tb_response where (TO_DAYS(submittime)-TO_DAYS(now())=0)";
			rs = db.openStatement(sql);
			while (rs.next()) {
				i = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.colse();
		return i;
	}

	public static boolean updateRecord(String forumname, String name) {
		boolean b;
		db.getCon();
		String sql = "update tb_forum set manager=? where forumname=?";
		b = db.OpenPreparedStatement(sql, new Object[] { name, forumname });
		db.colse();
		return b;
	}

	public static boolean deleteRecord(int id) {
		boolean b;
		db.getCon();
		String sql = "delete  from tb_forum where id=?";
		b = db.OpenPreparedStatement(sql, new Object[] { id });
		db.colse();
		return b;
	}

	public static boolean AddRecord(String forumname,String manager) {
		boolean b;
		db.getCon();
		String sql = "insert into tb_forum(forumname,manager) values(?,?)";
		b = db.OpenPreparedStatement(sql, new Object[] { forumname, manager});
		db.colse();
		return b;
	}

}
