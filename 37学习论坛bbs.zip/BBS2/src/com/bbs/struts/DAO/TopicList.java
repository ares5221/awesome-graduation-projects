package com.bbs.struts.DAO;

public class TopicList {
	private int id;
	private String content;
	private String author;
	private String submittime;
	private int forumid;
	private String title;
	private String xq; //������е��ֶ�
	private String rq; //����
	private int reCount;//ÿ������ظ��ĸ���
	private String lastTalk;//ÿ���������»ظ��������
	private String forumname;//��̳����

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getSubmittime() {
		return submittime;
	}
	public void setSubmittime(String submittime) {
		this.submittime = submittime;
	}
	
	public int getForumid() {
		return forumid;
	}
	public void setForumid(int forumid) {
		this.forumid = forumid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getXq() {
		return xq;
	}
	public void setXq(String xq) {
		this.xq = xq;
	}
	public String getRq() {
		return rq;
	}
	public void setRq(String rq) {
		this.rq = rq;
	}
	public int getReCount() {
		return reCount;
	}
	public void setReCount(int reCount) {
		this.reCount = reCount;
	}
	public String getLastTalk() {
		return lastTalk;
	}
	public void setLastTalk(String lastTalk) {
		this.lastTalk = lastTalk;
	}
	public String getForumname() {
		return forumname;
	}
	public void setForumname(String forumname) {
		this.forumname = forumname;
	}
	
}
