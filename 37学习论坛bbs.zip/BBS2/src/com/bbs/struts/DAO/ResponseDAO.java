package com.bbs.struts.DAO;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ResponseDAO {
	private static Database db = Database.getDatebase();

	public static List<Response> getAllRecord() {
		List<Response> list = new ArrayList();
		ResultSet rs = null;
		db.getCon();
		String sql = "select * from tb_response";
		rs = db.openStatement(sql);
		try {
			while (rs.next()) {
				Response r = new Response();
				r.setId(rs.getInt("id"));
				r.setTitle(rs.getString("title"));
				r.setAuthor(rs.getString("author"));
				System.out.println((rs.getString("topicname")));
				r.setSubmittime(rs.getString("submittime"));
				r.setTopicid(rs.getInt("topicid"));
				r.setTopicname(rs.getString("topicname"));
				r.setXq(rs.getString("xq"));
				list.add(r);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		db.colse();
		return list;
	}

	public static boolean deleResponseRecord(String topicid) {
		boolean b;
		db.getCon();
		String sql = "delete from tb_response where topicid='" + topicid + "'";
		b = db.openUpateStatement(sql);
		return b;
	}
	public static boolean deleResponse(int id) {
		boolean b;
		db.getCon();
		String sql = "delete from tb_response where id='" + id + "'";
		b = db.openUpateStatement(sql);
		return b;
	}
	public static boolean InsertResponseRecord(Response rp) {
		boolean b;
		db.getCon();
		String sql = "INSERT INTO tb_response " +
				"(title, content, author,topicid, topicname, xq)" +
				"VALUES('"+rp.getTitle()+"', '"+rp.getContent()+"', '"+rp.getAuthor()+"', '"+rp.getTopicid()+"', '"+rp.getTopicname()+"', '"+rp.getXq()+"')";
		System.out.println(sql);
		b = db.openUpateStatement(sql);
		return b;
	}
}
