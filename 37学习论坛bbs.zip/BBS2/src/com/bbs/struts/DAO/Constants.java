package com.bbs.struts.DAO;

public class Constants {
	public static final int  TOPIC_PAGE_SIZE=5;
}
