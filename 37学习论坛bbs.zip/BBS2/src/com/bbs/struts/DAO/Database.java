package com.bbs.struts.DAO;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
	private static Database db;
	private Connection con = null;
	private Statement state = null;
	private PreparedStatement per = null;
	private ResultSet rs = null;
	private CallableStatement callstmt = null;

	public static Database getDatebase() {
		db = new Database();
		return db;
	}

	private Database() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/db_bbs", "root", "123456");
		} catch (Exception e) {
			System.out.println("���ݿ������쳣");
			e.printStackTrace();
		}
	}

	public void openCon() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/db_bbs", "root", "123456");
		} catch (Exception e) {
			
			System.out.println("���ݿ������쳣");
		}
	}

	public ResultSet openStatement(String sql) {
		try {
			getCon();
			state = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			rs = state.executeQuery(sql);
		} catch (SQLException e) {
			System.out.println("����Statement�쳣");
			e.printStackTrace();
		} finally {
			return rs;
		}
	}

	public boolean openUpateStatement(String sql) {
		boolean isSuccee = false;
		try {
			getCon();
			state = con.createStatement();
			state.executeUpdate(sql);
			isSuccee = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return isSuccee;
	}

	public boolean OpenPreparedStatement(String sql, Object[] o) {
		boolean isSuccee = true;
		try {
			getCon();
			per = con.prepareStatement(sql);
			for (int i = 1; i <= o.length; i++) {
				per.setObject(i, o[i - 1]);
			}
		   per.execute();
		} catch (SQLException e) {
			isSuccee=false;
		} finally {
			return isSuccee;
		}
	}

	public ResultSet OpenPreStatement(String sql, Object[] o) {
		try {
			getCon();
			per = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			for (int i = 1; i <= o.length; i++) {
				per.setObject(i, o[i - 1]);
			}
			rs = per.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;

	}

	public ResultSet OpenQuerryCallableStatementt(String sql, Object[] in,
			int[] outType, Object out[]) throws SQLException {
		ResultSet rs = null;

/*		if (callstmt == null || callstmt.isClosed() || con == null*/
		if (callstmt == null  || con == null || con.isClosed())
			getCon();
		callstmt = con.prepareCall(sql);
		int l = in.length;
		for (int i = 0; i < l; i++) {
			callstmt.setObject(i + 1, in[i]);
		}

		for (int j = l + 1, i = 0; j <= l + out.length || i < out.length; i++, j++) {
			callstmt.setObject(j, out[i]);
			callstmt.registerOutParameter(j, outType[i]);
		}
		rs = callstmt.executeQuery();
		for (int j = 0; j < out.length; j++) {
			out[j] = callstmt.getObject(l + j + 1);
		}
		return rs;
	}

	public boolean OpenCallableStatementt(String sql, Object[] in,
			int[] outType, Object out[]) {
		boolean isSuccee = false;
		try {
			getCon();
			callstmt = con.prepareCall(sql);
			for (int i = 0; i < in.length; i++) {
				callstmt.setObject(i + 1, in[i]);
			}
			for (int j = 0; j < out.length; j++) {
				callstmt.setObject(in.length + j + 1, out[j]);
				callstmt.registerOutParameter(in.length + j + 1, outType[j]);
			}

			callstmt.execute();
			for (int j = 0; j < out.length; j++) {
				out[j] = callstmt.getObject(in.length + j + 1);
				System.out.println(out[j]);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isSuccee;
	}

	public boolean OpenCallableStatementt(String sql) {
		boolean isSuccee = false;
		try {
			getCon();
			callstmt = con.prepareCall(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			isSuccee = callstmt.execute();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			return isSuccee;
		}
	}

	public boolean OpenCallableStatementt(String sql, Object[] in) {
		boolean isSuccee = false;
		try {
			getCon();
			callstmt = con.prepareCall(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			for (int i = 0; i < in.length; i++) {
				callstmt.setObject(i + 1, in[i]);
			}
			isSuccee = callstmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			return isSuccee;
		}
	}

	public void colse() {
		try {
			if (rs != null)
				rs.close();
			if (state != null)
				state.close();
			if (per != null)
				per.close();
			if (callstmt != null)
				callstmt.close();
			if (con != null)
				con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Connection getCon() {
		try {
			if (con.isClosed())
				openCon();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	public void setCon(Connection con) {
		this.con = con;
	}

}
