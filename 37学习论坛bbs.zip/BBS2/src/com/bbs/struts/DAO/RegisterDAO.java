package com.bbs.struts.DAO;

import javax.sql.DataSource;

public class RegisterDAO {
	private static Database db = Database.getDatebase();

	public static boolean InsertData(Register register) {
		boolean b;
		db.getCon();
		String sql = "insert into tb_user(username,password,sex,email,oicq,signature,grade,lxdz,tx,grzy,realname) values(?,?,?,?,?,?,?,?,?,?,?)";
		b = db.OpenPreparedStatement(sql, new Object[] {
				register.getUsername(), register.getPassword1(),
				register.getSex(), register.getMail(), register.getQq(),
				register.getSignature(), "user", register.getLxdz(),
				register.getTx(), register.getGrzy(), register.getRealname() });
		db.colse();
		return b;
	}

	public static boolean deleResponseRecord(String id, DataSource datasource) {
		boolean b;
		db.getCon();
		String sql = "delete from tb_response where id='" + id + "'";
		b = db.openUpateStatement(sql);
		return b;
	}
}
