package com.bbs.struts.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ResponseviewDAO {
	private static Database db = Database.getDatebase();

	public static List<Responseview> getResponseview(int topicid)
			throws SQLException {
		List<Responseview> responseview = new ArrayList<Responseview>();
		db.getCon();
		Responseview view ;
		String sql = "select * from responseview WHERE topicid=" + topicid	
		+ "  ORDER BY rid ASC ";
		ResultSet rs = db.openStatement(sql);
		while (rs.next()) {
			 view = new Responseview();
			view.setRid(rs.getInt("rid"));
			view.setTitle(rs.getString("title"));
			view.setContent(rs.getString("content"));
			view.setAuthor(rs.getString("author"));
			view.setSubmittime(rs.getString("submittime"));
			view.setTopicid(rs.getInt("topicid"));
			view.setTopicname(rs.getString("topicname"));
			view.setXq(rs.getString("xq"));
			view.setUsername(rs.getString("username"));
			view.setSex(rs.getString("sex"));
			view.setEmail(rs.getString("email"));
			view.setOicq(rs.getString("oicq"));
			view.setSignature(rs.getString("signature"));
			view.setGrade(rs.getString("grade"));
			view.setLxdz(rs.getString("lxdz"));
			view.setTx(rs.getString("tx"));
			view.setGrzy(rs.getString("grzy"));
			view.setRealname(rs.getString("realname"));
			responseview.add(view);
		}
		rs.close();
		db.colse();
		return responseview;
	}

	public static int getRqPageCount(int topicid) throws SQLException {
		String sql = "SELECT COUNT(rid) FROM  responseview WHERE topicid="
				+ topicid;
		db.getCon();
		ResultSet rs = db.openStatement(sql);
		int count = 0;
		while (rs.next()) {
			count = rs.getInt(1);
		}
		rs.close();
		db.colse();
		return count % Constants.TOPIC_PAGE_SIZE == 0 ? count
				/ Constants.TOPIC_PAGE_SIZE : count / Constants.TOPIC_PAGE_SIZE
				+ 1;
	}
}
