package com.bbs.struts.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TopicListDAO {
	private static Database db = Database.getDatebase();

	public static  int getPageCount(int ForumId) throws SQLException{
		String sql = "select count(*) from tb_topic where forumid=" + ForumId;
		ResultSet rs = db.openStatement(sql);
		int count = 0;
		while(rs.next()){
			count=rs.getInt(1);
		}
		return  count%Constants.TOPIC_PAGE_SIZE==0? count/Constants.TOPIC_PAGE_SIZE:count/Constants.TOPIC_PAGE_SIZE+1;
	}
	public static  int getPageCount() throws SQLException{
		String sql = "select count(*) from tb_topic ";
		ResultSet rs = db.openStatement(sql);
		int count = 0;
		while(rs.next()){
			count=rs.getInt(1);
		}
		return  count%Constants.TOPIC_PAGE_SIZE==0? count/Constants.TOPIC_PAGE_SIZE:count/Constants.TOPIC_PAGE_SIZE+1;
	}
	public static List<TopicList> search(int pageid, int ForumId) throws Exception {  //��ҳ�鿴������

		List<TopicList> l = new ArrayList<TopicList>();
		String sql = "select * from tb_topic where forumid=" + ForumId
				+ " order by id desc limit " + pageid
				* Constants.TOPIC_PAGE_SIZE + "," + Constants.TOPIC_PAGE_SIZE;
		db.getCon();
		ResultSet rs = db.openStatement(sql);
		ResultSet rscount = null;
		while (rs.next()) {
			TopicList t = new TopicList();
			t.setId(rs.getInt("id"));
			t.setContent(rs.getString("content"));
			t.setAuthor(rs.getString("author"));
			t.setSubmittime(rs.getString("submittime"));
			t.setForumid(rs.getInt("forumid"));
			t.setForumname(rs.getString("forumname"));
			t.setTitle(rs.getString("title"));
			t.setXq(rs.getString("xq"));
			t.setRq(rs.getString("rq"));
			t.setLastTalk(rs.getString("submittime"));
			String sqlcount = "select count(*) from tb_response where topicid='"
					+ t.getId() + "'";// ȡ����Ļظ�����
			rscount = db.openStatement(sqlcount);
			while (rscount.next()) {
				t.setReCount(rscount.getInt(1));
			}
			l.add(t);
		}
		rs.close();
		rscount.close();
		db.colse();
		return l;
	}
    // ����
	public static boolean InsertData(TopicList t) {
		boolean b = false;
		db.getCon();
		String sql = "insert into tb_topic(title,content,xq,author,forumid,forumname) values(?,?,?,?,?,?)";
		b = db.OpenPreparedStatement(sql, new Object[] { t.getTitle(), t.getContent(), t.getXq(),
				t.getAuthor(), t.getForumid(),t.getForumname()});
		db.colse();
		return b;

	}

	/* ����tb_response�����ݣ� ���� */
	public static boolean InsertDataResponse(String title, String content, String xq,
			String name, String topicid, String topicname) {
		boolean b = false;
		db.getCon();
		String sql = "insert into tb_response(title,content,author,topicid,topicname,xq)values ('"
				+ title
				+ "','"
				+ content
				+ "','"
				+ name
				+ "','"
				+ topicid
				+ "','" + topicname + "','" + xq + "')";
		System.out.println(sql);
		b = db.openUpateStatement(sql);
		return b;

	}

	/* ����������ڻظ�����ȡ��Ϣ */
	//�鿴ĳ���Ļ���
	public  static List<Response> getRecordResponse(int topicid,int pageid) {
		List<Response> list = new ArrayList<Response>();
		db.getCon();
		ResultSet rs = null;
		String sql=new String();
		if(topicid==0){
			 sql = "select * from tb_response  order by id desc limit " + pageid* Constants.TOPIC_PAGE_SIZE + "," + Constants.TOPIC_PAGE_SIZE;
		}
		else
			sql = "select * from tb_response where topicid='" + topicid
				+ "'  order by id desc limit " + pageid
				* Constants.TOPIC_PAGE_SIZE + "," + Constants.TOPIC_PAGE_SIZE;
		try {
			rs = db.openStatement(sql);
			while (rs.next()) {
				Response t = new Response();
				t.setId(rs.getInt("id"));
				t.setTitle(rs.getString("title"));
				t.setContent(rs.getString("content"));
				t.setAuthor(rs.getString("author"));
				t.setSubmittime(rs.getString("submittime"));
				t.setXq(rs.getString("xq"));
				list.add(t);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		db.colse();
		return list;
	}
	public  static int getRecordResponseCount(int topicid) {
		int count = 0;
		db.getCon();
		ResultSet rs = null;
		String sql=new String();
		if(topicid==0){
			 sql = "select count(id) from tb_response";
		}
		else sql = "select  count(id) from tb_response where topicid='" + topicid
				+ "'";
		try {
			rs = db.openStatement(sql);
			while (rs.next()) {
				count=rs.getInt(1);
			}
		} catch (Exception e) {
		}
		db.colse();
		return  count%Constants.TOPIC_PAGE_SIZE==0? count/Constants.TOPIC_PAGE_SIZE:count/Constants.TOPIC_PAGE_SIZE+1;

	}
    //�鿴���е�����
	public  static List<TopicList> getTotalRecordTopic(int pageid) {
		ArrayList<TopicList> list = new ArrayList<TopicList>();
		db.getCon();
		ResultSet rs = null;
		String sql = "select * from tb_topic   order by id desc limit " + pageid
				* Constants.TOPIC_PAGE_SIZE + "," + Constants.TOPIC_PAGE_SIZE;
		try {
			rs = db.openStatement(sql);
			while (rs.next()) {
				TopicList t = new TopicList();
				t.setId(rs.getInt("id"));
				t.setTitle(rs.getString("title"));
				t.setForumid(rs.getInt("forumid"));
				t.setForumname(rs.getString("forumname"));
				t.setContent(rs.getString("content"));
				t.setAuthor(rs.getString("author"));
				t.setSubmittime(rs.getString("submittime"));
				t.setXq(rs.getString("xq"));
				list.add(t);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		db.colse();
		return list;
	}
    //ɾ��ĳ��
	public  static boolean DelRecord(int id) {
		boolean b;
		db.getCon();
		String sql = "delete from tb_topic where id='" + id + "'";
		b = db.openUpateStatement(sql);
		db.colse();
		return b;
	}

	public  static boolean DelRecordforForumn(String forumid) {// ����ɾ��ĳ����̳��������Ӧ�����̳������Ҳ��Ҫ��ɾ��
		boolean b;
		db.getCon();
		String id = null;
		String sql2 = "select id from tb_topic where forumid='" + forumid + "'";
		String sql = "delete from tb_topic where forumid='" + forumid + "'";
		ResultSet rs = db.openStatement(sql2);
		try {
			while (rs.next()) {
				id = rs.getString(1);
				String sql3 = "delete from tb_response where topicid='" + id
						+ "'";// ���ظ����������̳�ظ�ɾ��
				System.out.println(sql3);
				System.out.println("TopicList" + db.openUpateStatement(sql3));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		b = db.openUpateStatement(sql);
		db.colse();
		return b;
	}
  //��������
	public  static boolean UpdateRq(String id) {
		boolean b;
		db.getCon();
		String sql = "update  tb_topic set rq=rq+1 where id='" + id + "'";
		b = db.openUpateStatement(sql);
		db.colse();
		return b;
	}
   //ɾ��ĳ�˷���������
	public static  boolean delRecordforUser(String name) {
		boolean b;
		db.getCon();
		String sql = "delete from tb_topic where author='" + name + "'";
		b = db.openUpateStatement(sql);
		db.colse();
		return b;
	}
//  ���ĳ������Ϣ
	public static List getTotalRecordTopic(String id) {
		List list = new ArrayList();
		db.getCon();
		ResultSet rs = null;
		String sql = "select * from tb_topic where id='" + id + "'";
		try {
			rs = db.openStatement(sql);
			while (rs.next()) {
				TopicList t = new TopicList();
				t.setId(rs.getInt("id"));
				t.setTitle(rs.getString("title"));
				t.setForumid(rs.getInt("forumid"));
				t.setForumname(rs.getString("forumname"));
				t.setContent(rs.getString("content"));
				t.setAuthor(rs.getString("author"));
				t.setSubmittime(rs.getString("submittime"));
				t.setXq(rs.getString("xq"));
				list.add(t);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.colse();
		return list;
	}
}
