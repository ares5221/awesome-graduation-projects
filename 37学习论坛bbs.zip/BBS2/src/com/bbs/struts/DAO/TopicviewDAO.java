package com.bbs.struts.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TopicviewDAO {
	private static Database db = Database.getDatebase();

	public static Topicview getTopicview(int id) throws SQLException {
		String sql = "SELECT * FROM topicview WHERE id=" + id;
		db.getCon();
		Topicview tview = new Topicview();
		ResultSet rs = db.openStatement(sql);
		if (rs.next()) {
			tview.setId(rs.getInt("id"));
			tview.setContent(rs.getString("content"));
			tview.setAuthor(rs.getString("author"));
			tview.setSubmittime(rs.getString("submittime"));
			tview.setForumid(rs.getString("forumid"));
			tview.setTitle(rs.getString("title"));
			tview.setXq(rs.getString("xq"));
			tview.setRq(rs.getString("rq"));
			tview.setForumname(rs.getString("forumname"));
			tview.setSex(rs.getString("sex"));
			tview.setEmail(rs.getString("email"));
			tview.setOicq(rs.getString("oicq"));
			tview.setSignature(rs.getString("signature"));
			tview.setGrade(rs.getString("grade"));
			tview.setLxdz(rs.getString("lxdz"));
			tview.setTx(rs.getString("tx"));
			tview.setGrzy(rs.getString("grzy"));
			tview.setRealname(rs.getString("realname"));
		}
		rs.close();
		db.colse();
		return tview;
	}
}
