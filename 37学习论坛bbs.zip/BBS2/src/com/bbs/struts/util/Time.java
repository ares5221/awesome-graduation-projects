package com.bbs.struts.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Time {
	public static String getCurrentTime(){
	      Date   date   =   new   Date();
          SimpleDateFormat   df   =   new   SimpleDateFormat( "yyyy-MM-dd HH:mm:ss ");
          return df.format(date);
	}
	public   static   void   main(String   args[])   { 
		getCurrentTime();
	}
}
