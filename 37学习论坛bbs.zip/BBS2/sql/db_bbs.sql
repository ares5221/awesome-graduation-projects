/*
Navicat MySQL Data Transfer

Source Server         : ares
Source Server Version : 50132
Source Host           : localhost:3306
Source Database       : db_bbs

Target Server Type    : MYSQL
Target Server Version : 50132
File Encoding         : 65001

Date: 2015-04-28 10:49:03
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tb_forum`
-- ----------------------------
DROP TABLE IF EXISTS `tb_forum`;
CREATE TABLE `tb_forum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `forumname` varchar(20) NOT NULL,
  `manager` varchar(100) DEFAULT NULL,
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of tb_forum
-- ----------------------------
INSERT INTO `tb_forum` VALUES ('1', 'ASP', 'TSoft', '2010-10-27 00:58:08');
INSERT INTO `tb_forum` VALUES ('2', 'PHP', 'fish', '2010-10-27 00:58:08');
INSERT INTO `tb_forum` VALUES ('3', 'C#', 'fish', '2010-10-27 00:58:08');
INSERT INTO `tb_forum` VALUES ('4', '.NET', 'fish', '2010-10-27 00:58:08');
INSERT INTO `tb_forum` VALUES ('6', 'JSP', 'fish', '2010-10-27 00:58:08');
INSERT INTO `tb_forum` VALUES ('7', 'C语言', 'TSoft', '2010-11-11 01:13:45');

-- ----------------------------
-- Table structure for `tb_response`
-- ----------------------------
DROP TABLE IF EXISTS `tb_response`;
CREATE TABLE `tb_response` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) NOT NULL,
  `content` text,
  `author` varchar(20) NOT NULL,
  `submittime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `topicid` int(4) NOT NULL,
  `topicname` varchar(100) DEFAULT NULL,
  `xq` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_tb_response` (`topicid`),
  CONSTRAINT `FK_tb_response` FOREIGN KEY (`topicid`) REFERENCES `tb_topic` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of tb_response
-- ----------------------------
INSERT INTO `tb_response` VALUES ('1', '测试1', '测试\r\n测试\r\n测试\n测试\r\n测试', 'gg', '2010-11-04 00:37:32', '1', '测试', '1.gif');
INSERT INTO `tb_response` VALUES ('115', '测试2', '测试2', 'gg', '2010-11-06 23:22:11', '1', '测试', '1.gif');
INSERT INTO `tb_response` VALUES ('116', '测试3', '测试3', 'gg', '2010-11-06 23:23:57', '1', '测试', '1.gif');
INSERT INTO `tb_response` VALUES ('118', '测试3', '测试5', 'gg', '2010-11-06 23:51:57', '1', '测试', '4.gif');
INSERT INTO `tb_response` VALUES ('119', '测试3', '测试5', 'gg', '2010-11-06 23:53:22', '1', '测试', '13.gif');
INSERT INTO `tb_response` VALUES ('120', 'dfh', '换地方和', 'gg', '2010-11-10 00:12:28', '13', 'dcgh', '1.gif');
INSERT INTO `tb_response` VALUES ('121', '试试', '生生世世', 'gg', '2010-11-11 15:33:09', '13', 'dcgh', '3.gif');
INSERT INTO `tb_response` VALUES ('122', '最后测试', '最后测试', 'ss', '2010-11-14 19:11:59', '24', '测试分页', '1.gif');
INSERT INTO `tb_response` VALUES ('123', '哈哈', '哈哈', 'test', '2015-04-28 10:16:58', '26', 'test', '1.gif');
INSERT INTO `tb_response` VALUES ('124', '哈哈', '哈哈', 'test', '2015-04-28 10:17:01', '26', 'test', '1.gif');
INSERT INTO `tb_response` VALUES ('125', '哈哈', '哈哈刚刚刚刚', 'test', '2015-04-28 10:17:30', '26', 'test', '1.gif');

-- ----------------------------
-- Table structure for `tb_topic`
-- ----------------------------
DROP TABLE IF EXISTS `tb_topic`;
CREATE TABLE `tb_topic` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `content` text,
  `author` varchar(20) NOT NULL,
  `submittime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `forumid` int(4) DEFAULT '1',
  `title` varchar(300) NOT NULL,
  `xq` varchar(30) NOT NULL,
  `rq` int(4) DEFAULT '0',
  `forumname` varchar(20) DEFAULT 'ASP',
  PRIMARY KEY (`id`),
  KEY `FK_tb_topic` (`forumid`),
  CONSTRAINT `FK_tb_topic` FOREIGN KEY (`forumid`) REFERENCES `tb_forum` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of tb_topic
-- ----------------------------
INSERT INTO `tb_topic` VALUES ('1', '测试', 'ss', '2007-08-20 00:00:00', '1', '测试', '1.gif', '8', 'ASP');
INSERT INTO `tb_topic` VALUES ('10', 'sssssssss', 'gg', '2010-11-07 16:06:32', '1', 'sss', '5.gif', '0', 'ASP');
INSERT INTO `tb_topic` VALUES ('12', 'gfgfjhfgfgj', 'gg', '2010-11-07 16:07:44', '1', 'dfhg', '0.gif', '0', 'ASP');
INSERT INTO `tb_topic` VALUES ('13', 'sdghfdh', 'gg', '2010-11-07 16:10:34', '1', 'dcgh', '9.gif', '0', 'ASP');
INSERT INTO `tb_topic` VALUES ('21', '的撒个花', 'gg', '2010-11-07 16:42:49', '4', '大使馆和', '1.gif', '0', '.NET');
INSERT INTO `tb_topic` VALUES ('24', '测试分页', 'ss', '2010-11-11 16:36:03', '1', '测试分页', '1.gif', '0', 'ASP');
INSERT INTO `tb_topic` VALUES ('25', '最后测试发帖发帖在C语言区', 'ss', '2010-11-14 19:13:53', '1', '最后测试发帖', '1.gif', '0', 'ASP');
INSERT INTO `tb_topic` VALUES ('26', '最新文档', 'test', '2015-04-28 10:16:24', '1', 'test', '0.gif', '0', 'ASP');

-- ----------------------------
-- Table structure for `tb_user`
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `sex` varchar(2) NOT NULL,
  `email` varchar(50) NOT NULL,
  `oicq` varchar(20) DEFAULT NULL,
  `signature` varchar(300) DEFAULT NULL,
  `grade` varchar(20) DEFAULT NULL,
  `lxdz` varchar(50) DEFAULT NULL,
  `tx` varchar(30) DEFAULT NULL,
  `grzy` varchar(50) DEFAULT NULL,
  `realname` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO `tb_user` VALUES ('1', 'TSoft', '111', '1', 'xiaoyu*****@sina.com', '123', 'test', 'admin', 'test', '2.gif', 'test', 'test');
INSERT INTO `tb_user` VALUES ('3', 'ss', 'ss', '女', '373941312@qq.com', '2345435646', '', 'user', 'ssssssssssss', '1.gif', 'http://lcoalhost', 'ss');
INSERT INTO `tb_user` VALUES ('4', 'hr', 'hr', '女', '2343556@qq.com', '2343556', '', 'user', '大概', '0.gif', 'http://hi.csdn.net/chenzhiqin20', '和人');
INSERT INTO `tb_user` VALUES ('5', 'test', '123', '男', '8888888@qq.com', '8888888', 'test', 'admin', '山西', '18888888888, 15.gif', '', 'test');

-- ----------------------------
-- View structure for `responseview`
-- ----------------------------
DROP VIEW IF EXISTS `responseview`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `responseview` AS select `tb_response`.`id` AS `rid`,`tb_response`.`title` AS `title`,`tb_response`.`content` AS `content`,`tb_response`.`author` AS `author`,`tb_response`.`submittime` AS `submittime`,`tb_response`.`topicid` AS `topicid`,`tb_response`.`topicname` AS `topicname`,`tb_response`.`xq` AS `xq`,`tb_user`.`username` AS `username`,`tb_user`.`password` AS `password`,`tb_user`.`sex` AS `sex`,`tb_user`.`email` AS `email`,`tb_user`.`oicq` AS `oicq`,`tb_user`.`signature` AS `signature`,`tb_user`.`grade` AS `grade`,`tb_user`.`lxdz` AS `lxdz`,`tb_user`.`tx` AS `tx`,`tb_user`.`grzy` AS `grzy`,`tb_user`.`realname` AS `realname` from (`tb_response` left join `tb_user` on((`tb_response`.`author` = `tb_user`.`username`))) ;

-- ----------------------------
-- View structure for `topicview`
-- ----------------------------
DROP VIEW IF EXISTS `topicview`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `topicview` AS select `tb_topic`.`id` AS `id`,`tb_topic`.`content` AS `content`,`tb_topic`.`author` AS `author`,`tb_topic`.`submittime` AS `submittime`,`tb_topic`.`forumid` AS `forumid`,`tb_topic`.`title` AS `title`,`tb_topic`.`xq` AS `xq`,`tb_topic`.`rq` AS `rq`,`tb_topic`.`forumname` AS `forumname`,`tb_user`.`username` AS `username`,`tb_user`.`password` AS `password`,`tb_user`.`sex` AS `sex`,`tb_user`.`email` AS `email`,`tb_user`.`oicq` AS `oicq`,`tb_user`.`signature` AS `signature`,`tb_user`.`grade` AS `grade`,`tb_user`.`lxdz` AS `lxdz`,`tb_user`.`tx` AS `tx`,`tb_user`.`grzy` AS `grzy`,`tb_user`.`realname` AS `realname` from (`tb_topic` left join `tb_user` on((`tb_topic`.`author` = `tb_user`.`username`))) ;
