function change_B(){
    var text = $("#text");
    var v = text.val();
    if (v != "") {
    
        text.css({
            "font-weight": "bold"
        });
    }
    document.getElementsByName("rp.xq").getAttribute("");
}

function change_I(){
    var text = $("#text");
    var v = text.val();
    if (v != "") {
        var v2 = "<em>" + v + "</em>";
        text.html(v2);
    }
}

function change_U(){
    var text = $("#text");
    var v = text.html();
    
    if (v != "") {
        var v2 = "<U>" + v + "</U>";
        text.html(v2);
    }
}

function change_color(){
    var text = $("#text");
    var color = $("#color").val();
    var v = text.val();
    if (v != "") {
        text.css({
            "color": color
        });
    }
}

function change_size(){
    var text = $("#text");
    var size = $("#size").val();
    var v = text.val();
    if (v != "") {
        text.css({
            "font-size": size
        });
    }
}

function change_font(){

    var text = $("#text");
    var font = $("#font").val();
    var v = text.val();
    if (v != "") {
        text.css({
            "font-family": font
        });
        
    }
}
