var Obj = ''
document.onmouseup = MUp
document.onmousemove = MMove

function MDown(Object){
    Obj = Object.id;
    document.all(Obj).setCapture();
    pX = event.x - document.all(Obj).style.pixelLeft;
    pY = event.y - document.all(Obj).style.pixelTop;
}

function MMove(){
    if (Obj != '') {
        document.all(Obj).style.left = event.x - pX;
        document.all(Obj).style.top = event.y - pY;
    }
}

function MUp(){
    if (Obj != '') {
        document.all(Obj).releaseCapture();
        Obj = '';
    }
}

//��ʾ���ڵķ���
function showwin(){
    var winNode = $("#massage_box");
    winNode.css("visibility", "visible");
}

//���ش��ڵķ���
function hide(){
    var winNode = $("#massage_box");
    winNode.css("visibility", "hidden");
}


