package com.club.entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * ClubNews entity. @author MyEclipse Persistence Tools
 */

public class ClubNews implements java.io.Serializable {

	// Fields

	private Integer newsId;//������
	private Club club;//������������
	private String newsTitle;//�������
	private String newsContent;//��������
	private Date newsTime;//���淢��ʱ��
	private String newsUser;//���淢����
	private Set clubMessages = new HashSet(0);
	private Set clubPictures = new HashSet(0);

	// Constructors

	/** default constructor */
	public ClubNews() {
	}

	/** full constructor */
	public ClubNews(Club club, String newsTitle, String newsContent,
			Date newsTime, String newsUser, Set clubMessages, Set clubPictures) {
		this.club = club;
		this.newsTitle = newsTitle;
		this.newsContent = newsContent;
		this.newsTime = newsTime;
		this.newsUser = newsUser;
		this.clubMessages = clubMessages;
		this.clubPictures = clubPictures;
	}

	// Property accessors

	public Integer getNewsId() {
		return this.newsId;
	}

	public void setNewsId(Integer newsId) {
		this.newsId = newsId;
	}

	public Club getClub() {
		return this.club;
	}

	public void setClub(Club club) {
		this.club = club;
	}

	public String getNewsTitle() {
		return this.newsTitle;
	}

	public void setNewsTitle(String newsTitle) {
		this.newsTitle = newsTitle;
	}

	public String getNewsContent() {
		return this.newsContent;
	}

	public void setNewsContent(String newsContent) {
		this.newsContent = newsContent;
	}

	public Date getNewsTime() {
		return this.newsTime;
	}

	public void setNewsTime(Date newsTime) {
		this.newsTime = newsTime;
	}

	public String getNewsUser() {
		return this.newsUser;
	}

	public void setNewsUser(String newsUser) {
		this.newsUser = newsUser;
	}

	public Set getClubMessages() {
		return this.clubMessages;
	}

	public void setClubMessages(Set clubMessages) {
		this.clubMessages = clubMessages;
	}

	public Set getClubPictures() {
		return this.clubPictures;
	}

	public void setClubPictures(Set clubPictures) {
		this.clubPictures = clubPictures;
	}

}