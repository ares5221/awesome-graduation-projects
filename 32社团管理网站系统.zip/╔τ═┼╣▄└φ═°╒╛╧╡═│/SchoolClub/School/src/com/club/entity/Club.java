package com.club.entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**����ʵ����
 * Club entity. @author MyEclipse Persistence Tools
 */

public class Club implements java.io.Serializable {

	// Fields

	private Integer clubId;//���ű��
	private ClubUser clubUser;//���Ÿ�����
	private String clubName;//��������
	private Date clubDate;//���ų���ʱ��
	private String clubDescription;//������Ϣ
	private Integer clubAudit;//���������� 0��δ��� 1�������
	private Set clubUsers = new HashSet(0);
	private Set clubActivities = new HashSet(0);
	private Set clubNewses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Club() {
	}

	/** full constructor */
	public Club(ClubUser clubUser, String clubName, Date clubDate,
			String clubDescription, Integer clubAudit, Set clubUsers,
			Set clubActivities, Set clubNewses) {
		this.clubUser = clubUser;
		this.clubName = clubName;
		this.clubDate = clubDate;
		this.clubDescription = clubDescription;
		this.clubAudit = clubAudit;
		this.clubUsers = clubUsers;
		this.clubActivities = clubActivities;
		this.clubNewses = clubNewses;
	}

	// Property accessors

	public Integer getClubId() {
		return this.clubId;
	}

	public void setClubId(Integer clubId) {
		this.clubId = clubId;
	}

	public ClubUser getClubUser() {
		return this.clubUser;
	}

	public void setClubUser(ClubUser clubUser) {
		this.clubUser = clubUser;
	}

	public String getClubName() {
		return this.clubName;
	}

	public void setClubName(String clubName) {
		this.clubName = clubName;
	}

	public Date getClubDate() {
		return this.clubDate;
	}

	public void setClubDate(Date clubDate) {
		this.clubDate = clubDate;
	}

	public String getClubDescription() {
		return this.clubDescription;
	}

	public void setClubDescription(String clubDescription) {
		this.clubDescription = clubDescription;
	}

	public Integer getClubAudit() {
		return this.clubAudit;
	}

	public void setClubAudit(Integer clubAudit) {
		this.clubAudit = clubAudit;
	}

	public Set getClubUsers() {
		return this.clubUsers;
	}

	public void setClubUsers(Set clubUsers) {
		this.clubUsers = clubUsers;
	}

	public Set getClubActivities() {
		return this.clubActivities;
	}

	public void setClubActivities(Set clubActivities) {
		this.clubActivities = clubActivities;
	}

	public Set getClubNewses() {
		return this.clubNewses;
	}

	public void setClubNewses(Set clubNewses) {
		this.clubNewses = clubNewses;
	}

}