package com.club.entity;

import java.util.HashSet;
import java.util.Set;

/**���ų�Աʵ����
 * ClubUser entity. @author MyEclipse Persistence Tools
 */

public class ClubUser implements java.io.Serializable {

	// Fields

	private Integer userId;//�û����
	private Club club;//�û���������
	private ClubType clubType;//�û�����
	private String userName;//�û���
	private String userPwd;//�û�����
	private String userSex;//�û��Ա�
	private String userRealname;//�û���ʵ����
	private Integer userAge;//�û�����
	private String userClass;//�༶
	private String userPhone;//��ϵ�绰
	private String userAddress;//סַ
	private String userPicture;//ͷ��
	private String userNick;//�ǳ�
	private Set clubMessages = new HashSet(0);
	private Set clubs = new HashSet(0);//
	private Set clubActivities = new HashSet(0);

	// Constructors

	/** default constructor */
	public ClubUser() {
	}

	/** full constructor */
	public ClubUser(Club club, ClubType clubType, String userName,
			String userPwd, String userSex, String userRealname,
			Integer userAge, String userClass, String userPhone,
			String userAddress, String userPicture, String userNick,
			Set clubMessages, Set clubs, Set clubActivities) {
		this.club = club;
		this.clubType = clubType;
		this.userName = userName;
		this.userPwd = userPwd;
		this.userSex = userSex;
		this.userRealname = userRealname;
		this.userAge = userAge;
		this.userClass = userClass;
		this.userPhone = userPhone;
		this.userAddress = userAddress;
		this.userPicture = userPicture;
		this.userNick = userNick;
		this.clubMessages = clubMessages;
		this.clubs = clubs;
		this.clubActivities = clubActivities;
	}

	// Property accessors

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Club getClub() {
		return this.club;
	}

	public void setClub(Club club) {
		this.club = club;
	}

	public ClubType getClubType() {
		return this.clubType;
	}

	public void setClubType(ClubType clubType) {
		this.clubType = clubType;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPwd() {
		return this.userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public String getUserSex() {
		return this.userSex;
	}

	public void setUserSex(String userSex) {
		this.userSex = userSex;
	}

	public String getUserRealname() {
		return this.userRealname;
	}

	public void setUserRealname(String userRealname) {
		this.userRealname = userRealname;
	}

	public Integer getUserAge() {
		return this.userAge;
	}

	public void setUserAge(Integer userAge) {
		this.userAge = userAge;
	}

	public String getUserClass() {
		return this.userClass;
	}

	public void setUserClass(String userClass) {
		this.userClass = userClass;
	}

	public String getUserPhone() {
		return this.userPhone;
	}

	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}

	public String getUserAddress() {
		return this.userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public String getUserPicture() {
		return this.userPicture;
	}

	public void setUserPicture(String userPicture) {
		this.userPicture = userPicture;
	}

	public String getUserNick() {
		return this.userNick;
	}

	public void setUserNick(String userNick) {
		this.userNick = userNick;
	}

	public Set getClubMessages() {
		return this.clubMessages;
	}

	public void setClubMessages(Set clubMessages) {
		this.clubMessages = clubMessages;
	}

	public Set getClubs() {
		return this.clubs;
	}

	public void setClubs(Set clubs) {
		this.clubs = clubs;
	}

	public Set getClubActivities() {
		return this.clubActivities;
	}

	public void setClubActivities(Set clubActivities) {
		this.clubActivities = clubActivities;
	}

}