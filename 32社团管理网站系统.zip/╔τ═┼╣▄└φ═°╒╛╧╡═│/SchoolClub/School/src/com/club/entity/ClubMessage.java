package com.club.entity;

import java.util.Date;

/**��������ʵ����
 * ClubMessage entity. @author MyEclipse Persistence Tools
 */

public class ClubMessage implements java.io.Serializable {

	// Fields

	private Integer msgId;//���Ա��
	private ClubUser clubUser;//������
	private ClubNews clubNews;//������������
	private String msgContent;//��������
	private Date msgTime;//����ʱ��

	// Constructors

	/** default constructor */
	public ClubMessage() {
	}

	/** full constructor */
	public ClubMessage(ClubUser clubUser, ClubNews clubNews, String msgContent,
			Date msgTime) {
		this.clubUser = clubUser;
		this.clubNews = clubNews;
		this.msgContent = msgContent;
		this.msgTime = msgTime;
	}

	// Property accessors

	public Integer getMsgId() {
		return this.msgId;
	}

	public void setMsgId(Integer msgId) {
		this.msgId = msgId;
	}

	public ClubUser getClubUser() {
		return this.clubUser;
	}

	public void setClubUser(ClubUser clubUser) {
		this.clubUser = clubUser;
	}

	public ClubNews getClubNews() {
		return this.clubNews;
	}

	public void setClubNews(ClubNews clubNews) {
		this.clubNews = clubNews;
	}

	public String getMsgContent() {
		return this.msgContent;
	}

	public void setMsgContent(String msgContent) {
		this.msgContent = msgContent;
	}

	public Date getMsgTime() {
		return this.msgTime;
	}

	public void setMsgTime(Date msgTime) {
		this.msgTime = msgTime;
	}

}