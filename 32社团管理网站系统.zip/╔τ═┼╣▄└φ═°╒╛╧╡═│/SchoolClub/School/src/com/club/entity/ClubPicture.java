package com.club.entity;

/**
 * ClubPicture entity. @author MyEclipse Persistence Tools
 */

public class ClubPicture implements java.io.Serializable {

	// Fields

	private Integer picId;//ͼƬ���
	private ClubNews clubNews;//ͼƬ��������
	private String picUrl;//ͼƬ��ַ

	// Constructors

	/** default constructor */
	public ClubPicture() {
	}

	/** full constructor */
	public ClubPicture(ClubNews clubNews, String picUrl) {
		this.clubNews = clubNews;
		this.picUrl = picUrl;
	}

	// Property accessors

	public Integer getPicId() {
		return this.picId;
	}

	public void setPicId(Integer picId) {
		this.picId = picId;
	}

	public ClubNews getClubNews() {
		return this.clubNews;
	}

	public void setClubNews(ClubNews clubNews) {
		this.clubNews = clubNews;
	}

	public String getPicUrl() {
		return this.picUrl;
	}

	public void setPicUrl(String picUrl) {
		this.picUrl = picUrl;
	}

}