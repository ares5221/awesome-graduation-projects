package com.club.entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**���Żʵ����
 * ClubActivity entity. @author MyEclipse Persistence Tools
 */

public class ClubActivity implements java.io.Serializable {

	// Fields

	private Integer actId;//����
	private Club club;//���������
	private ClubUser clubUser;//�������
	private String actTitle;//�����
	private String actContent;//�����
	private String actAddress;//��ص�
	private Date actTime;//�ʱ��
	private String actPic;//�����
	private Integer actAudit;//�������  0:δ��� 1�������

	// Constructors

	/** default constructor */
	public ClubActivity() {
	}

	/** full constructor */
	public ClubActivity(Club club, ClubUser clubUser, String actTitle,
			String actContent, String actAddress, Date actTime,
			Integer actAudit) {
		this.club = club;
		this.clubUser = clubUser;
		this.actTitle = actTitle;
		this.actContent = actContent;
		this.actAddress = actAddress;
		this.actTime = actTime;
		this.actAudit = actAudit;
	}

	// Property accessors

	public Integer getActId() {
		return this.actId;
	}

	public void setActId(Integer actId) {
		this.actId = actId;
	}

	public Club getClub() {
		return this.club;
	}

	public void setClub(Club club) {
		this.club = club;
	}

	public ClubUser getClubUser() {
		return this.clubUser;
	}

	public void setClubUser(ClubUser clubUser) {
		this.clubUser = clubUser;
	}

	public String getActTitle() {
		return this.actTitle;
	}

	public void setActTitle(String actTitle) {
		this.actTitle = actTitle;
	}

	public String getActContent() {
		return this.actContent;
	}

	public void setActContent(String actContent) {
		this.actContent = actContent;
	}

	public String getActAddress() {
		return this.actAddress;
	}

	public void setActAddress(String actAddress) {
		this.actAddress = actAddress;
	}

	public Date getActTime() {
		return this.actTime;
	}

	public void setActTime(Date actTime) {
		this.actTime = actTime;
	}

	public Integer getActAudit() {
		return this.actAudit;
	}

	public void setActAudit(Integer actAudit) {
		this.actAudit = actAudit;
	}

	public String getActPic() {
		return actPic;
	}

	public void setActPic(String actPic) {
		this.actPic = actPic;
	}
	

}