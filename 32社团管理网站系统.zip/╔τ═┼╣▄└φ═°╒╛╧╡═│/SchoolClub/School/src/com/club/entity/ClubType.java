package com.club.entity;

import java.util.HashSet;
import java.util.Set;

/**�û���ɫʵ����
 * ClubType entity. @author MyEclipse Persistence Tools
 */

public class ClubType implements java.io.Serializable {

	// Fields

	private Integer typeId;//��ɫid
	private String typeName;//��ɫ����  1.ϵͳ����Ա  2.���Ź���Ա  3.��ͨ�û�  4.���ų�Ա
	private Set clubUsers = new HashSet(0);

	// Constructors

	/** default constructor */
	public ClubType() {
	}

	/** full constructor */
	public ClubType(String typeName, Set clubUsers) {
		this.typeName = typeName;
		this.clubUsers = clubUsers;
	}

	// Property accessors

	public Integer getTypeId() {
		return this.typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getTypeName() {
		return this.typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public Set getClubUsers() {
		return this.clubUsers;
	}

	public void setClubUsers(Set clubUsers) {
		this.clubUsers = clubUsers;
	}

}