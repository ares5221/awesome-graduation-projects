package com.club.action;

import java.io.File;
import java.util.List;

import org.apache.struts2.ServletActionContext;


import com.club.entity.Club;
import com.club.entity.ClubActivity;
import com.club.entity.ClubNews;
import com.club.entity.ClubPicture;
import com.club.entity.ClubUser;
import com.club.service.ActivityService;
import com.club.service.ClubService;
import com.club.service.NewsService;
import com.club.service.PictureService;
import com.club.service.UserInfoService;
import com.club.service.impl.ActivityServiceImpl;
import com.club.service.impl.ClubServiceImpl;
import com.club.service.impl.NewsServiceImpl;
import com.club.service.impl.PictureServiceImpl;
import com.club.service.impl.UserInfoServiceImpl;
import com.opensymphony.xwork2.Preparable;

/**
 * ���Żaction��
 * 
 * @author Administrator
 * 
 */
public class ActivityAction extends BaseAction implements Preparable {
	private ClubActivity activity;// ����һ�������
	private ActivityService service = null;
	private NewsService nservice=null;
	private UserInfoService uservice = null;
	private PictureService pservice=null;
	private ClubService cservice=null;
	private String clubId;
	public String getClubId() {
		return clubId;
	}

	public void setClubId(String clubId) {
		this.clubId = clubId;
	}

	private Club club;// ����һ�����Ŷ���
	private String page;// ҳ��
	private String audit;
	private File pic;// �ϴ�ͼƬ�ļ�
	private String picFileName;// �ϴ�ͼƬ�ļ�����

	public File getPic() {
		return pic;
	}

	public void setPic(File pic) {
		this.pic = pic;
	}

	public String getPicFileName() {
		return picFileName;
	}

	public void setPicFileName(String picFileName) {
		this.picFileName = picFileName;
	}

	public String getAudit() {
		return audit;
	}

	public void setAudit(String audit) {
		this.audit = audit;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	private final static int PAGESIZE = 5;

	public Club getClub() {
		return club;
	}

	public void setClub(Club club) {
		this.club = club;
	}

	public ClubActivity getActivity() {
		return activity;
	}

	public void setActivity(ClubActivity activity) {
		this.activity = activity;
	}

	// ��ʾ�������Ż
	public String list() {
		int pageIndex = 1;
		if (page != null && !"".equals(page)) {
			pageIndex = Integer.valueOf(page);
		}
		List<ClubActivity> list = null;
		int totalPage = 0;
		ClubUser user = this.getSessionUser();
		if (user.getClubType().getTypeId() == 1) {
			if (audit != null && audit.length() > 0) {
				list = service.selAllActsByPageAudit1(pageIndex, PAGESIZE);
				totalPage = service.getActsTotalPageAudit1(PAGESIZE);
			} else {
				list = service.selAllActsByPageAudit0(pageIndex, PAGESIZE);
				totalPage = service.getActsTotalPageAudit0(PAGESIZE);
			}
		} else {
			list = service.selAllActsByPageClub(pageIndex, PAGESIZE, user
					.getClub().getClubId());
			totalPage = service.getActsTotalPageClub(PAGESIZE, user.getClub()
					.getClubId());
		}

		this.getPutInRequet("list", list);
		this.getPutInRequet("totalPage", totalPage);
		this.getPutInRequet("page", pageIndex);
		return "list";
	}

	// �޸Ļǰ��׼��
	public String toEdit() {
		activity = service.getActivityById(activity.getActId());
		List<ClubUser> userList = uservice.selAllUsers(this.getSessionUser()
				.getClub().getClubId(), 4);
		this.getPutInRequet("userList", userList);
		this.getPutInRequet("activity", activity);
		return "toedit";
	}

	// �޸Ļ
	public String edit() {
		int row = 0;
		ClubUser user = this.getSessionUser();
		if(pic!=null){
			
	    	   String appPath = ServletActionContext.getServletContext().getRealPath(
				"/");

		String storePath = "userfiles/" + user.getUserName() + "/"
				+ com.club.util.FileUtils.fileName(picFileName);
		File f = new File(appPath + "/userfiles/" + user.getUserName());
		if (!f.exists()) {
			f.mkdirs();
		}
		pic.renameTo(new File(appPath + "/" + storePath));
		activity.setActPic(storePath);
			}else{
				ClubActivity ac=service.getActivityById(activity.getActId());
				if(ac.getActPic()!=null&&ac.getActPic().length()>0){
					activity.setActPic(ac.getActPic());
				}
			
			}
		row = service.updateActivity(activity);
		if (row > 0) {
			return "edit";
		} else {
			  this.getPutInRequet("message", "�޸�ʧ��!<a href='javascript:history.back();'>����</a>");
			return "message";
		}
	}

	// ���ӻǰ��׼��
	public String toAdd() {
		List<ClubUser> userList = uservice.selAllUsers(this.getSessionUser()
				.getClub().getClubId(), 4);
		this.getPutInRequet("userList", userList);
		return "toadd";
	}

	// ���ӻ
	public String add() {
		ClubUser user = this.getSessionUser();
		
		// ͼƬ�ϴ�
       if(pic!=null){
			
    	   String appPath = ServletActionContext.getServletContext().getRealPath(
			"/");

	String storePath = "userfiles/" + user.getUserName() + "/"
			+ com.club.util.FileUtils.fileName(picFileName);
	File f = new File(appPath + "/userfiles/" + user.getUserName());
	if (!f.exists()) {
		f.mkdirs();
	}
	pic.renameTo(new File(appPath + "/" + storePath));
	activity.setActPic(storePath);
		}
		
	ClubUser u=uservice.getUserById(activity.getClubUser().getUserId());
		activity.setActAudit(0);
		activity.setClubUser(u);
		activity.setClub(user.getClub());
		int row = 0;
		row = service.insertActivity(activity);
		if (row > 0) {
			return "add";
		} else {
			 this.getPutInRequet("message", "����ʧ��!<a href='javascript:history.back();'>����</a>");
			 return "message";
		}
	}

	// �鿴��ϸ��Ϣ
	public String detail() {
		activity = service.getActivityById(activity.getActId());
		return "detail";
	}

	// ɾ���
	public String del() {
		int row = 0;
		row = service.deleteActivity(activity.getActId());
		if (row > 0) {

			return "del";
		} else {
			 this.getPutInRequet("message", "ɾ��ʧ��!<a href='javascript:history.back();'>����</a>");
			return "message";
		}
	}

	

	/**
	 * ���ͨ��һ�����Ϣ
	 * 
	 * @return
	 */
	public String audit() {
		ClubActivity checkActivity = service.getActivityById(activity
				.getActId());
		checkActivity.setActAudit(1);
		int flag = service.updateActivity(checkActivity);
		if (flag > 0) {
			return "audit";
		}
		else{
			
		 this.getPutInRequet("message", "���ʧ��!<a href='javascript:history.back();'>����</a>");
		return "message";
		}
	}

	public String show(){
		int totalPage=service.getActsTotalPageAudit1(PAGESIZE);		
		List<Club> clubList=cservice.selAllClubs();
		int pageIndex=1;
		if(page!=null&&page.length()>0){
			pageIndex=Integer.valueOf(page);
		}
		List<ClubActivity> actList=service.selAllActsByPageAudit1(pageIndex, PAGESIZE);
		if(clubId!=null&&clubId.length()>0){
			actList=service.selAllActsByPageClub(pageIndex, PAGESIZE, Integer.valueOf(clubId));
			totalPage=service.getActsTotalPageClub(PAGESIZE, Integer.valueOf(clubId));
			}
		List<ClubPicture> picList=pservice.selAllPictures();
		this.getPutInRequet("picList", picList);
		this.getPutInRequet("totalPage", totalPage);
		this.getPutInRequet("actList", actList);
		this.getPutInRequet("page", pageIndex);
		this.getPutInRequet("clubId", clubId);
		this.getPutInRequet("clubList", clubList);
		return "show";
	}

	public  String info(){
		List<ClubPicture> picList=pservice.selAllPictures();
		this.getPutInRequet("picList", picList);
		activity=service.getActivityById(activity.getActId());

		return "info";
	}
	// ��ʼ������
	public void prepare() throws Exception {
		service = new ActivityServiceImpl();
		uservice = new UserInfoServiceImpl();
		nservice=new NewsServiceImpl();
		cservice=new ClubServiceImpl();
		pservice=new PictureServiceImpl();

	}

}
