package com.club.action;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;


import net.sf.json.JSONObject;



import com.club.entity.Club;
import com.club.entity.ClubMessage;
import com.club.entity.ClubNews;
import com.club.entity.ClubUser;
import com.club.service.ClubService;
import com.club.service.MessageService;
import com.club.service.NewsService;
import com.club.service.UserInfoService;
import com.club.service.impl.ClubServiceImpl;
import com.club.service.impl.MessageServiceImpl;
import com.club.service.impl.NewsServiceImpl;
import com.club.service.impl.UserInfoServiceImpl;
import com.opensymphony.xwork2.Preparable;

public class MessageAction extends BaseAction implements Preparable {
	private ClubMessage message;// ����һ�����Զ���
	private MessageService service = null;
	public UserInfoService uservice = null;
	private ClubNews news;// ����һ�����Ź������
	private ClubUser user;


	public ClubUser getUser() {
		return user;
	}

	public void setUser(ClubUser user) {
		this.user = user;
	}

	private Club club;// ����һ�����Ŷ���
	private String page;// ҳ��
	private ClubService clubService = null;// ����һ������ҵ������
	private NewsService newsService = null;// ����һ�������ҵ������
	private final static int PAGESIZE = 3;

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public Club getClub() {
		return club;
	}

	public void setClub(Club club) {
		this.club = club;
	}

	public ClubNews getNews() {
		return news;
	}

	public void setNews(ClubNews news) {
		this.news = news;
	}

	public ClubMessage getMessage() {
		return message;
	}

	public void setMessage(ClubMessage message) {
		this.message = message;
	}

	// ��ʾ��������������Ϣ
	public String dolist() {
		int pageIndex = 1;
		if (page != null && !"".equals(page)) {
			pageIndex = Integer.valueOf(page);
		}
		List<ClubMessage> list = service.selAllMsgsByPageNews(pageIndex,
				PAGESIZE, news.getNewsId());
		int totalPage = service.getTotalPageByNews(news.getNewsId(), PAGESIZE);
		this.getPutInRequet("list", list);
		this.getPutInRequet("totalPage", totalPage);
		this.getPutInRequet("page", pageIndex);
		return "list";
	}

	// �鿴����
	public String detail() {
		message = service.getMessageById(message.getMsgId());
		this.getPutInRequet("message", message);
		return "detail";
	}

	// ��������
	public String add() {
		try {
			message.setMsgContent(URLDecoder.decode(message.getMsgContent(), "UTF-8"));
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int row = 0;
		user=this.getSessionUser();
		message.setClubUser(user);
		message.setMsgTime(new Date());
		message.setClubNews(news);
		row = service.insertMessage(message);
		if (row > 0) {
				
					String jsonString="["; 
				
				jsonString+="{\"username\":\""+user.getUserNick()+"\",\"messagecontent\":\""
				  +message.getMsgContent()+"\",\"timeday\":\""+message.getMsgTime()+"\"}"; 
				  HttpServletResponse response=ServletActionContext.getResponse();
				  response.setCharacterEncoding("utf-8");
				  response.setContentType("text/html;charset=utf-8");
				  jsonString+="]"; 
				  System.out.println(jsonString);
				  try {
					  response.getWriter().write(jsonString); 
				  } catch (Exception e) { 
					  
				  }
			
			return NONE;
		} else {
			this.getPutInRequet("message", "����ʧ�ܣ�&nbsp;&nbsp;<a href='javascript:history.back();'style='color:red'>����</a>");
			return "msg";
		}
	}

	// ɾ������
	public String del() {
		int row = 0;
		row = service.deleteMessage(message.getMsgId());
		if (row > 0) {
			return "del";
		} else {
			this.getPutInRequet("message", "ɾ��ʧ��");
			return "del_error";
		}

	}

	/**
	 * ��ȡ���е����Ŷ�����Ҫ��ҳ������ʾ���ŵ���������
	 * 
	 * @return
	 */
	public String getClubName() {
		List<Club> clubs = clubService.selAllClubs();
		if (this.getSessionUser().getClubType().getTypeId() == 2) {
			clubs = clubService.selClubByAdminId(this.getSessionUser().getUserId());
			
		}
		this.getPutInRequet("clubs", clubs);
		return "list";
	}

	/**
	 * �õ�һ�������µ�5������棬���з�ҳЧ��
	 * 
	 * @return
	 * 
	 */
	public String getClubNews() {
		int pageIndex = 1;
		if (null != page && !"".equals(page)) {
			pageIndex = Integer.valueOf(page);
		}
		List<ClubNews> newsName = newsService.selAllNewsByPageClub(pageIndex,
				PAGESIZE, club.getClubId());
		int pageCount = newsService.getNewsCountByClub(club.getClubId());
		if (pageCount % PAGESIZE == 0) {
			pageCount = pageCount / PAGESIZE;
		} else {
			pageCount = pageCount / PAGESIZE + 1;
		}
		this.getPutInRequet("page", pageIndex);
		this.getPutInRequet("totalPage", pageCount);
		this.getPutInRequet("newsName", newsName);
		this.getPutInRequet("clubid", club.getClubId());
		/*
		 * String jsonString="["; for (ClubNews clubNews : newsName) {
		 * jsonString
		 * +="{\"newsname\":\""+clubNews.getNewsTitle()+"\",\"newsid\":\""
		 * +clubNews
		 * .getNewsId()+"\",\"page\":\""+pageIndex+"\",\"pagecount\":\""
		 * +pageCount+"\"},"; } HttpServletResponse
		 * response=ServletActionContext.getResponse();
		 * response.setCharacterEncoding("utf-8");
		 * response.setContentType("text/html;charset=utf-8");
		 * jsonString=jsonString.substring(0,jsonString.length()-1);
		 * jsonString+="]"; System.out.println(jsonString); try {
		 * response.getWriter().write(jsonString); } catch (IOException e) { //
		 * TODO Auto-generated catch block e.printStackTrace(); }
		 */
		return "newslist";
	}

	/**
	 * �õ�һ��������5��������Ϣ�����з�ҳЧ��
	 * 
	 * @return
	 */
	public String getNewsMessage() {
		int pageIndex = 1;
		if (null != page && !"".equals(page)) {
			pageIndex = Integer.valueOf(page);
		}
		List<ClubMessage> messageName = service.selAllMsgsByPageNews(pageIndex,
				PAGESIZE, news.getNewsId());
		int pageCount = service.getMsgsCountByNews(news.getNewsId());
		if (pageCount % PAGESIZE == 0) {
			pageCount = pageCount / PAGESIZE;
		} else {
			pageCount = pageCount / PAGESIZE + 1;
		}
		this.getPutInRequet("page", pageIndex);
		this.getPutInRequet("totalPage", pageCount);
		this.getPutInRequet("messagesName", messageName);
		this.getPutInRequet("newsid", news.getNewsId());
		return "messageslist";
	}

	/**
	 * ����һ������IDɾ��һ�����ԣ����ҷ��ص�һҳ
	 * 
	 * @return
	 */
	public String delone() {
		int flag = service.deleteMessage(message.getMsgId());
		if (flag > 0) {
			int pageIndex = 1;
			if (null != page && !"".equals(page)) {
				pageIndex = Integer.valueOf(page);
			}
			List<ClubMessage> messageName = service.selAllMsgsByPageNews(
					pageIndex, PAGESIZE, news.getNewsId());
			int pageCount = service.getMsgsCountByNews(news.getNewsId());
			if (pageCount % PAGESIZE == 0) {
				pageCount = pageCount / PAGESIZE;
			} else {
				pageCount = pageCount / PAGESIZE + 1;
			}
			this.getPutInRequet("page", pageIndex);
			this.getPutInRequet("totalPage", pageCount);
			this.getPutInRequet("messagesName", messageName);
			this.getPutInRequet("newsid", news.getNewsId());
			return "messageslist";
		} else {
			return "del_error";
		}

	}

	// ��ʼ������
	public void prepare() throws Exception {
		service = new MessageServiceImpl();
		uservice = new UserInfoServiceImpl();
		clubService = new ClubServiceImpl();
		newsService = new NewsServiceImpl();
	}

}
