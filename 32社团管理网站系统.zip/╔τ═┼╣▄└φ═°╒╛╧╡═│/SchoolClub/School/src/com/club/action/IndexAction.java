package com.club.action;

import java.util.List;

import com.club.entity.Club;
import com.club.entity.ClubActivity;
import com.club.entity.ClubNews;
import com.club.service.ActivityService;
import com.club.service.ClubService;
import com.club.service.NewsService;
import com.club.service.impl.ActivityServiceImpl;
import com.club.service.impl.ClubServiceImpl;
import com.club.service.impl.NewsServiceImpl;
import com.opensymphony.xwork2.Preparable;

public class IndexAction extends BaseAction implements Preparable{
private ClubService cservice=null;
private ActivityService aservice=null;
private NewsService nservice=null;
	public String index(){
		List<Club> clubList=cservice.selAllClubs();
		List<ClubActivity> actList=aservice.selAllActs();
		List<ClubNews> newsList=nservice.selAllNews();
		this.getPutInRequet("actList", actList);
		this.getPutInRequet("clubList", clubList);
		this.getPutInRequet("newsList", newsList);
		return SUCCESS;
	}

	public void prepare() throws Exception {
	cservice=new ClubServiceImpl();
	aservice=new ActivityServiceImpl();
	nservice=new NewsServiceImpl();
		
	}
}
