package com.club.action;
import java.util.Map;

import com.club.entity.ClubUser;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
/**
 *Action������
 * @author Administrator
 *
 */
public class BaseAction extends ActionSupport {
 public  void getPutInRequet(String param,Object value){
	Map<String, Object> request= (Map<String, Object>) ActionContext.getContext().get("request");
	request.put(param, value);
 }
 
 public void getPutInSession(String param,Object value){
	 Map<String, Object> session=ActionContext.getContext().getSession();
	 session.put(param, value);
 }
 //��ȡ�û�����
 public ClubUser getSessionUser(){
	 return (ClubUser) ActionContext.getContext().getSession().get("user");
 }
 
}
