package com.club.action;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.club.entity.Club;
import com.club.entity.ClubActivity;
import com.club.entity.ClubPicture;
import com.club.entity.ClubType;
import com.club.entity.ClubUser;
import com.club.service.ClubService;
import com.club.service.PictureService;
import com.club.service.TypeService;
import com.club.service.UserInfoService;
import com.club.service.impl.ClubServiceImpl;
import com.club.service.impl.PictureServiceImpl;
import com.club.service.impl.TypeServiceImpl;
import com.club.service.impl.UserInfoServiceImpl;
import com.club.util.MD5Test;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.Preparable;
/**
 * �û�action��
 * @author Administrator
 *
 */
public class UserAction extends BaseAction implements Preparable{
private String page;//ҳ��
private final static int PAGESIZE=2;
private String clubId;
private TypeService tservice=null;
private ClubService cservice=null;
private PictureService pservice=null;
private String op;//�û�����  1.�û��޸�  2.�����޸�  
public String getOp() {
	return op;
}
public void setOp(String op) {
	this.op = op;
}
private String json;
public String getJson() {
	return json;
}

public void setJson(String json) {
	this.json = json;
}
private File pic;// �ϴ�ͼƬ�ļ�
private String picFileName;// �ϴ�ͼƬ�ļ�����

public File getPic() {
	return pic;
}
public void setPic(File pic) {
	this.pic = pic;
}
public String getPicFileName() {
	return picFileName;
}
public void setPicFileName(String picFileName) {
	this.picFileName = picFileName;
}
public String getClubId() {
	return clubId;
}
public void setClubId(String clubId) {
	this.clubId = clubId;
}
private String code;
private String str;
public String getStr() {
	return str;
}
public void setStr(String str) {
	this.str = str;
}
public String getCode() {
	return code;
}
public void setCode(String code) {
	this.code = code;
}
public String getPage() {
	return page;
}
public void setPage(String page) {
	this.page = page;
}
public ClubUser getUser() {
		return user;
	}
	public void setUser(ClubUser user) {
		this.user = user;
	}
private ClubUser user;//�û�����
private String newPwd;//������
private String oldPwd;//������
  public String getOldPwd() {
	return oldPwd;
}
public void setOldPwd(String oldPwd) {
	this.oldPwd = oldPwd;
}
public String getNewPwd() {
	return newPwd;
}
public void setNewPwd(String newPwd) {
	this.newPwd = newPwd;
}
private UserInfoService service=null;

public String join(){
	Club club=cservice.getClubById(Integer.valueOf(clubId));
	ClubUser user=this.getSessionUser();
	if(user.getClubType().getTypeId()==1){
		this.getPutInRequet("message", "����ϵͳ����Ա������ʧ�ܣ�&nbsp;&nbsp;<a href='javascript:history.back();'style='color:red'>����</a>");
		return "msg";
		
	}else if(user.getClubType().getTypeId()==2){
		this.getPutInRequet("message", "�������Ź���Ա������ʧ�ܣ�&nbsp;&nbsp;<a href='javascript:history.back();'style='color:red'>����</a>");
		return "msg";
		
	}
	ClubType type=tservice.getTypeById(4);
	user.setClub(club);
	user.setClubType(type);
	int row=service.editUser(user);
	if(row>0){
		this.getPutInRequet("message", "��ɹ�����"+club.getClubName()+",&nbsp;&nbsp;<a href='index_a.action'style='color:red'>���ص���ҳ</a>");
		return "msg";
	}
	else{
		this.getPutInRequet("message", "�����ʧ�ܣ�&nbsp;&nbsp;<a href='javascript:history.back();'style='color:red'>����</a>");
		return "msg";
	}
}
public String reLogin(){
	 boolean result=false;
	 if(str!=null&&str.length()>0){
		 user.setUserPwd(MD5Test.GetMD5Code(user.getUserPwd()));
	     result=service.reLogin(user);
		  if(result==false){
			  this.getPutInRequet("message", "�û�����������");
			  return "relogin_error";
		  }
		 
		  else{
			  user=service.getUserByName(user.getUserName());
			  user.getClubType().getTypeId();
			  if(user.getClub()!=null){
				  user.getClub().getClubId();
			  }
			  this.getPutInSession("user", user);
			  return "relogin";
		
		  }
	 }
	 else{
	 String image = (String) ActionContext.getContext().getSession().get(
		"imageCheckCode");
if (!image.equalsIgnoreCase(code)) {
	this.getPutInRequet("message", "��֤�����");
	return "relogin_error";
}else{
	  user.setUserPwd(MD5Test.GetMD5Code(user.getUserPwd()));
     result=service.reLogin(user);
	  if(result==false){
		  this.getPutInRequet("message", "�û�����������");
		  return "relogin_error";
	  }
	 
	  else{
		  user=service.getUserByName(user.getUserName());
		  user.getClubType().getTypeId();
		  if(user.getClub()!=null){
			  user.getClub().getClubId();
		  }
		
		  this.getPutInSession("user", user);
		  return "relogin";
	
	  }
}
	 }
	
}

public String exit(){
	user=this.getSessionUser();
	user.setClub(null);
	ClubType type=tservice.getTypeById(3);
	user.setClubType(type);
	int row=service.editUser(user);
	if(row>0){
		this.getPutInRequet("message", "����ɹ���<a href='main_user.action' style='color:red';>�ص�������ҳ</a>");
		return "msg";
	}
	else{
		this.getPutInRequet("message", "����ʧ�ܣ�<a href='javascript:history.back();' style='color:red';>����</a>");
		return "msg";
	}
}
  //�û���¼����
  public String login(){
	  int row=0;
	  user.setUserPwd(MD5Test.GetMD5Code(user.getUserPwd()));
      row=service.login(user);
	  if(row==0){
		  this.getPutInRequet("message", "�û�����������");
		  return "index";
	  }
	  else if(row<0){
		  this.getPutInRequet("message", "���ǹ���Ա");
		  return "index";
	  }
	  else{
		  user=service.getUserByName(user.getUserName());
		  user.getClubType().getTypeId();
		  if(user.getClub()!=null){
			  user.getClub().getClubId();
		  }
		
		  this.getPutInSession("user", user);
		  return "login_success";
	  }
	 
  }
  //ɾ���Ա
  public String del(){
	  int row=0;
	  row=service.deleteUser(user);
	  if(row>0){
		  return "del";
	  }else{
		  this.getPutInRequet("message", "ɾ��ʧ��!<a href='javascript:history.back();'>����</a>");
		  return "msg";
	  }
	 
  }
  //�û�ע�Ṧ��
  public String register(){
	  int row=0;
		 String image = (String) ActionContext.getContext().getSession().get(
			"imageCheckCode");
	if (!image.equalsIgnoreCase(code)) {
		this.getPutInRequet("message", "��֤�����");
		return "register_error";
	}
	else{
	  ClubType type=tservice.getTypeById(3);
	  user.setClubType(type);
	  user.setUserPwd(MD5Test.GetMD5Code(user.getUserPwd()));
	  row=service.register(user);
	  if(row>0){
		  this.getPutInRequet("user", user);
		  return "register";
	  }
	  else{
		  this.getPutInRequet("message","ע��ʧ��");
		  return "register_error";
	  }
  }
  }
  public String out(){
	  this.getPutInSession("user", null);
	  return "out";
  }
   //�޸����빦��
  public String updatePwd(){
	  user=service.getUserByName(user.getUserName());
	  oldPwd=MD5Test.GetMD5Code(oldPwd);
	  newPwd=MD5Test.GetMD5Code(newPwd);
	  if(user.getUserPwd().equals(oldPwd)){
		  user.setUserPwd(newPwd);
		  int row=service.editUser(user);
		  if(row>0){
			  this.getPutInSession("user", null);
			  return "index";
		  }else{
			  this.getPutInRequet("message", "�޸�����ʧ�ܣ�");
			  return "editpwd_error";
		  }
	  }else{
		  this.getPutInRequet("message", "�������������");
		  return "editpwd_error";
		  
	  }
  }
  //�޸��û�����
  public String edit(){
	  if(op!=null&&op.length()>0&&op.equals("1")){
		 ClubUser u=service.getUserByName(user.getUserName());
			 user.setUserPicture(u.getUserPicture());
			 user.setClub(u.getClub());
			 user.setUserPwd(u.getUserPwd());
			 user.setClubs(u.getClubs());
		user.setClubActivities(u.getClubActivities());
			user.setClubMessages(u.getClubMessages());
			user.setClubType(u.getClubType());
			int row=service.editUser(user);
			if(row>0){
				  this.getPutInRequet("message","�޸ĳɹ�!&nbsp;&nbsp;<a href='main_user.action'>�ص�������ҳ</a>");
				  this.getPutInSession("user", user);
				  return "msg";
			}else{
				 this.getPutInRequet("message","�޸�ʧ��!&nbsp;&nbsp;<a href='javascript:history.back();'>����</a>");
				  return "msg";
			}
	  }
	  else if(op!=null&&op.length()>0&&op.equals("2")){
		  user=service.getUserByName(user.getUserName());
		  oldPwd=MD5Test.GetMD5Code(oldPwd);
		  newPwd=MD5Test.GetMD5Code(newPwd);
		  if(user.getUserPwd().equals(oldPwd)){
			  user.setUserPwd(newPwd);
			  int row=service.editUser(user);
			  if(row>0){
				  this.getPutInSession("user", null);
				  this.getPutInRequet("message","�޸�����ɹ�!&nbsp;&nbsp;<a href='index_a.action'>�ص���ҳ</a>");
				  this.getPutInSession("user", user);
				 return "msg";
			  }else{
				  this.getPutInRequet("message","�޸�����ʧ��!&nbsp;&nbsp;<a href='javascript:history.back();'>����</a>");
				  return"msg";
			  }
		  }else{
			  this.getPutInRequet("message","ԭ������������&nbsp;&nbsp;<a href='javascript:history.back();'>����</a>");
			  return"msg";
			  
		  }
		  
	  }else{
		  String appPath = ServletActionContext.getServletContext().getRealPath(
			"/");

	String storePath = "userfiles/" + user.getUserName() + "/"
			+ com.club.util.FileUtils.fileName(picFileName);
	File f = new File(appPath + "/userfiles/" + user.getUserName());
	if (!f.exists()) {
		f.mkdirs();
	}
	pic.renameTo(new File(appPath + "/" + storePath));
	user=service.getUserByName(user.getUserName());
	user.setUserPicture(storePath);
		
	int row=service.editUser(user);
	 if(row>0){
		  
		  this.getPutInRequet("message","�ϴ�ͷ��ɹ�!&nbsp;&nbsp;<a href='index_a.action'>�ص���ҳ</a>");
		  this.getPutInSession("user", user);
		  return "mm";
	  }else{
		  this.getPutInRequet("message","�ϴ�ͷ��ʧ��!&nbsp;&nbsp;<a href='javascript:history.back();'>����</a>");
		  return "mm";
	  }
	  }

	  
	
	
  }

  
  //��ʾ���ų�Ա
  public String list(){
	  int pageIndex=1;
	  if(page!=null&&page.length()>0){
		  pageIndex=Integer.valueOf(page);
	  }
	  List<ClubUser> list=service.selAllUsers(4, pageIndex, PAGESIZE);
	  int totalPage=service.getTotalPage(4, PAGESIZE);
	  int count=service.getUsersCount(4);
	  user=this.getSessionUser();
	  if(user.getClubType().getTypeId()==2){
		  list=service.selAllUsersByClub(user.getClub().getClubId(), 4, pageIndex, PAGESIZE);
		  totalPage=service.getTotalPageByClub(user.getClub().getClubId(), 4, PAGESIZE);
		  count=service.getUsersCountByClub(user.getClub().getClubId(), 4);
	  }
	  this.getPutInRequet("list", list);
	  this.getPutInRequet("page", pageIndex);
	  this.getPutInRequet("totalPage", totalPage);
	  this.getPutInRequet("count", count);
	  return "list";
	  
  }
  
  public String main(){
	  user=this.getSessionUser();
	  
	  return "main";
  }
  public String info(){
	  user=this.getSessionUser();
	 
	  return "info";
  }
  
  public String look(){
	  user=service.getUserById(user.getUserId());
	  return "look";
  }
  public String toedit(){
	  List<ClubPicture> picList=pservice.selAllPictures();
		this.getPutInRequet("picList", picList);
	  user=this.getSessionUser();
	
	  return "toedit";
  }
  public String checkUser(){
	  user=service.getUserByName(user.getUserName());	
		if(user!=null){
			json ="{\"status\":\"2\"}";
		}
		else{
			json ="{\"status\":\"1\"}";
		}
		  HttpServletResponse response=ServletActionContext.getResponse();
		  response.setCharacterEncoding("utf-8");
		  response.setContentType("text/html;charset=utf-8");
		  try {
			  response.getWriter().write(json); 
		  } catch (Exception e) { 
			  
		  }
	  return NONE;
  }
  //��ʼ������
public void prepare() throws Exception {
	service=new UserInfoServiceImpl();
	cservice=new ClubServiceImpl();
	tservice=new TypeServiceImpl();
 pservice=new PictureServiceImpl();
}
}
