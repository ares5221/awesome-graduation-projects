package com.club.action;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.struts2.ServletActionContext;

import com.club.entity.Club;
import com.club.entity.ClubActivity;
import com.club.entity.ClubNews;
import com.club.entity.ClubPicture;
import com.club.service.ActivityService;
import com.club.service.ClubService;
import com.club.service.NewsService;
import com.club.service.PictureService;
import com.club.service.impl.ActivityServiceImpl;
import com.club.service.impl.ClubServiceImpl;
import com.club.service.impl.NewsServiceImpl;
import com.club.service.impl.PictureServiceImpl;
import com.opensymphony.xwork2.Preparable;

/**
 * �û�����action��
 * 
 * @author Administrator
 * 
 */
public class NewsAction extends BaseAction implements Preparable {
	private final static int PAGESIZE = 5;
	private ClubNews news;// ����һ���������
	private Club club;
	private File[] pics;// ͼƬ
	private String[] picsFileName;// ͼƬ��
	private String clubId;
    private PictureService pservice=null;
	public String getClubId() {
		return clubId;
	}

	public void setClubId(String clubId) {
		this.clubId = clubId;
	}

	public File[] getPics() {
		return pics;
	}

	public void setPics(File[] pics) {
		this.pics = pics;
	}

	public String[] getPicsFileName() {
		return picsFileName;
	}

	public void setPicsFileName(String[] picsFileName) {
		this.picsFileName = picsFileName;
	}

	public Club getClub() {
		return club;
	}

	public void setClub(Club club) {
		this.club = club;
	}

	private String page;// ҳ�ı��
	private NewsService service = null;
	private ClubService cservice = null;
	private ActivityService aservice=null;
	public String detail(){
		news=service.getNewsById(news.getNewsId());
		return "detail";
	}

	// ��ʾ���Ź����б�
	public String list() {
		int pageIndex = 1;
		if (page != null && !"".equals(page)) {
			pageIndex = Integer.valueOf(page);
		}
		List<ClubNews> list = service.selAllNewsByPage(pageIndex, PAGESIZE);
		int totalPage = service.getNewsTotalPage(PAGESIZE);
		if (this.getSessionUser().getClubType().getTypeId() == 2) {
			list = service.selAllNewsByPageClub(pageIndex, PAGESIZE, this
					.getSessionUser().getClub().getClubId());
			totalPage = service.getNewsTotalPageClub(PAGESIZE, this
					.getSessionUser().getClub().getClubId());
		}
		this.getPutInRequet("page", pageIndex);
		this.getPutInRequet("list", list);
		this.getPutInRequet("totalPage", totalPage);
		return "list";
	}

	// ���ӹ���ǰ��׼��
	public String toAdd() {
		List<Club> list = cservice.selAllClubs();
		this.getPutInRequet("clubList", list);
		return "toadd";
	}

	// ���ӹ���
	public String add() {
		Set<ClubPicture> p= new HashSet<ClubPicture>();
		String appPath = ServletActionContext.getServletContext().getRealPath(
		"/");
		if (pics != null && pics.length > 0) {
			for (int i = 0; i < pics.length; i++) {
				String storePath = "userfiles/" + this.getSessionUser().getUserName() + "/"
				+ com.club.util.FileUtils.fileName(picsFileName[i]);
				File f = new File(appPath + "/userfiles/" + this.getSessionUser().getUserName());
				if (!f.exists()) {
					f.mkdirs();
				}
				pics[i].renameTo(new File(appPath + "/" + storePath));
				ClubPicture clubp=new ClubPicture();
				clubp.setPicUrl(storePath);
				p.add(clubp);
			}
		}
		news.setClubPictures(p);
		news.setClub(this.getSessionUser().getClub());
		int row = service.insertNews(news);
		if (row > 0) {
			return "add";
		} else {
			 this.getPutInRequet("message", "����ʧ��!<a href='javascript:history.back();'>����</a>");
				return "message";
		}

	}

	// �޸Ĺ���ǰ��׼��
	public String toEdit() {
		List<Club> list = cservice.selAllClubs();
		this.getPutInRequet("clubList", list);
		news = service.getNewsById(news.getNewsId());
		return "toedit";
	}

	// �޸Ĺ���
	public String edit() {
		Set<ClubPicture> p= new HashSet<ClubPicture>();
		String appPath = ServletActionContext.getServletContext().getRealPath(
		"/");
		if (pics != null && pics.length > 0) {
			for (int i = 0; i < pics.length; i++) {
				String storePath = "userfiles/" + this.getSessionUser().getUserName() + "/"
				+ com.club.util.FileUtils.fileName(picsFileName[i]);
				File f = new File(appPath + "/userfiles/" + this.getSessionUser().getUserName());
				if (!f.exists()) {
					f.mkdirs();
				}
				pics[i].renameTo(new File(appPath + "/" + storePath));
				ClubPicture clubp=new ClubPicture();
				clubp.setPicUrl(storePath);
				p.add(clubp);
			}
		}
		news.setClubPictures(p);
		int row = service.updateNews(news);
		if (row > 0) {
			List<ClubPicture> list=pservice.selPicByNews();
			for (ClubPicture pic : list) {
				row=pservice.deletePicture(pic.getPicId());
				if(row<=0){
					break;
				}
			}
		if(row>0){
			return "edit";
		}else{
			 this.getPutInRequet("message", "�޸�ʧ��!<a href='javascript:history.back();'>����</a>");
				return "message";
		}
			
		}
		 this.getPutInRequet("message", "�޸�ʧ��!<a href='javascript:history.back();'>����</a>");
			return "message";
			}
			

	// ɾ������
	public String del() {
		int row = service.deleteNews(news.getNewsId());
		if (row > 0) {
			return "del";
		} else {
			 this.getPutInRequet("message", "ɾ��ʧ��!<a href='javascript:history.back();'>����</a>");
				return "message";
		}

	}
public String show(){
	int totalPage=service.getNewsTotalPage(PAGESIZE);
	

	List<Club> clubList=cservice.selAllClubs();
	int pageIndex=1;
	if(page!=null&&page.length()>0){
		pageIndex=Integer.valueOf(page);
	}
	List<ClubNews> newsList=service.selAllNewsByPage(pageIndex, PAGESIZE);
	List<ClubActivity> actList=aservice.selAllActsByPageAudit1(pageIndex, PAGESIZE);
	if(clubId!=null&&clubId.length()>0){
		newsList=service.selAllNewsByPageClub(pageIndex, PAGESIZE,  Integer.valueOf(clubId));
		totalPage=service.getNewsTotalPageClub(PAGESIZE, Integer.valueOf(clubId));
		}
	this.getPutInRequet("totalPage", totalPage);
	this.getPutInRequet("actList", actList);
	this.getPutInRequet("newsList", newsList);
	this.getPutInRequet("page", pageIndex);
	this.getPutInRequet("clubId", clubId);
	this.getPutInRequet("clubList", clubList);
	return "show";
}

public String info(){
	news=service.getNewsById(news.getNewsId());
	List<ClubActivity> actList=aservice.selAllActs();
	this.getPutInRequet("actList", actList);
	List<ClubPicture> pictures=pservice.selAllPicturesByNewsId(news.getNewsId());
	this.getPutInRequet("picList", pictures);
	return "info";
	
}
	// ��ʼ������
	public void prepare() throws Exception {
		service = new NewsServiceImpl();
		cservice = new ClubServiceImpl();
		aservice=new ActivityServiceImpl();
		pservice=new PictureServiceImpl();
	}

	public ClubNews getNews() {
		return news;
	}

	public void setNews(ClubNews news) {
		this.news = news;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}
}
