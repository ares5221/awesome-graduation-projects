package com.club.action;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.club.entity.Club;
import com.club.entity.ClubActivity;
import com.club.entity.ClubNews;
import com.club.entity.ClubType;
import com.club.entity.ClubUser;
import com.club.service.ActivityService;
import com.club.service.ClubService;
import com.club.service.NewsService;
import com.club.service.TypeService;
import com.club.service.UserInfoService;
import com.club.service.impl.ActivityServiceImpl;
import com.club.service.impl.ClubServiceImpl;
import com.club.service.impl.NewsServiceImpl;
import com.club.service.impl.TypeServiceImpl;
import com.club.service.impl.UserInfoServiceImpl;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.Preparable;
/**
 * �û�����action��
 * @author Administrator
 *
 */
public class ClubAction extends BaseAction implements Preparable{
private final static int PAGESIZE=5;
private Club club;//����һ������
private String page;//ҳ�ı��
private ClubService service=null;
private UserInfoService uservice=null;
private String json;
public String getJson() {
	return json;
}

public void setJson(String json) {
	this.json = json;
}

private ActivityService aservice=null;
private TypeService tservice=null;
private NewsService nservice=null;
private String audit;//�Ƿ����
private String code;
public String getCode() {
	return code;
}

public void setCode(String code) {
	this.code = code;
}

public String getAudit() {
	return audit;
}

public void setAudit(String audit) {
	this.audit = audit;
}


//��ʾ�����б�
public String list(){
	int pageIndex=1;
	if(page!=null&&!"".equals(page)){
		pageIndex=Integer.valueOf(page);
	}
	List<Club> list=null;
	int totalPage=0;
	ClubUser user=this.getSessionUser();
	if(user.getClubType().getTypeId()==1){
		if(audit!=null&&audit.length()>0){
			list=service.selAllClubsByPageAudit1(pageIndex, PAGESIZE);
			totalPage=service.getTotalPageByAudit1(PAGESIZE);
		}else{
			list=service.selAllClubsByPageAudit0(pageIndex, PAGESIZE);
			totalPage=service.getTotalPageByAudit0(PAGESIZE);
		}
	}else{
		list=service.selClubByAdminId(user.getUserId());
	}
	
	this.getPutInRequet("page", pageIndex);
	this.getPutInRequet("list", list);
	this.getPutInRequet("totalPage", totalPage);
	return "list";
}

public String audit(){
	club=service.getClubById(club.getClubId());
	club.setClubAudit(1);
	int row=service.updateClub(club);
	if(row>0){
		return "audit";
	}
	 this.getPutInRequet("message", "���ʧ��!&nbsp;&nbsp;<a href='javascript:history.back();' style='color:red;'>����</a>");
		return "message";

}

public String checkClub(){
//    try {
//		ServletActionContext.getRequest().setCharacterEncoding("utf-8");
//	} catch (UnsupportedEncodingException e1) {
//		// TODO Auto-generated catch block
//		e1.printStackTrace();
//	}
	try {
		club.setClubName(URLDecoder.decode(club.getClubName(), "UTF-8"));
	} catch (UnsupportedEncodingException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	 
	  club=service.getClubByName(club.getClubName());
		if(club!=null){
			json ="{\"status\":\"2\"}";
		}
		else{
			json ="{\"status\":\"1\"}";
		}
		  HttpServletResponse response=ServletActionContext.getResponse();
		  response.setCharacterEncoding("utf-8");
		  response.setContentType("text/html;charset=utf-8");
          
		
		  try {
			  response.getWriter().write(json); 
		  } catch (Exception e) { 
			  
		  }
	  return NONE;
}

//��������
public String add(){
	String image = (String) ActionContext.getContext().getSession().get(
	"imageCheckCode");
if (!image.equalsIgnoreCase(code)) {
this.getPutInRequet("message", "��֤�����");
return "add_error";
}
else{
	club.setClubAudit(0);
	club.setClubDate(new Date());
	ClubUser user=this.getSessionUser();
	ClubType type=tservice.getTypeById(2);
    user.setClubType(type);
	int row=uservice.editUser(user);
	if(row>0){
		club.setClubUser(user);
		int row2=service.insertClub(club);
		if(row2>0){
			user.setClub(club);
			row=uservice.editUser(user);
			
			return "add";
		}else{
			 this.getPutInRequet("message","�ύ����ʧ��!&nbsp;&nbsp;<a href='javascript:history.back();' style='color:red;'>����</a>");
				return "msg";
		}
	}
	else{
		 this.getPutInRequet("message","�ύ����ʧ��!&nbsp;&nbsp;<a href='javascript:history.back();' style='color:red;'>����</a>");
		return "msg";
	}
	
}
}

//�޸�����ǰ��׼��
public String toEdit(){
	club=service.getClubById(club.getClubId());
	return "toedit";
}

public String detail(){
	club=service.getClubById(club.getClubId());
	return "detail";
}
//�޸�����
public String edit(){

	int row=service.updateClub(club);
	if(row>0){
		return "edit";
	}
	else{
		 this.getPutInRequet("message", "�޸�ʧ��!&nbsp;&nbsp;<a href='javascript:history.back();' style='color:red'>����</a>");
		 return "message";
	}
}

//ɾ������
public String del(){
	club=service.getClubById(club.getClubId());

	if(aservice.getActsCountByClub(club.getClubId())>0){
		this.getPutInRequet("message", "ɾ��ʧ��,�������»��л������ɾ���!<a href='javascript:history.back();'>����</a>");
		return "message";
		
	}else if(nservice.getNewsCountByClub(club.getClubId())>0){
		this.getPutInRequet("message", "ɾ��ʧ��,�������»��й��棬����ɾ������!<a href='javascript:history.back();'>����</a>");
		return "message";
		
	}else if(uservice.getUsersCountByClub(club.getClubId(), 4)>0){
		this.getPutInRequet("message", "ɾ��ʧ��,�������»��г�Ա������ɾ����Ա!<a href='javascript:history.back();'>����</a>");
		return "message";
		
	}
	else{
	int row=service.deleteClub(club.getClubId());
	if(row>0){
		return "del";
	}
	else{
		 this.getPutInRequet("message", "ɾ��ʧ��!<a href='javascript:history.back();'>����</a>");
		return "message";
	}
	}
}

public String show(){
	int pageIndex=1;
	if(page!=null&&page.length()>0){
		pageIndex=Integer.valueOf(page);
	}
	List<Club> clublist=service.selAllClubsByPageAudit1(pageIndex, PAGESIZE);
	List<ClubActivity> actList=aservice.selAllActs();
	this.getPutInRequet("actList",actList);
	List<ClubNews> newsList=nservice.selAllNews();
	this.getPutInRequet("newsList", newsList);
	int totalPage=service.getTotalPageByAudit1(PAGESIZE);
	this.getPutInRequet("totalPage", totalPage);
	this.getPutInRequet("clubList", clublist);
	this.getPutInRequet("page", pageIndex);
	return "show";
	
}

public String info(){
	club=service.getClubById(club.getClubId());
	List<ClubActivity> actList=aservice.selAllActs();
	this.getPutInRequet("actList",actList);
	List<ClubNews> newsList=nservice.selAllNews();
	this.getPutInRequet("newsList", newsList);
	return "info";
}
//��ʼ������
public void prepare() throws Exception {
	service=new ClubServiceImpl();
	uservice=new UserInfoServiceImpl();
	nservice=new NewsServiceImpl();
	aservice=new ActivityServiceImpl();
	tservice=new TypeServiceImpl();
}
public Club getClub() {
	return club;
}
public void setClub(Club club) {
	this.club = club;
}
public String getPage() {
	return page;
}
public void setPage(String page) {
	this.page = page;
}
}
