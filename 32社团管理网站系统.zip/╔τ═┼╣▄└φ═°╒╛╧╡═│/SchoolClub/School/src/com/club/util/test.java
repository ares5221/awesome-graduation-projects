package com.club.util;

import java.text.ParseException;
import java.util.Date;



public class test {
public static void main(String[] args) throws ParseException {
	System.out.println(DateFormate.setFormatDate(new Date()));
	System.out.println(new Date());
}
}
