package com.club.util;

import java.util.UUID;

public class FileUtils {
		public static String fileName(String name){
			String fileName=UUID.randomUUID().toString();
			fileName=fileName+getExtc(name);
			return fileName;
		}
		public static String getExtc(String name){
			String extc="";
			if(null!=name && name.length()>0 && name.indexOf(".")>0){
				extc=name.substring(name.lastIndexOf("."));
			}
			return extc;
		}
}
