package com.club.service.impl;

import java.util.List;

import com.club.dao.NewsDao;
import com.club.dao.impl.NewsDaoImpl;
import com.club.entity.ClubNews;
import com.club.service.NewsService;

/**
 * ��������ҵ��ʵ����
 * 
 * @author Administrator
 * 
 */
public class NewsServiceImpl implements NewsService {
	private NewsDao dao = new NewsDaoImpl();

	// ʵ��ɾ�����ŵķ���
	public int deleteNews(int id) {
		int row = 0;
		try {
			row = dao.deleteNews(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	// ʵ�ֻ�ȡ���ŵķ���
	public ClubNews getNewsById(int id) {
		ClubNews news = null;
		try {
			news = dao.getNewsById(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return news;
	}

	// ʵ�ֻ�ȡ���������ķ���
	public int getNewsCountByClub(int cid) {
		int count = 0;
		try {
			count = dao.getNewsCountByClub(cid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	// ʵ�ֻ�ȡ������ҳ���ķ���
	public int getNewsTotalPage(int pageSize) {
		int totalPage = 0;
		try {
			int count = dao.getNewsCount();
			totalPage = count % pageSize == 0 ? (count / pageSize) : (count
					/ pageSize + 1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return totalPage;
	}
	
	public int getNewsTotalPageClub(int pageSize, int cid) {
		int totalPage = 0;
		try {
			int count = dao.getNewsCountByClub(cid);
			totalPage = count % pageSize == 0 ? (count / pageSize) : (count
					/ pageSize + 1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return totalPage;
	}

	// ʵ���������ŵķ���
	public int insertNews(ClubNews news) {
		int row = 0;
		try {
			row = dao.insertNews(news);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	// ʵ�ֲ�ѯ�������ŵķ���
	public List<ClubNews> selAllNews() {
		List<ClubNews> list = null;
		try {
			list = dao.selAllNews();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	// ʵ�ֲ�ѯÿ�������������ŵķ���
	public List<ClubNews> selAllNewsByPageClub(int pageIndex,int pageSize,int cid) {
		List<ClubNews> list = null;
		try {
			list = dao.selAllNewsByPageClub(pageIndex, pageSize, cid);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	// ʵ�ֲ�ѯÿҳ�������ŵķ���
	public List<ClubNews> selAllNewsByPage(int pageIndex, int pageSize) {
		List<ClubNews> list = null;
		try {
			list = dao.selAllNewsByPage(pageIndex, pageSize);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	// ʵ���޸�������Ϣ�ķ���
	public int updateNews(ClubNews news) {
		int row = 0;
		try {
			row = dao.updateNews(news);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	public int getNewsCount(){
		int count = 0;
		try {
			count = dao.getNewsCount();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}




}
