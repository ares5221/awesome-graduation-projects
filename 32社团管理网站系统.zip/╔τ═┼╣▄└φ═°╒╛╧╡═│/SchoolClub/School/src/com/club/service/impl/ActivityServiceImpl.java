package com.club.service.impl;

import java.util.List;

import com.club.dao.ActivityDao;
import com.club.dao.impl.ActivityDaoImpl;
import com.club.entity.ClubActivity;
import com.club.service.ActivityService;

/**
 * ����ҵ��ʵ����
 * 
 * @author Administrator
 * 
 */
public class ActivityServiceImpl implements ActivityService {
	private ActivityDao dao = new ActivityDaoImpl();

	// ʵ��ɾ����ķ���
	public int deleteActivity(int id) {
		int row = 0;
		try {
			row = dao.deleteActivity(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return row;
	}

	// ��ȡ�����ķ���
	public ClubActivity getActivityById(int id) {
		ClubActivity activity = null;
		try {
			activity = dao.getActivityById(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return activity;
	}

	
	// ��ȡ������ķ���
	public int getActsCountByClub(int cid) {
		int count = 0;
		try {
			count = dao.getActsCountByClub(cid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	// ʵ�ֻ�ȡ���ҳ���ķ���
	public int getActsTotalPageClub(int pageSize, int cid) {
		int totalPage = 0;
		try {
			
				int count = dao.getActsCountByClub(cid);

			totalPage = count % pageSize == 0 ? (count / pageSize) : (count
					/ pageSize + 1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return totalPage;
	}
	
	public int getActsTotalPageAudit1(int pageSize){
		
		int totalPage = 0;
		try {
			
				int count = dao.getActsCountByAudit1();

			totalPage = count % pageSize == 0 ? (count / pageSize) : (count
					/ pageSize + 1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return totalPage;
	};

	// ʵ�����ӻ�ķ���
	public int insertActivity(ClubActivity activity) {
		int row = 0;
		try {
			row = dao.insertActivity(activity);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	// ʵ�ֲ�ѯÿ���������л�ķ���
	public List<ClubActivity> selAllActsByPageClub(int pageIndex,int pageSize,int cid) {
		List<ClubActivity> list = null;
		try {
			list = dao.selAllActsByPageClub(pageIndex, pageSize, cid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	// ʵ�ֲ�ѯÿҳ���л�ķ���
	public List<ClubActivity> selAllActsByPageAudit1(int pageIndex, int pageSize) {
		List<ClubActivity> list = null;
		try {
			list = dao.selAllActsByPageAudit1(pageIndex, pageSize);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	// ʵ���޸Ļ��Ϣ�ķ���
	public int updateActivity(ClubActivity activity) {
		int row = 0;
		try {
			row = dao.updateActivity(activity);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	public List<ClubActivity> selAllActs() {
		List<ClubActivity> list = null;
		try {
			list = dao.selAllActs();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	public int getActsCountByAudit0() throws Exception {
		int count = 0;
		try {
			count = dao.getActsCountByAudit0();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	public int getActsCountByAudit1() throws Exception {
		int count = 0;
		try {
			count = dao.getActsCountByAudit1();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	public int getActsTotalPageAudit0(int pageSize) {
		int totalPage = 0;
		try {
			
				int count = dao.getActsCountByAudit0();

			totalPage = count % pageSize == 0 ? (count / pageSize) : (count
					/ pageSize + 1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return totalPage;
	}


	public List<ClubActivity> selAllActsByPageAudit0(int pageIndex, int pageSize) {
		List<ClubActivity> list = null;
		try {
			list = dao.selAllActsByPageAudit0(pageIndex, pageSize);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}



}
