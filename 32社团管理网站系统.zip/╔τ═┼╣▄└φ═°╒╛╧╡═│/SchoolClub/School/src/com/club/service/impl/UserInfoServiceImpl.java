package com.club.service.impl;

import java.util.List;

import com.club.dao.UserInfoDao;
import com.club.dao.impl.UserInfoDaoImpl;
import com.club.entity.ClubUser;
import com.club.service.UserInfoService;

/**
 * �û�ʵ��ҵ����
 * 
 * @author Administrator
 * 
 */
public class UserInfoServiceImpl implements UserInfoService {
	private UserInfoDao dao = new UserInfoDaoImpl();

	// ʵ���û���¼�ķ���
	public int login(ClubUser user) {
		int row=0;
		try {
			ClubUser reuser = dao.getUserByName(user.getUserName());
			if (reuser != null) {
				System.out.println(reuser.getClubType().getTypeId());
				if(reuser.getClubType().getTypeId()!=1&&reuser.getClubType().getTypeId()!=2){
					row=-1;
				}else{
				if (reuser.getUserPwd().equals(user.getUserPwd())) {
					row=1;
				}
			}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	// ʵ���û�ע��ķ���
	public int register(ClubUser user) {
		int row = 0;
		try {
			row = dao.insertUser(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return row;

	}
  //ʵ��ɾ���û��ķ���
	public int deleteUser(ClubUser user) {
		int row=0;
		try {
			row=dao.deleteUser(user);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}
  //ʵ���޸��û��ķ���
	public int editUser(ClubUser user) {
		int row=0;
		try {
			row=dao.updateUser(user);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}
  //ʵ�ָ����û�����ȡ�û�����ķ���
	public ClubUser getUserByName(String name) {
		ClubUser user=null;
		try {
			user=dao.getUserByName(name);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}
  //ʵ�ָ���ҳ����ѯ���г�Ա
	public List<ClubUser> selAllUsers(int type,int pageIndex,int pageSize) {
		List<ClubUser> list=null;
		try {
			list=dao.selAllUsers(type, pageIndex, pageSize);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	//ʵ�ֻ�ȡ���ų�Ա��ҳ��
	public int getTotalPage(int type, int pageSize) {
		int totalPage=0;
		try {
			int count=dao.getUsersCount(type);
			totalPage=(count%pageSize==0)?(count/pageSize):(count/pageSize+1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return totalPage;
	}


	//ʵ�ֻ�ȡ���ų�Ա����
	public int getUsersCount(int type) {
		int count=0;
		try {
			count=dao.getUsersCount(type);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	//ʵ�ֻ�ȡ�����������г�Ա����ҳ��
	public int getTotalPageByClub(int clubId, int type, int pageSize) {
		int totalPage=0;
		try {
			int count=dao.getUsersCountByClub(clubId, type);
			totalPage=(count%pageSize==0)?(count/pageSize):(count/pageSize+1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return totalPage;
	}

	//ʵ�ֻ�ȡ�����������г�Ա������
	public int getUsersCountByClub(int clubId, int type) {
		int count=0;
		try {
			count=dao.getUsersCountByClub(clubId, type);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	//ʵ�ָ���ҳ����ѯ�����������г�Ա
	public List<ClubUser> selAllUsersByClub(int clubId, int type,
			int pageIndex, int pageSize) {
		List<ClubUser> list=null;
		try {
			list=dao.selAllUsersByClub(clubId, type, pageIndex, pageSize);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	//ʵ�ָ������µ����г�Ա
	public List<ClubUser> selAllUsers(int clubId, int type) {
		List<ClubUser> list=null;
		try {
			list=dao.selAllUsers(clubId, type);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	public boolean reLogin(ClubUser user) {
		boolean result= false;
		ClubUser reuser;
		try {
			reuser = dao.getUserByName(user.getUserName());
			if(reuser!=null){
				if(reuser.getUserPwd().equals(user.getUserPwd())){
					result=true;
				}
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public ClubUser getUserById(int id) {
		ClubUser user=null;
		try {
			user=dao.getUserById(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}


}
