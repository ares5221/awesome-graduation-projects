package com.club.service.impl;

import java.util.List;

import com.club.dao.MessageDao;
import com.club.dao.impl.MessageDaoImpl;
import com.club.entity.ClubMessage;
import com.club.service.MessageService;

/**
 * ��������ҵ��ʵ����
 * 
 * @author Administrator
 * 
 */
public class MessageServiceImpl implements MessageService {
	private MessageDao dao = new MessageDaoImpl();

	// ʵ��ɾ�����Եķ���
	public int deleteMessage(int id) {
		int row = 0;
		try {
			row = dao.deleteMessage(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;

	}

	// ʵ�ֻ�ȡ���Եķ���
	public ClubMessage getMessageById(int id) {
		ClubMessage message = null;
		try {
			message = dao.getMessageById(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return message;
	}

	// ʵ���������Եķ���
	public int insertMessage(ClubMessage message) {
		int row = 0;
		try {
			row = dao.insertMessage(message);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}


	// ʵ���޸����Եķ���
	public int updateMessage(ClubMessage message) {
		int row = 0;
		try {
			row = dao.updateMessage(message);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	public int getTotalPageByNews(int nid, int pageSize) {
		int totalPage = 0;
		try {
			int count = dao.getMsgsCountByNews(nid);
			totalPage = count % pageSize == 0 ? (count / pageSize) : (count
					/ pageSize + 1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return totalPage;
	}
 //ʵ�ֲ�ѯÿ�������µ��������Եķ���
	public List<ClubMessage> selAllMsgsByPageNews(int pageIndex, int pageSize,
			int nid) {
		List<ClubMessage> list = null;
		try {
			list = dao.selAllMsgsByPageNews(pageIndex, pageSize, nid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
  //ʵ�ֻ�ȡÿ�������µ����������ķ���
	public int getMsgsCountByNews(int nid) {
		int count = 0;
		try {
			count = dao.getMsgsCountByNews(nid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

}
