package com.club.service.impl;

import java.util.List;

import com.club.dao.PictureDao;
import com.club.dao.impl.PictureDaoImpl;
import com.club.entity.ClubPicture;
import com.club.service.PictureService;

/**
 * ����ͼƬҵ��ʵ����
 * 
 * @author Administrator
 * 
 */
public class PictureServiceImpl implements PictureService {
	private PictureDao dao = new PictureDaoImpl();

	// ʵ��ɾ��ͼƬ�ķ���
	public int deletePicture(int id) {
		int row = 0;
		try {
			row = dao.deletePicture(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	// ʵ�ֻ�ȡͼƬ������ ����
	public int getPictureCount(int actId) {
		int count = 0;
		try {
			count = dao.getPictureCount(actId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	// ʵ�ֻ�ȡͼƬ��ҳ���ķ���
	public int getTotalPage(int actId, int pageSize) {
		int totalPage = 0;
		try {
			int count = dao.getPictureCount(actId);
			totalPage = count % pageSize == 0 ? (count / pageSize) : (count
					/ pageSize + 1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return totalPage;
	}

	// ʵ������ͼƬ�ķ���
	public int insertPicture(ClubPicture picture) {
		int row = 0;
		try {
			row = dao.insertPicture(picture);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	// ʵ�ֲ�ѯ����ͼƬ�ķ���
	public List<ClubPicture> selAllPictures() {
		List<ClubPicture> list = null;
		try {
			list = dao.selAllPictures();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	// ʵ�ֲ�ѯÿ�������ͼƬ�ķ���
	public List<ClubPicture> selAllPicturesByNewsId(int newsId) {
		List<ClubPicture> list = null;
		try {
			list = dao.selAllPicturesByNewsId(newsId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	// ʵ�ֲ�ѯÿҳ����ͼƬ�ķ���
	public List<ClubPicture> selAllPicturesByPage(int pageIndex, int pageSize,
			int newsId) {
		List<ClubPicture> list = null;
		try {
			list = dao.selAllPicturesByPage(pageIndex, pageSize, newsId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	// ʵ���޸�ͼƬ�ķ���
	public int updatePicture(ClubPicture picture) {
		int row = 0;
		try {
			row = dao.updatePicture(picture);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	public List<ClubPicture> selPicByNews() {
		List<ClubPicture> list = null;
		try {
			list =dao.selPicByNews();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

}
