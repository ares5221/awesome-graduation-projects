package com.club.service.impl;

import com.club.dao.TypeDao;
import com.club.dao.impl.TypeDaoImpl;
import com.club.entity.ClubType;
import com.club.service.TypeService;

public class TypeServiceImpl implements TypeService{
  private TypeDao dao=new TypeDaoImpl();
	public ClubType getTypeById(int typeId) {
		ClubType type=null;
		try {
			type=dao.getTypeById(typeId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return type;
	}

}
