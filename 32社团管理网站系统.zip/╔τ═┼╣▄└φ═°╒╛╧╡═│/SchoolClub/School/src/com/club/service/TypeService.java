package com.club.service;

import com.club.entity.ClubType;

public interface  TypeService {
 public ClubType getTypeById(int typeId);
}
