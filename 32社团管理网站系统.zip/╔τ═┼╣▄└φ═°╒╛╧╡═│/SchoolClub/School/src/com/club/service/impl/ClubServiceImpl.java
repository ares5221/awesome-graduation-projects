package com.club.service.impl;

import java.util.List;

import com.club.dao.ClubDao;
import com.club.dao.impl.ClubDaoImpl;
import com.club.entity.Club;
import com.club.service.ClubService;

/**
 * ����ҵ��ʵ����
 * 
 * @author Administrator
 * 
 */
public class ClubServiceImpl implements ClubService {
	private ClubDao dao = new ClubDaoImpl();

	// ʵ��ɾ�����ŵķ���
	public int deleteClub(int id) {
		int row = 0;
		try {
			row = dao.deleteClub(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	// ʵ�ֻ�ȡ���Ŷ���ķ���
	public Club getClubById(int id) {
		Club club = null;
		try {
			club = dao.getClubById(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return club;
	}
	
	public List<Club> selClubByAdminId(int uid) {
		List<Club> list=null;
		try {
			list = dao.selClubByAdminId(uid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	// ʵ�ֻ�ȡ���������ķ���
	public int getClubsCountByAudit0() {
		int count = 0;
		try {
			count = dao.getClubsCountByAudit0();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	// ʵ�ֻ�ȡ������ҳ���ķ���
	public int getTotalPageByAudit1(int pageSize) {
		int totalPag = 0;
		try {
			int count = dao.getClubsCountByAudit1();
			totalPag = count % pageSize == 0 ? (count / pageSize) : (count
					/ pageSize + 1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return totalPag;
	}

	// ʵ���������ŵķ���
	public int insertClub(Club club) {
		int row = 0;
		try {
			row = dao.insertClub(club);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	// ʵ�ֲ�ѯ����������Ϣ�ķ���
	public List<Club> selAllClubs() {
		List<Club> list = null;
		try {
			list = dao.selAllClubs();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	// ʵ�ֲ�ѯÿҳ������Ϣ�ķ���
	public List<Club> selAllClubsByPageAudit1(int pageIndex, int pageSize) {
		List<Club> list = null;
		try {
			list = dao.selAllClubsByPageAudit1(pageIndex, pageSize);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	// ʵ���޸�������Ϣ�ķ���
	public int updateClub(Club club) {
		int row = 0;
		try {
			row = dao.updateClub(club);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	public int getClubsCountByAudit1() {
		int count = 0;
		try {
			count = dao.getClubsCountByAudit1();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	public int getTotalPageByAudit0(int pageSize) {
		int totalPag = 0;
		try {
			int count = dao.getClubsCountByAudit0();
			totalPag = count % pageSize == 0 ? (count / pageSize) : (count
					/ pageSize + 1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return totalPag;
	}



	public List<Club> selAllClubsByPageAudit0(int pageIndex, int pageSize) {
		List<Club> list = null;
		try {
			list = dao.selAllClubsByPageAudit0(pageIndex, pageSize);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	public Club getClubByName(String name) {
	Club club=null;
	try {
		club=dao.getClubByName(name);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return club;
	}

}
