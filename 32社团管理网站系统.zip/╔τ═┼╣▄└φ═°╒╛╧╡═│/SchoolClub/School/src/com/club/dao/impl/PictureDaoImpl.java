package com.club.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.club.dao.HibernateSessionFactory;
import com.club.dao.PictureDao;
import com.club.entity.ClubMessage;
import com.club.entity.ClubPicture;

/**
 * ����ͼƬdaoʵ����
 * 
 * @author Administrator
 * 
 */
public class PictureDaoImpl implements PictureDao {
	// ʵ��ɾ��ͼƬ��Ϣ�ķ���
	public int deletePicture(int id) throws Exception {
		int row = 0;
		ClubPicture picture = new ClubPicture();
		picture.setPicId(id);
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.delete(picture);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		return row;
	}

	// ʵ�ֻ�ȡͼƬ�����ķ���
	public int getPictureCount(int newsId) throws Exception {
		int count = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql = "select count(*) from  ClubPicture c";
		Query query = session.createQuery(hql);
		if (newsId != 0) {
			hql = "select count(*) from  ClubPicture c where c.clubNews.newsId=?";
			query = session.createQuery(hql);
			query.setInteger(0, newsId);
		}
		count = Integer.parseInt(query.uniqueResult() + "");
		return count;
	}

	// ʵ������ͼƬ�ķ���
	public int insertPicture(ClubPicture picture) throws Exception {
		int row = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.save(picture);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		return row;
	}

	// ʵ�ֲ�ѯ����ͼƬ�ķ���
	public List<ClubPicture> selAllPictures() throws Exception {
		List<ClubPicture> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Query query = session.createQuery("from ClubPicture pic where pic.clubNews is not null");
		list = query.list();
		return list;
	}

	// ʵ�ֲ�ѯÿ���������ͼƬ
	public List<ClubPicture> selAllPicturesByNewsId(int newsId) throws Exception {
		List<ClubPicture> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Query query = session
				.createQuery("from ClubPicture c where c.clubNews.newsId=?");
		query.setInteger(0, newsId);
		list = query.list();
		return list;
	}

	// ʵ�ֲ�ѯÿ������ͼƬ�ķ���
	public List<ClubPicture> selAllPicturesByPage(int pageIndex, int pageSize,
			int newsId) throws Exception {
		List<ClubPicture> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql = "from ClubPicture c where c.clubNews is not null";
		Query query = session.createQuery(hql);
		if (newsId != 0) {
			hql = "from ClubPicture c where c.clubNews.newsId=?";
			query = session.createQuery(hql);
			query.setInteger(0, newsId);
		}
		query.setFirstResult(pageSize * (pageIndex - 1));
		query.setMaxResults(pageSize);
		list = query.list();
		return list;
	}

	// ʵ���޸�ͼƬ�ķ���
	public int updatePicture(ClubPicture picture) throws Exception {
		int row = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.update(picture);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		return row;
	}

	public List<ClubPicture> selPicByNews() throws Exception {
		List<ClubPicture> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Query query = session.createQuery("from ClubPicture c where c.clubNews=null");
		list = query.list();
		return list;
	}

	

}
