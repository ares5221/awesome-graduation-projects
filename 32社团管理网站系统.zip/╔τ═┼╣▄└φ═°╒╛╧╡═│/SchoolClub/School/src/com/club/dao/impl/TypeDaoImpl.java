package com.club.dao.impl;

import org.hibernate.Session;

import com.club.dao.HibernateSessionFactory;
import com.club.dao.TypeDao;
import com.club.entity.ClubType;

public class TypeDaoImpl implements TypeDao{

	public ClubType getTypeById(int typeId) throws Exception{
		ClubType type=null;
		Session session=HibernateSessionFactory.getSession();
		session.clear();
	   type=(ClubType) session.get(ClubType.class, typeId);
	   return type;
	}

}
