package com.club.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.club.dao.HibernateSessionFactory;
import com.club.dao.MessageDao;
import com.club.entity.ClubActivity;
import com.club.entity.ClubMessage;

/**
 * ��������daoʵ����
 * 
 * @author Administrator
 * 
 */
public class MessageDaoImpl implements MessageDao {
	// ʵ��ɾ��������Ϣ�ķ���
	public int deleteMessage(int id) throws Exception {
		int row = 0;
		ClubMessage message = new ClubMessage();
		message.setMsgId(id);
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.delete(message);
			tx.commit();
			row = 1;		
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		return row;
	}

	// ʵ�ָ�������id��ȡ���Զ���ķ���
	public ClubMessage getMessageById(int id) throws Exception {
		ClubMessage message = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		message = (ClubMessage) session.get(ClubMessage.class, id);
		return message;
	}

	// ʵ������������Ϣ�ķ���
	public int insertMessage(ClubMessage message) throws Exception {
		int row = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.save(message);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		return row;
	}

	// ʵ�ֲ�ѯÿ����������������Ϣ�ķ���
	public List<ClubMessage> selAllMsgsByClubId(int cid) throws Exception {
		List<ClubMessage> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Query query = session
				.createQuery("from ClubMessage c where c.club.clubId=?");
		query.setInteger(0, cid);
		list = query.list();
		return list;
	}

	// ʵ���޸�������Ϣ�ķ���
	public int updateMessage(ClubMessage message) throws Exception {
		int row = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.update(message);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} 
		return row;
	}


  //ʵ�ֲ�ѯÿ�������µ�����������Ϣ
	public List<ClubMessage> selAllMsgsByPageNews(int pageIndex, int pageSize,
			int nid) throws Exception {
		List<ClubMessage> list=null;
		String hql="from ClubMessage c where c.clubNews.newsId=?";
		Session session=HibernateSessionFactory.getSession();
		session.clear();
		Query query=session.createQuery(hql);
		query.setInteger(0, nid);
		query.setFirstResult(pageSize*(pageIndex-1));
		query.setMaxResults(pageSize);
		list=query.list();
		return list;
	}
//ʵ�ֲ�ѯÿ�������µ�����������Ϣ
public int getMsgsCountByNews(int nid) throws Exception {
	int count = 0;
	Session session = HibernateSessionFactory.getSession();
	session.clear();
	String	hql = "select count(*) from  ClubMessage c where c.clubNews.newsId=?";
		Query query = session.createQuery(hql);
		query.setInteger(0, nid);
	count = Integer.parseInt(query.uniqueResult() + "");
	return count;
}

}
