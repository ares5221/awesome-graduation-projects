package com.club.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.club.dao.HibernateSessionFactory;
import com.club.dao.NewsDao;
import com.club.entity.Club;
import com.club.entity.ClubNews;

/**
 * ����daoʵ����
 * 
 * @author Administrator
 * 
 */
public class NewsDaoImpl implements NewsDao {
	// ʵ������������Ϣ�ķ���
	public int deleteNews(int id) throws Exception {
		int row = 0;
		ClubNews news = new ClubNews();
		news.setNewsId(id);
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.delete(news);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} 
		return row;
	}

	// ʵ�ָ�������id��ȡ���Ŷ���ķ���
	public ClubNews getNewsById(int id) throws Exception {
		ClubNews news = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		news = (ClubNews) session.get(ClubNews.class, id);
		return news;
	}

	// ʵ������������Ϣ�ķ���
	public int insertNews(ClubNews news) throws Exception {
		int row = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.save(news);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		return row;
	}

	// ʵ�ֲ�ѯ����������Ϣ�ķ���
	public List<ClubNews> selAllNews() throws Exception {
		List<ClubNews> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Query query = session.createQuery("from ClubNews c order by c.newsTime desc");
		list = query.list();
		return list;
	}

	// ʵ�ֲ�ѯÿ����������������Ϣ�ķ���
	public List<ClubNews> selAllNewsByPageClub(int pageIndex,int pageSize,int cid) throws Exception {
		List<ClubNews> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Query query = session
				.createQuery("from ClubNews c where c.club.clubId=? order by c.newsTime desc");
		query.setInteger(0, cid);
		query.setFirstResult(pageSize*(pageIndex-1));
		query.setMaxResults(pageSize);
		list = query.list();
		return list;
	}

	// ʵ���޸�������Ϣ�ķ���
	public int updateNews(ClubNews news) throws Exception {
		int row = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.update(news);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} 
		return row;
	}


	public int getNewsCount() throws Exception {
		int count = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql = "select count(*) from  ClubNews c";
		Query query = session.createQuery(hql);
			query = session.createQuery(hql);
		count = Integer.parseInt(query.uniqueResult() + "");
		return count;
	}

	public int getNewsCountByClub(int cid) throws Exception {
		int count = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql="select count(*) from ClubNews c where c.club.clubId=?";
		Query query = session.createQuery(hql);
			
			query.setInteger(0, cid);
		count = Integer.parseInt(query.uniqueResult() + "");
		return count;
	}


		// ʵ�ֲ�ѯÿҳ����������Ϣ
		public List<ClubNews> selAllNewsByPage(int pageIndex, int pageSize)throws Exception {
			List<ClubNews> list = null;
			Session session = HibernateSessionFactory.getSession();
			session.clear();
			String hql = "from ClubNews c order by c.newsTime desc";
			Query query = session.createQuery(hql);
			query.setFirstResult(pageSize * (pageIndex - 1));
			query.setMaxResults(pageSize);
			list = query.list();
			return list;

	}


}
