package com.club.dao;

import java.util.List;

import com.club.entity.ClubPicture;

/**
 * ���Żdao�ӿ�
 * 
 * @author Administrator
 * 
 */
public interface PictureDao {
	// ����ͼƬ
	public int insertPicture(ClubPicture picture) throws Exception;

	// ɾ��ͼƬ
	public int deletePicture(int id) throws Exception;

	// �޸�ͼƬ
	public int updatePicture(ClubPicture picture) throws Exception;

	// ��ѯÿ�������ͼƬ
	public List<ClubPicture> selAllPicturesByNewsId(int newsId) throws Exception;

	// ��ѯ����ͼƬ
	public List<ClubPicture> selAllPictures() throws Exception;

	// ��ѯÿҳ����ͼƬ
	public List<ClubPicture> selAllPicturesByPage(int pageIndex, int pageSize,
			int newsId) throws Exception;

	// ��ȡͼƬ����
	public int getPictureCount(int actId) throws Exception;
	
	public List<ClubPicture> selPicByNews()throws Exception;
	
}
