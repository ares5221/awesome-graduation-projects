package com.club.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.club.dao.ActivityDao;
import com.club.dao.HibernateSessionFactory;
import com.club.entity.ClubActivity;

/**
 * ���Żdaoʵ����
 * 
 * @author Administrator
 * 
 */
public class ActivityDaoImpl implements ActivityDao {
	// ʵ��ɾ�����Ϣ�ķ���
	public int deleteActivity(int id) throws Exception {
		int row = 0;
		ClubActivity activity = new ClubActivity();
		activity.setActId(id);
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.delete(activity);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		return row;
	}

	// ʵ�ָ��ݻid��ȡ�����ķ���
	public ClubActivity getActivityById(int id) throws Exception {
		ClubActivity activity = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		activity = (ClubActivity) session.get(ClubActivity.class, id);
		return activity;
	}

	// ʵ�����ӻ��Ϣ�ķ���
	public int insertActivity(ClubActivity activity) throws Exception {
		int row = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.save(activity);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} 
		return row;
	}


	// ʵ�ֲ�ѯÿ����������������Ϣ�ķ���
	public List<ClubActivity> selAllActs() throws Exception {
		List<ClubActivity> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Query query = session
				.createQuery("from ClubActivity c where c.actAudit=1 order by c.actTime desc");
		list = query.list();
	
		return list;
	}

	// ʵ���޸Ļ��Ϣ�ķ���
	public int updateActivity(ClubActivity activity) throws Exception {
		int row = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.update(activity);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		return row;
	}
 //ʵ�ֻ�ȡ���ҳ���ķ���
	public int getActsCountByClub(int cid) throws Exception {
		int count=0;
		Session session=HibernateSessionFactory.getSession();
		session.clear();
		String hql="select count(*) from  ClubActivity c where c.club.clubId=?";
		Query query=session.createQuery(hql);
		query.setInteger(0, cid);
		count=Integer.parseInt(query.uniqueResult()+"");
		return count;
	}
	
//ʵ�ֲ�ѯÿҳ���л��Ϣ�ķ���
	public List<ClubActivity> selAllActsByPageClub(int pageIndex, int pageSize,
			int cid) throws Exception {
		List<ClubActivity> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql="from ClubActivity c where c.club.clubId=?order by c.actAudit";
		Query query = session.createQuery(hql);
		query.setInteger(0, cid);
		query.setFirstResult(pageSize*(pageIndex-1));
		query.setMaxResults(pageSize);
		list = query.list();
		return list;
	}
	public List<ClubActivity> selAllActsByPageAudit1(int pageIndex, int pageSize) throws Exception {
		List<ClubActivity> list = null;
		Session session = HibernateSessionFactory.getSession();
		String hql="from ClubActivity c where c.actAudit=1 order by c.actTime desc";
		Query query = session.createQuery(hql);
		query.setFirstResult(pageSize*(pageIndex-1));
		query.setMaxResults(pageSize);
		list = query.list();
		return list;
	}
	public List<ClubActivity> selAllActsByPageAudit0(int pageIndex, int pageSize) throws Exception {
		List<ClubActivity> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql="from ClubActivity c where c.actAudit=0 order by c.actTime desc";
		Query query = session.createQuery(hql);
		query.setFirstResult(pageSize*(pageIndex-1));
		query.setMaxResults(pageSize);
		list = query.list();
		return list;
	}
public int getActsCountByAudit1()throws Exception{
	int count=0;
	Session session=HibernateSessionFactory.getSession();
	session.clear();
	String hql="select count(*) from  ClubActivity c where c.actAudit=1 ";
	Query	query=session.createQuery(hql);
	count=Integer.parseInt(query.uniqueResult()+"");
	return count;
};
	
	public int getActsCountByAudit0()throws Exception{
		int count=0;
		Session session=HibernateSessionFactory.getSession();
		session.clear();
		String hql="select count(*) from  ClubActivity c where c.actAudit=0";
		Query	query=session.createQuery(hql);
		count=Integer.parseInt(query.uniqueResult()+"");
		return count;
	};
}
