package com.club.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.club.dao.HibernateSessionFactory;
import com.club.dao.UserInfoDao;
import com.club.entity.ClubUser;
import com.club.service.impl.UserInfoServiceImpl;

/**
 * �û�daoʵ����
 * 
 * @author Administrator
 * 
 */
public class UserInfoDaoImpl implements UserInfoDao {
	// ʵ�ָ����û�id��ȡ�û�����ķ���
	public ClubUser getUserById(int id) throws Exception {
		ClubUser user = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		user = (ClubUser) session.get(ClubUser.class, id);
		return user;
	}

	// ʵ�������û��ķ���
	public int insertUser(ClubUser user) throws Exception {
		int row = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.save(user);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		return row;
	}

	// ʵ�ָ����û�����ȡ�û�����
	public ClubUser getUserByName(String name) throws Exception {
		ClubUser user = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Query query = session.createQuery("from ClubUser c where c.userName=?");
		query.setString(0, name);
		user = (ClubUser) query.uniqueResult();
		return user;
	}

	// ʵ��ɾ���û��ķ���
	public int deleteUser(ClubUser user) throws Exception {
		int row = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.delete(user);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}

		return row;
	}

	// ʵ���޸��û��ķ���
	public int updateUser(ClubUser user) throws Exception {
		int row = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.update(user);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}

		return row;
	}

	// ʵ�ָ���ҳ����ѯ�������µ����г�Ա
	public List<ClubUser> selAllUsersByClub(int clubId, int type,
			int pageIndex, int pageSize) throws Exception {
		List<ClubUser> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql = "from ClubUser u where u.club.clubId=? and u.clubType.typeId=?";
		Query query = session.createQuery(hql);
		query.setInteger(0, clubId);
		query.setInteger(1, type);
		query.setFirstResult(pageSize * (pageIndex - 1));
		query.setMaxResults(pageSize);
		list=query.list();
		return list;
	}
   
	//ʵ�ֻ�ȡ���г�Ա������
	public int getUsersCount(int type) throws Exception {
		int count = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql = "select count(*) from ClubUser u where  u.clubType.typeId=?";
		Query query = session.createQuery(hql);
		query.setInteger(0, type);
		count = Integer.valueOf(query.uniqueResult() + "");
		return count;
	}
 
	//ʵ�ֻ�ȡ�������µ����г�Ա����
	public int getUsersCountByClub(int clubId, int type) throws Exception {
		int count = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql = "select count(*) from ClubUser u where u.club.clubId=? and  u.clubType.typeId=?";
		Query query = session.createQuery(hql);
		query.setInteger(0, clubId);
		query.setInteger(1, type);
		count = Integer.valueOf(query.uniqueResult() + "");
		return count;
	}
 
	//ʵ��ÿҳ��ѯ���г�Ա�ķ���
	public List<ClubUser> selAllUsers(int type, int pageIndex, int pageSize)
			throws Exception {
		List<ClubUser> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql = "from ClubUser u where  u.clubType.typeId=?";
		Query query = session.createQuery(hql);
		query.setInteger(0, type);
		query.setFirstResult(pageSize * (pageIndex - 1));
		query.setMaxResults(pageSize);
		list=query.list();
		return list;
	}

	//ʵ�ֲ�ѯ���и������µĳ�Ա
	public List<ClubUser> selAllUsers(int clubId, int type) {
		List<ClubUser> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql = "from ClubUser u where u.club.clubId=? and u.clubType.typeId=?";
		Query query = session.createQuery(hql);
		query.setInteger(0, clubId);
		query.setInteger(1, type);
		list=query.list();
		return list;
	}

}
