package com.club.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.club.dao.ClubDao;
import com.club.dao.HibernateSessionFactory;
import com.club.entity.Club;
import com.club.entity.ClubActivity;

/**
 * ����daoʵ����
 * 
 * @author Administrator
 * 
 */
public class ClubDaoImpl implements ClubDao {
	// ʵ��ɾ��������Ϣ�ķ���
	public int deleteClub(int id) throws Exception {
		int row = 0;
		Club club = new Club();
		club.setClubId(id);
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.delete(club);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} 
		return row;
	}

	// ʵ�ָ���id��ȡ���Ŷ���ķ���
	public Club getClubById(int id) throws Exception {
		Club club = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		club = (Club) session.get(Club.class, id);
		return club;
	}

	// ʵ���������ŵķ���
	public int insertClub(Club club) throws Exception {
		int row = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.save(club);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();

		}
		return row;
	}

	// ʵ�ֲ�ѯ�������ŵķ���
	public List<Club> selAllClubs() throws Exception {
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		List<Club> list = null;
		Query query = session.createQuery("from Club c where c.clubAudit=1 order by c.clubDate desc");
		list = query.list();
		return list;
	}

	// ʵ���޸����ŵķ���
	public int updateClub(Club club) throws Exception {
		int row = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		Transaction tx = session.beginTransaction();
		try {
			session.update(club);
			tx.commit();
			row = 1;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		return row;
	}

	// ʵ�ֻ�ȡ�����
	public int getClubsCountByAudit1() throws Exception {
		int count = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql = "select count(*) from  Club c where c.clubAudit=1";
		Query query = session.createQuery(hql);
		count = Integer.parseInt(query.uniqueResult() + "");
		return count;
	}


   //ʵ�ֻ�ȡÿ������Ա�µ���������
	public int getClubsCountByAudit0() throws Exception {
		int count = 0;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql = "select count(*) from  Club c where c.clubAudit=0";
		Query query = session.createQuery(hql);
		count = Integer.parseInt(query.uniqueResult() + "");
		return count;
	}


	public List<Club> selAllClubsByPageAudit0(int pageIndex, int pageSize)
			throws Exception {
		List<Club> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql = "from  Club c where c.clubAudit=0 order by c.clubDate desc";
		Query query = session.createQuery(hql);
		query.setFirstResult(pageSize * (pageIndex - 1));
		query.setMaxResults(pageSize);
		list = query.list();
		return list;
	}

	public List<Club> selAllClubsByPageAudit1(int pageIndex, int pageSize)
			throws Exception {
		List<Club> list = null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql = "from  Club c where c.clubAudit=1 order by c.clubDate desc";
		Query query = session.createQuery(hql);
		query.setFirstResult(pageSize * (pageIndex - 1));
		query.setMaxResults(pageSize);
		list = query.list();
		return list;
	}

	public List<Club> selClubByAdminId(int uid) throws Exception {
		List<Club> list=null;
		Session session = HibernateSessionFactory.getSession();
		session.clear();
		String hql = "from  Club c where c.clubUser.userId=? order by c.clubAudit";
		Query query = session.createQuery(hql);
		query.setInteger(0, uid);
		list=query.list();
		return list;
	}

	public Club getClubByName(String name) throws Exception {
	Club club=null;
	Session session=HibernateSessionFactory.getSession();
	session.clear();
	String hql="from Club c where c.clubName=?";
	Query query=session.createQuery(hql);
	return club;
	}

}
