package com.club.dao;

import com.club.entity.ClubType;

public interface TypeDao {
 public ClubType getTypeById(int typeId)throws Exception;
}
