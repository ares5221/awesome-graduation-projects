package com.club.random;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ��ȡһ�����ͼƬ��ʵ�ֵ��빦��
 * 
 * @author Administrator
 * 
 */
public class RandomNum extends HttpServlet {
	// ��һ������������ͼ�εĿ���
	public static final int WIDTH = 80;
	// ��һ������������ͼ�εĸ߶�
	public static final int HEIGHT = 20;

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		BufferedImage image = new BufferedImage(WIDTH, HEIGHT,
				BufferedImage.TYPE_INT_RGB);
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		Graphics g = image.getGraphics();
		// ����ͼ�α���ɫ
		setBackGround(g);
		// ����ͼ�α߿�
		setBorder(g);
		// ��������
		drawRandomLine(g);
		// д�����
		String random=drawRandomNum((Graphics2D)g);
		request.getSession().setAttribute("imageCheckCode",random);
		// д�������
		response.setContentType("image/jpeg");
		//�����������Ҫ����
		response.setDateHeader("exprise", -1);
		response.setHeader("Cache-Control","no-cache");
		response.setHeader("Pragma","no-cache");
		ImageIO.write(image, "jpg", response.getOutputStream());
	}

	// д�����
	private String drawRandomNum(Graphics2D g) {
		// TODO Auto-generated method stub
		g.setColor(Color.RED);
		g.setFont(new Font("����",Font.BOLD, 20));
		String base="0123456789";
		//[\u4e00-\u9fa5]
		StringBuffer sb=new StringBuffer();
		int x=10;
		for (int i = 0; i <4; i++) {
			int degree=new Random().nextInt()%23;
			String ch=base.charAt(new Random().nextInt(base.length()))+"";
			sb.append(ch);
			g.rotate(degree*Math.PI/180, x, 20);//������ת�Ƕ�
			g.drawString(ch, x, 20);
			g.rotate(-degree*Math.PI/180, x, 20);
			x=x+15;
		}
		return sb.toString();
	}

	// ��������
	private void drawRandomLine(Graphics g) {
		// TODO Auto-generated method stub
		g.setColor(Color.BLACK);
		for (int i = 0; i <3; i++) {
			int x1 = new Random().nextInt(WIDTH - 10);
			int y1 = new Random().nextInt(HEIGHT - 5);
			int x2 = new Random().nextInt(WIDTH - 10);
			int y2 = new Random().nextInt(HEIGHT - 5);
			g.drawLine(x1, y1, x2, y2);
		}
	}

	// ����ͼ�α���ɫ����ͼ�α߿�
	private void setBorder(Graphics g) {
		g.setColor(Color.BLACK);
		g.drawRect(1, 1, WIDTH - 2, HEIGHT - 2);

	}

	// ����ͼ�α���ɫ
	private void setBackGround(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, WIDTH, HEIGHT);
	}

	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}
}
