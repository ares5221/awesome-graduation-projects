if (document.all){
msg="欢迎来到杭州电子科技社团网";
msgColor="#FF9900";
msgFont="Verdana";
msg=msg.split('');
n=msg.length;
e=360/n;
yp=0;
xp=0;
yb=40;
xb=60;
sa=0.07;
sb=0;
pa=new Array();
pb=new Array();
for (i=0; i < n; i++){
document.write('<div id="logo" style="position:absolute;top:0;left:0;'
+'height:30px;width:60px;font-family:'+msgFont+';text-align:center;font-weight: bold;color:'+msgColor+'">'+msg[i]+'</div>');
}
function ani(){
yp=55;
xp=document.body.scrollLeft+window.document.body.clientWidth-1050;
for (i=0; i < n; i++){
logo[i].style.top =yp+yb*Math.sin(sb+i*e*Math.PI/180);
logo[i].style.left=xp+xb*Math.cos(sb+i*e*Math.PI/180);
pb[i]=logo[i].style.pixelTop-yp;
pa[i]=pb[i]-pb[i]*2;
if (pa[i] < 1){
pa[i]=0;
logo[i].style.visibility='hidden';
}
else logo[i].style.visibility='visible';
logo[i].style.fontSize=pa[i]/2.7;
}
sb-=sa;
setTimeout('ani()',100);
}
window.onload=ani;
}

//增大字体
function ChangeSize(size){	var objSize=document.getElementById('container');objSize.style.fontSize=size+"px";}
function ChangeSize1(size){	
	
	var objSize=document.getElementsByTagName("p");
	for(var i=0;i<objSize.length;i++){
		objSize[i].style.fontSize=size+"px";
	}
	}
function AddFav(){	window.external.AddFavorite(window.document.location.href, document.title)}