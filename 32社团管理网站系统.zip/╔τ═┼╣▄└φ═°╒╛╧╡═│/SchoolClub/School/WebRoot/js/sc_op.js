 function tab(a){
	 var d=$("main"+a);
	 $("tab"+a).className="on";

	 d.style.display="block";
	 for(var i=0;i<3;i++){
		 
		 if(i!=a){
			 $("tab"+i).className="";
			 $("main"+i).style.display="none";
		 }
	 }
	 
 }

/*得到制定元素*/
function $ (id){
	return document.getElementById(id);
	}

/*实现用户名焦点验证*/

	/*实现密码焦点验证*/
function pwdFocus(){
	var pwdId=$("box_U_Pass");
	pwdId.innerHTML="请输入密码";
	pwdId.className="import_prompt";
	}
 /*实现密码移开验证*/
function pwdBlur(){
	var pwd=$("pwd").value;
	var pwdId=$("box_U_Pass");
	if(pwd==""){
		pwdId.innerHTML="原密码不能为空";
		pwdId.className="error_prompt";
		return false;
		}
	 if(pwd.length<6||pwd.length>13){
		pwdId.innerHTML="密码格式长度在6-13之间";
		pwdId.className="error_prompt";
		return false;
		}
		pwdId.innerHTML="原密码输入正确";
		pwdId.className="ok_prompt";
		return true;
			
	
	}

function newpwdFocus(){
	var pwdId=$("box_U_newPwd");
	pwdId.innerHTML="请输入新密码";
	pwdId.className="import_prompt";
	}
 /*实现密码移开验证*/
function newpwdBlur(){
	var pwd=$("newpwd").value;
	var pwdId=$("box_U_newPwd");
	if(pwd==""){
		pwdId.innerHTML="原密码不能为空";
		pwdId.className="error_prompt";
		return false;
		}
	 if(pwd.length<6||pwd.length>13){
		pwdId.innerHTML="密码格式长度在6-13之间";
		pwdId.className="error_prompt";
		return false;
		}
		pwdId.innerHTML="新密码输入正确";
		pwdId.className="ok_prompt";
		return true;
			
	
	}


	/*实现重复密码移开验证*/
function repwdBlur(){
	var repwd=$("oknewpwd").value;
	var pwd=$("newpwd").value;
	var repwdId=$("box_U_oknewPwd");
	if(repwd==""){
		repwdId.innerHTML="重置密码不能为空";
		repwdId.className="error_prompt";
		return false;
		}
	 if(repwd!=pwd){
		repwdId.innerHTML="两个密码不一致，请重新输入密码";
		repwdId,className="error_prompt";
		return false;
		}
		repwdId.innerHTML="重复输入密码正确";
		repwdId.className="ok_prompt";
       return true;
	
	} 

function repwdFocus(){
	var pwdId=$("box_U_oknewPwd");
	pwdId.innerHTML="请输入确认密码";
	pwdId.className="import_prompt";
	}
	
	/*实现手机号焦点验证*/
function telFocus(){
	var telId=$("box_U_Mobile");
	telId.innerHTML="请输入您的手机号";
	telId.className="import_prompt";
	}
	/*实现手机移开验证*/
function telBlur(){
 var tel=$("mobile").value;
 var telId=$("box_U_Mobile");
 var str=/^13\d{9}$|^15\d{9}$|^18\d{9}$/;//手机号码的正则表达式
 if(tel==""){
	 telId.innerHTML="手机号码不能为空";
	 telId.className="error_prompt";
	 return false;
	 }
	 if(str.test(tel)==false){
		telId.innerHTML="手机号格式不正确";
		telId.className="error_prompt";
		return false;
		}
		telId.innerHTML="手机号输入正确";
		telId.className="ok_prompt";
		return true;
	}



function realNameBlur(){
	var realname=$("realname").value;
	if(realname==""){
		$("box_U_RealName").innerHTML="真实姓名不能为空";
		$("box_U_RealName").className="error_prompt";
		return false;
	}
	
	$("#box_U_RealName").innerHTML="真实姓名输入正确";
	$("#box_U_RealName").className="ok_prompt";
	return true;
	
}
function realNameFocus(){
	$("#box_U_RealName").innerHTML="请输入您的真实姓名";
	$("#box_U_RealName").className="import_prompt";
	
}




function nickBlur(){
	var nick=$("nick").value;
	var len=nick.replace(/[\u4e00-\u9fa5]/g,"xx").length;
	if(nick==""){
		$("box_U_Nick").innerHTML="昵称不能为空";
		$("box_U_Nick").className="error_prompt";
		return false;
	}
	 if(len<4||len>20){
		$("box_U_Nick").innerHTML="昵称长度在4-20之间";
		$("box_U_Nick").className="error_prompt";
		return false;
	}
	$("box_U_Nick").innerHTML="昵称输入正确";
	$("box_U_Nick").className="ok_prompt";
	return true;
}
function nickFocus(){
	$("box_U_Nick").innerHTML="请输入您的昵称";
	$("box_U_Nick").className="import_prompt";
	
}



function ageBlur(){
	var age=$("age").value;
	if(age==""){
		$("box_U_Age").innerHTML="年龄不能为空";
		$("box_U_Age").className="error_prompt";
		return false;
	}
	
	$("box_U_Age").innerHTML="年龄输入正确";
	$("box_U_Age").className="ok_prompt";
	return true;
}
function ageFocus(){
	$("box_U_Age").innerHTML="请输入您的真实年龄";
	$("box_U_Age").className="import_prompt";
	
}

function addressBlur(){
	var address=$("address").value;
	if(address==""){
		$("box_U_Address").innerHTML="住址不能为空";
		$("box_U_Address").className="error_prompt";
		return false;
	}else{
		$("box_U_Address").innerHTML="住址输入正确";
		$("box_U_Age").className="ok_prompt";
		return true;
	}
	
}

function addressFocus(){
	$("box_U_Address").innerHTML="请输入您的地址";
	$("box_U_Address").className="import_prompt";
	
}


function clsBlur(){
	var cls=$("cls").value;
	if(cls==""){
		$("box_U_Cls").innerHTML="班级不能为空";
		$("box_U_Cls").className="error_prompt";
		return false;
	}

	$("box_U_Cls").innerHTML="班级输入正确";
	$("box_U_Cls").className="ok_prompt";
	return true;
}

function clsFocus(){
	
	$("box_U_Cls").innerHTML="请输入你的班级";
	$("box_U_Cls").className="import_prompt";
}

function checkPwd(){
	if(pwdBlur()==true&&newpwdBlur()==true&&repwdBlur()==true){
		alert(12);
	return true;
		
	}
	else{
		return false;
	}
}

function checkUp(){
		 var image=$("file_upload").value;
		if(image==""){
			alert("请选择头像！");
			return false;
		}
		return true;
}

function checkUser(){
	if(clsBlur()==true&&ageBlur()==true&&nickBlur()==true&&realNameBlur()==true&&addressBlur()==true){
		return true;
	}else{
		return false;
	}
	
}