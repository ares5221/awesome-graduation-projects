﻿$(document).ready(function(){
	$("#name").bind("blur",nameBlur);
	$("#name").bind("focus",function(){
		$("#box_U_Name").text("请输入用户名");
		$("#box_U_Name").removeClass();
		$("#box_U_Name").addClass("import_prompt");
		
	});
	
	function nameBlur(){
		var str=/^[a-zA-Z]\w{5,13}$/;
		var name=$("#name").val();
		if(name==""){
			$("#box_U_Name").text("用户名不能为空");
			$("#box_U_Name").addClass("error_prompt");
			return false;
		}
		 if(!str.test(name)){
			$("#box_U_Name").text("用户名要以字母开头而且6-12位");
			$("#box_U_Name").addClass("error_prompt");
			return false;
		}
		 $.ajax({
			 dataType:"json",
			 type:"post",
			 url:"checkUser_user.action?user.userName="+name,
			 success:function(data){
			
			 if(data.status=="1"){
				 $("#box_U_Name").text("用户名输入正确");
					$("#box_U_Name").addClass("ok_prompt");
			 }else{
				
				 $("#box_U_Name").text("用户名已存在");
					$("#box_U_Name").addClass("error_prompt");
			 }
			
			 
		 }
		 });
	
		return true;
	}
	
	
	$("#username").bind("blur",usernameBlur);
	$("#username").bind("focus",function(){
		$("#box_U_UserName").text("请输入用户名");
		$("#box_U_UserName").removeClass();
		$("#box_U_UserName").addClass("import_prompt");
		
	});
	
	function usernameBlur(){
		var str=/^[a-zA-Z]\w{5,13}$/;
		var name=$("#username").val();
		if(name==""){
			$("#box_U_UserName").text("用户名不能为空");
			$("#box_U_UserName").addClass("error_prompt");
			return false;
		}
		 if(!str.test(name)){
			$("#box_U_UserName").text("用户名要以字母开头而且6-12位");
			$("#box_U_UserName").addClass("error_prompt");
			return false;
		}
		 $("#box_U_UserName").text("用户名输入正确");
			$("#box_U_UserName").addClass("ok_prompt");
		
		return true;
	}
	
	
	$("#pwd").bind("blur",pwdBlur);
	function pwdBlur(){
		var pwd=$("#pwd").val();
		if(pwd==""){
			$("#box_U_Pass").text("密码不能为空");
			$("#box_U_Pass").addClass("error_prompt");
			return false;
		}
		 if(pwd.length<6||pwd.length>13){
			 $("#box_U_Pass").text("密码格式长度在6-13之间");
				$("#box_U_Pass").addClass("error_prompt");
				return false;
		}
		$("#box_U_Pass").text("密码输入正确");
		$("#box_U_Pass").addClass("ok_prompt");
		return true;
	}
	$("#pwd").bind("focus",function(){
		$("#box_U_Pass").text("请输入密码");
		$("#box_U_Pass").removeClass();
		$("#box_U_Pass").addClass("import_prompt");
		
	});
	
	
	
	$("#okpwd").bind("blur",okpwdBlur);
	function okpwdBlur(){
		var okpwd=$("#okpwd").val();
		var pwd=$("#pwd").val();
		if(okpwd==""){
			$("#box_U_okPass").text("确认密码不能为空");
			$("#box_U_okPass").addClass("error_prompt");
			return false;
		}
		if(pwd!=okpwd){
			$("#box_U_okPass").text("两次密码输入不一致");
			$("#box_U_okPass").addClass("error_prompt");
			return false;
		}
		$("#box_U_okPass").text("确认密码输入正确");
		$("#box_U_okPass").addClass("ok_prompt");
		return true;
	}
	$("#okpwd").bind("focus",function(){
		$("#box_U_okPass").text("请输入确认密码");
		$("#box_U_okPass").removeClass();
		$("#box_U_okPass").addClass("import_prompt");
		
	});
	
	
	$("#oknewpwd").bind("blur",okpwdBlur);
	function oknewpwdBlur(){
		var oknewpwd=$("#oknewpwd").val();
		var pwd=$("#newpwd").val();
		if(oknewpwd==""){
			$("#box_U_oknewPass").text("确认密码不能为空");
			$("#box_U_oknewPass").addClass("error_prompt");
			return false;
		}
		if(pwd!=oknewpwd){
			$("#box_U_oknewPass").text("两次密码输入不一致");
			$("#box_U_oknewPass").addClass("error_prompt");
			return false;
		}
		$("#box_U_okPass").text("确认密码输入正确");
		$("#box_U_okPass").addClass("ok_prompt");
		return true;
	}
	$("#oknewpwd").bind("focus",function(){
		$("#box_U_oknewPass").text("请输入确认密码");
		$("#box_U_oknewPass").removeClass();
		$("#box_U_oknewPass").addClass("import_prompt");
		
	});
	
	
	$("#newpwd").bind("blur",okpwdBlur);
	function newpwdBlur(){

		var pwd=$("#newpwd").val();
		if(pwd==""){
			$("#box_U_newPass").text("新密码不能为空");
			$("#box_U_newPass").addClass("error_prompt");
			return false;
		}
		
		$("box_U_newPass").text("新密码输入正确");
		$("#box_U_newPass").addClass("ok_prompt");
		return true;
	}
	$("#newpwd").bind("focus",function(){
		$("#box_U_newPass").text("请输入确认密码");
		$("#box_U_newPass").removeClass();
		$("#box_U_newPass").addClass("import_prompt");
		
	});
	
	
	$("#realname").bind("blur",realNameBlur);
	function realNameBlur(){
		var realname=$("#realname").val();
		if(realname==""){
			$("#box_U_RealName").text("真实姓名不能为空");
			$("#box_U_RealName").addClass("error_prompt");
			return false;
		}
		
		$("#box_U_RealName").text("真实姓名输入正确");
		$("#box_U_RealName").addClass("ok_prompt");
		return true;
		
	}
	$("#realname").bind("focus",function(){
		$("#box_U_RealName").text("请输入真实姓名");
		$("#box_U_RealName").removeClass();
		$("#box_U_RealName").addClass("import_prompt");
		
	});
	
	
	
	$("#nick").bind("blur",nickBlur);
	function nickBlur(){
		var nick=$("#nick").val();
		var len=nick.replace(/[\u4e00-\u9fa5]/g,"xx").length;
		if(nick==""){
			$("#box_U_Nick").text("昵称不能为空");
			$("#box_U_Nick").addClass("error_prompt");
			return false;
		}
		 if(len<4||len>20){
			$("#box_U_Nick").text("昵称长度在4-20之间");
			$("#box_U_Nick").addClass("error_prompt");
			return false;
		}
		$("#box_U_Nick").text("昵称输入正确");
		$("#box_U_Nick").addClass("ok_prompt");
		return true;
	}
	$("#nick").bind("focus",function(){
		$("#box_U_Nick").text("请输入昵称");
		$("#box_U_Nick").removeClass();
		$("#box_U_Nick").addClass("import_prompt");
		
	});
	
	
	
	$("#age").bind("blur",ageBlur);
	function ageBlur(){
		var age=$("#age").val();
		if(age==""){
			$("#box_U_Age").text("年龄不能为空");
			$("#box_U_Age").addClass("error_prompt");
			return false;
		}
		
		$("#box_U_Age").text("年龄输入正确");
		$("#box_U_Age").addClass("ok_prompt");
		return true;
	}
	$("#age").bind("focus",function(){
		$("#box_U_Age").text("请输入您的真实年龄");
		$("#box_U_Age").removeClass();
		$("#box_U_Age").addClass("import_prompt");
		
	});
	
	$("#code").bind("blur",codeBlur);
	function codeBlur(){
		var code=$("#code").val();
		if(code==""){
			$("#box_Code").text("验证码不能为空");
			$("#box_Code").addClass("error_prompt");
			return false;
		}
		return true;
	}
	$("#code").bind("focus",function(){
		$("#box_Code").text("请输入验证码");
		$("#box_Code").removeClass();
		$("#box_Code").addClass("import_prompt");
		
	});
	
	
	
	
	$("#cls").bind("blur",clsBlur);
	function clsBlur(){
		var cls=$("#cls").val();
		if(cls==""){
			$("#box_U_Cls").text("班级不能为空");
			$("#box_U_Cls").addClass("error_prompt");
			return false;
		}
	
		$("#box_U_Cls").text("班级输入正确");
		$("#box_U_Cls").addClass("ok_prompt");
		return true;
	}
	$("#cls").bind("focus",function(){
		$("#box_U_Cls").text("请输入班级");
		$("#box_U_Cls").removeClass();
		$("#box_U_Cls").addClass("import_prompt");
		
	});
	
	
	$("#phone").bind("blur",phoneBlur);
	function phoneBlur(){
		
		var str=/^13\d{9}$|^15\d{9}$|^18\d{9}$/;//手机号码的正则表达式
		var phone=$("#phone").val();
		if(phone==""){
			$("#box_U_Mobile").text("联系电话不能为空");
			$("#box_U_Mobile").addClass("error_prompt");
			return false;
		}
	 if(!str.test(phone)){
		 $("#box_U_Mobile").text("联系电话必须是以13,15,18开头的");
			$("#box_U_Mobile").addClass("error_prompt");
			return false;
	 }
		$("#box_U_Mobile").text("联系电话输入正确");
		
		$("#box_U_Mobile").addClass("ok_prompt");
		return true;
	}
	$("#phone").bind("focus",function(){
		$("#box_U_Mobile").text("请输入联系电话");
		$("#box_U_Mobile").removeClass();
		$("#box_U_Mobile").addClass("import_prompt");
		
	});
	
	$("#address").bind("blur",addressBlur);
	function addressBlur(){
		var address=$("#address").val();
		if(address==""){
			$("#box_U_Address").text("住址不能为空");
			$("#box_U_Address").addClass("error_prompt");
			return false;
		}
	
		$("#box_U_Address").text("住址输入正确");
		$("#box_U_Address").addClass("ok_prompt");
		return true;
	}
	$("#address").bind("focus",function(){
		$("#box_U_Address").text("请输入住址");
		$("#box_U_Address").removeClass();
		$("#box_U_Address").addClass("import_prompt");
		
	});
	
	
   $("#prop").bind("click",function(){
	   $("#ima").attr("src","randomImage?r="+Math.random()+"");
   });
   
   $("#reprop").bind("click",function(){
	   $("#ima").attr("src","randomImage?r="+Math.random()+"");
   });
	$("#register").bind("click",function(){
		if(nameBlur()==true&&pwdBlur()==true&&okpwdBlur()==true&&realNameBlur()==true&&nickBlur()==true&&ageBlur()==true&&clsBlur()==true&&addressBlur()==true&&phoneBlur()==true&&codeBlur()==true){
			return true;
		}else{
			return false;
		}
		
	});
	$("#login").bind("click",function(){
		if(nameBlur()==true&&pwdBlur()==true&&codeBlur()==true){
			return true;
		}else{
			return false;
		}
		
	});
	
	
});