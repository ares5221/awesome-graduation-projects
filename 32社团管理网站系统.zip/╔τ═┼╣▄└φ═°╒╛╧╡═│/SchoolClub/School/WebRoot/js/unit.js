function j(element){
return document.getElementById(element);
}
var dome=j("dome");
var dome1=j("dome1");
var dome2=j("dome2");
var speed=30; //设置向上滚动速度
dome2.innerHTML=dome1.innerHTML; //复制dome1为dome2
function moveTop(){
if(dome2.offsetTop-dome.scrollTop<=0) //当滚动至dome1与dome2交界时
dome.scrollTop-=dome1.offsetHeight; //dome跳到最顶端
else{
dome.scrollTop++;
}
}
var MyMar=setInterval(moveTop,speed); //设置定时器
dome.onmouseover=function() {clearInterval(MyMar);} //鼠标移上时清除定时器达到滚动停止的目的
dome.onmouseout=function() {MyMar=setInterval(moveTop,speed);} //鼠标移开时重设定时器，继续滚动 

