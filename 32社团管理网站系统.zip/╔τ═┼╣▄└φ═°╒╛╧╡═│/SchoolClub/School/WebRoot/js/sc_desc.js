 $(document).ready(function(){
        
       $("#greenxf").bind("load",start());
      
      });
     var k=0;
        var imgname1="image/index";    //这里是图片存放的位置  
        var imgname2=".jpg";          //这个是文件的格式  
        var imgnub=4;
       function start()
        {
    if (k<imgnub)
            {
                k++;
            }
            else
            {
                k=1;
            }

            var s=imgname1+k+imgname2;
            $("#zjl_").attr("src",s);
            setTimeout(start,3000);
        }