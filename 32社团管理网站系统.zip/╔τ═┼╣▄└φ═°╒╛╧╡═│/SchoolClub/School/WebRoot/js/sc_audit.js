$(document).ready(function(){
	$("#name").bind("blur",nameBlur);
	$("#name").bind("focus",function(){
		$("#box_c_Name").text("请输入社团名称");
		$("#box_c_Name").removeClass();
		$("#box_c_Name").addClass("import_prompt");
		
	});
	function nameBlur(){
		var name=$("#name").val();
		if(name==""){
			$("#box_c_Name").text("社团名称不能为空");
			$("#box_c_Name").addClass("error_prompt");
			return false;
		}
		
		
		 $.ajax({
			 dataType:"json",
			 type:"post",
			 url:"checkClub_club.action?club.clubName="+encodeURI(encodeURI(name)),
			 success:function(data){
			 if(data.status=="1"){
				 $("#box_c_Name").text("社团名称输入正确");
					$("#box_c_Name").addClass("ok_prompt");
			 }else{
				 $("#box_c_Name").text("社团名称已存在");
					$("#box_c_Name").addClass("error_prompt");
			 }
			
			 
		 }
		 });
		
	
		return true;
	}

	
	
	$("#desc").bind("blur",descBlur);
	function descBlur(){
		var desc=$("#desc").val();
		if(desc==""){
			$("#box_c_desc").text("社团介绍不能为空");
			$("#box_c_desc").addClass("error_prompt");
			return false;
		}
		
		$("#box_c_desc").addClass("ok_prompt");
		return true;
	}
	$("#desc").bind("focus",function(){
		$("#box_c_desc").text("请输入社团介绍");
		$("#box_c_desc").removeClass();
		$("#box_c_desc").addClass("import_prompt");
		
	});
	
	$("#code").bind("blur",codeBlur);
	function codeBlur(){
		var code=$("#code").val();
		if(code==""){
			$("#box_Code").text("验证码不能为空");
			$("#box_Code").addClass("error_prompt");
			return false;
		}
		return true;
	}
	$("#code").bind("focus",function(){
		$("#box_Code").text("请输入验证码");
		$("#box_Code").removeClass();
		$("#box_Code").addClass("import_prompt");
		
	});
	
	
	 $("#prop").bind("click",function(){
		   $("#ima").attr("src","randomImage?r="+Math.random()+"");
	   });
	   
	   $("#reprop").bind("click",function(){
		   $("#ima").attr("src","randomImage?r="+Math.random()+"");
	   });
	$("#audit").bind("click",function(){
		if(nameBlur()==true&&codeBlur()==true){
			return true;
		}else{
			return false;
		}
		
	});
	
});