/*
Navicat MySQL Data Transfer

Source Server         : ares
Source Server Version : 50132
Source Host           : localhost:3306
Source Database       : schoolclub

Target Server Type    : MYSQL
Target Server Version : 50132
File Encoding         : 65001

Date: 2015-04-14 20:16:51
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `club`
-- ----------------------------
DROP TABLE IF EXISTS `club`;
CREATE TABLE `club` (
  `club_id` int(11) NOT NULL AUTO_INCREMENT,
  `club_name` varchar(50) DEFAULT NULL,
  `club_user_id` int(30) DEFAULT NULL,
  `club_date` date DEFAULT NULL,
  `club_description` varchar(4000) DEFAULT NULL,
  `club_audit` int(11) DEFAULT NULL,
  PRIMARY KEY (`club_id`),
  KEY `fk_user_id` (`club_user_id`),
  CONSTRAINT `fk_user_id` FOREIGN KEY (`club_user_id`) REFERENCES `club_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of club
-- ----------------------------
INSERT INTO `club` VALUES ('1', '双节棍协会', '2', '2015-04-13', '长治学院双节协会 本协会以“强身健体，以棍会友,推动双节棍运动发展”为宗旨,努力将双节棍发展成一项时尚的运动，给广大的双节棍爱好者提供一个交流的平台,一个学习的空间,一个锻炼自己,完善自己的机会。\r\n\r\n本协会会员享有的会员权利与义务，及时和反应会员的愿望和要求。有针对性的开展独特的文化活动，锻炼会员当众玩双节棍的胆量，增强同学玩双节棍的能力，提高同学们的技术水平和实战能力。以灵活多样的形式让双节棍融入到同学的生活中，增强同学们玩双节棍的兴趣。', '1');
INSERT INTO `club` VALUES ('2', '吉他协会', '4', '2015-03-12', '创会以来，我们始终如一地坚持我们的宗旨“丰富课余生活陶冶学生情操 加强同学交流 提高演奏水平”。她聚集了一批又一批的爱吉他，爱音乐，热血 叛逆 甚至疯狂的青年，这是青春的怒放。也以此带动全校学生，奉献了n多场视听盛宴。当然我们的付出也一直受到学校，社联的支持与肯定，鼓舞着协会往更好的方向发展，争取做更多活动，丰富同学们的大学生活。', '1');
INSERT INTO `club` VALUES ('15', '街舞堂', '14', '2015-04-07', '', '1');
INSERT INTO `club` VALUES ('17', 'E族联盟与电子竞技', '19', '2015-04-08', 'kk', '1');
INSERT INTO `club` VALUES ('18', 'jj', '20', '2015-04-08', 'jj', '1');

-- ----------------------------
-- Table structure for `club_activity`
-- ----------------------------
DROP TABLE IF EXISTS `club_activity`;
CREATE TABLE `club_activity` (
  `act_id` int(11) NOT NULL AUTO_INCREMENT,
  `act_title` varchar(100) DEFAULT NULL,
  `act_content` varchar(2000) DEFAULT NULL,
  `act_club_id` int(11) DEFAULT NULL,
  `act_address` varchar(200) DEFAULT NULL,
  `act_time` date DEFAULT NULL,
  `act_user_id` int(30) DEFAULT NULL,
  `act_audit` int(11) DEFAULT NULL,
  `act_pic` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`act_id`),
  KEY `FK_club_act` (`act_club_id`),
  KEY `fk_user` (`act_user_id`),
  CONSTRAINT `FK_club_act` FOREIGN KEY (`act_club_id`) REFERENCES `club` (`club_id`),
  CONSTRAINT `fk_user` FOREIGN KEY (`act_user_id`) REFERENCES `club_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of club_activity
-- ----------------------------
INSERT INTO `club_activity` VALUES ('1', '参加市文艺团的文艺演出', '<strong>参加市文艺团的文艺演出</strong>', '2', '市立大剧院', '2015-04-01', '13', '1', null);
INSERT INTO `club_activity` VALUES ('2', '音乐节', '<p>参加音乐节</p>', '1', '学校体育馆', '2015-04-01', '3', '1', 'userfiles/zhangsan/42a682a4-4bfb-4b86-8456-e512525b1867.gif');
INSERT INTO `club_activity` VALUES ('3', '2014年双节棍比赛', '2014年双节棍比赛', '1', '学校体育馆', '2015-04-01', '11', '1', 'userfiles/zhangsan/e8789531-e2a5-4030-92eb-220fa43fe5a9.jpg');
INSERT INTO `club_activity` VALUES ('4', '双节棍体验', '双节棍体验体验', '1', '学校操场', '2015-04-01', '3', '1', null);
INSERT INTO `club_activity` VALUES ('5', '2014音乐节', '2014动漫展欢迎你的到来', '2', '漫画教室', '2015-04-01', '12', '1', null);
INSERT INTO `club_activity` VALUES ('6', '参加市舞蹈演出', '参加舞蹈演出', '15', '市中心文化馆', '2015-04-01', '15', '1', 'userfiles/wanggang/4431d76a-9f26-49af-914c-34c30b4bdba7.jpg');
INSERT INTO `club_activity` VALUES ('7', 'ffff', 'ff', '1', 'ff', '2015-04-01', '3', '1', 'userfiles/zhangsan/cd96261b-942b-4647-9964-1db80d06327a.jpg');

-- ----------------------------
-- Table structure for `club_message`
-- ----------------------------
DROP TABLE IF EXISTS `club_message`;
CREATE TABLE `club_message` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_content` varchar(2000) DEFAULT NULL,
  `msg_user_id` int(11) DEFAULT NULL,
  `msg_time` date DEFAULT NULL,
  `msg_news_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`msg_id`),
  KEY `fk_msg_user` (`msg_user_id`),
  KEY `fk_msg_news` (`msg_news_id`),
  CONSTRAINT `fk_msg_news` FOREIGN KEY (`msg_news_id`) REFERENCES `club_news` (`news_id`),
  CONSTRAINT `fk_msg_user` FOREIGN KEY (`msg_user_id`) REFERENCES `club_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of club_message
-- ----------------------------
INSERT INTO `club_message` VALUES ('3', '赞', '14', '2015-04-07', '1');
INSERT INTO `club_message` VALUES ('4', 'asdadadsad', '2', '2015-04-07', '2');
INSERT INTO `club_message` VALUES ('5', 'asdsadasdas', '2', '2015-04-07', '2');
INSERT INTO `club_message` VALUES ('6', 'dsadsadsadsa', '2', '2015-04-07', '3');
INSERT INTO `club_message` VALUES ('9', 'asdasdasdasd', '2', '2015-04-07', '4');
INSERT INTO `club_message` VALUES ('10', 'dsadasdasdas', '2', '2015-04-07', '4');
INSERT INTO `club_message` VALUES ('11', 'sadsadasdas', '2', '2015-04-07', '4');
INSERT INTO `club_message` VALUES ('12', 'a', '2', '2015-04-07', '4');
INSERT INTO `club_message` VALUES ('13', '', '2', '2015-04-07', '4');
INSERT INTO `club_message` VALUES ('14', 'b', '2', '2015-04-07', '4');
INSERT INTO `club_message` VALUES ('15', 'aa', '2', '2015-04-07', '1');
INSERT INTO `club_message` VALUES ('16', 'aa', '21', '2015-04-07', '1');

-- ----------------------------
-- Table structure for `club_news`
-- ----------------------------
DROP TABLE IF EXISTS `club_news`;
CREATE TABLE `club_news` (
  `news_id` int(11) NOT NULL AUTO_INCREMENT,
  `news_title` varchar(100) DEFAULT NULL,
  `news_content` varchar(2000) DEFAULT NULL,
  `news_time` date DEFAULT NULL,
  `news_user` varchar(30) DEFAULT NULL,
  `news_club` int(11) DEFAULT NULL,
  PRIMARY KEY (`news_id`),
  KEY `FK_club_news` (`news_club`),
  CONSTRAINT `FK_club_news` FOREIGN KEY (`news_club`) REFERENCES `club` (`club_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of club_news
-- ----------------------------
INSERT INTO `club_news` VALUES ('1', '我校学生积极参加公益活动', '<strong>我校学生积极参加公益活动</strong>', '2014-05-05', '李四', '1');
INSERT INTO `club_news` VALUES ('2', '我校双节棍圆满成功', '<p><em><strong>我校双节棍比赛圆满结束</strong></em></p>', '2014-05-05', '花花', '1');
INSERT INTO `club_news` VALUES ('3', '练习双节棍学生的风采', '练习双节棍学生的风采', '2014-05-05', '小名', '1');
INSERT INTO `club_news` VALUES ('4', '我校学生参加学校比赛', '我校学生参加我校比赛并取得优秀成绩', '2014-05-06', '小发', '2');
INSERT INTO `club_news` VALUES ('5', 'ss', 'ss', '2014-05-05', '张大', '15');
INSERT INTO `club_news` VALUES ('6', '学生们的舞蹈风采', '<strong>学生们的舞蹈风采</strong>', '2014-05-05', '海霞', '15');
INSERT INTO `club_news` VALUES ('9', 'ddd', 'dd', '2014-05-06', 'dd', '1');

-- ----------------------------
-- Table structure for `club_picture`
-- ----------------------------
DROP TABLE IF EXISTS `club_picture`;
CREATE TABLE `club_picture` (
  `pic_id` int(11) NOT NULL AUTO_INCREMENT,
  `pic_url` varchar(100) DEFAULT NULL,
  `pic_news_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`pic_id`),
  KEY `fk_news_pic` (`pic_news_id`),
  CONSTRAINT `fk_news_pic` FOREIGN KEY (`pic_news_id`) REFERENCES `club_news` (`news_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of club_picture
-- ----------------------------
INSERT INTO `club_picture` VALUES ('1', 'userfiles/zhangsan/5f3e764e-db46-4d9a-9636-b0a721d7972d.jpg', '1');
INSERT INTO `club_picture` VALUES ('2', 'userfiles/zhangsan/a7b54942-8984-4773-b9df-9ffa825e0ec1.jpg', '1');
INSERT INTO `club_picture` VALUES ('3', 'userfiles/zhangsan/e6b43061-c3e7-40d0-b47b-3abb9fa087cd.jpg', '2');
INSERT INTO `club_picture` VALUES ('4', 'userfiles/zhangsan/9ab6a14c-07c6-4225-a906-c92c87b473d2.jpg', null);
INSERT INTO `club_picture` VALUES ('5', 'userfiles/zhangsan/0b9b8af3-9d45-4470-8204-3c4d0ae57b31.jpg', '3');
INSERT INTO `club_picture` VALUES ('6', 'userfiles/zhangsan/ecd56678-f674-4e78-bd32-eb4570a42790.jpg', '9');

-- ----------------------------
-- Table structure for `club_type`
-- ----------------------------
DROP TABLE IF EXISTS `club_type`;
CREATE TABLE `club_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of club_type
-- ----------------------------
INSERT INTO `club_type` VALUES ('1', '系统管理员');
INSERT INTO `club_type` VALUES ('2', '社团管理员');
INSERT INTO `club_type` VALUES ('3', '普通用户');
INSERT INTO `club_type` VALUES ('4', '社团成员');

-- ----------------------------
-- Table structure for `club_user`
-- ----------------------------
DROP TABLE IF EXISTS `club_user`;
CREATE TABLE `club_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(30) DEFAULT NULL,
  `user_pwd` varchar(32) DEFAULT NULL,
  `user_sex` varchar(2) DEFAULT NULL,
  `user_realname` varchar(30) DEFAULT NULL,
  `user_age` int(11) DEFAULT NULL,
  `user_class` varchar(30) DEFAULT NULL,
  `user_phone` varchar(30) DEFAULT NULL,
  `user_address` varchar(100) DEFAULT NULL,
  `user_picture` varchar(100) DEFAULT NULL,
  `user_club_id` int(11) DEFAULT NULL,
  `user_type_id` int(11) DEFAULT NULL,
  `user_nick` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `fk_club` (`user_club_id`),
  KEY `fk_type` (`user_type_id`),
  CONSTRAINT `fk_club` FOREIGN KEY (`user_club_id`) REFERENCES `club` (`club_id`),
  CONSTRAINT `fk_type` FOREIGN KEY (`user_type_id`) REFERENCES `club_type` (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of club_user
-- ----------------------------
INSERT INTO `club_user` VALUES ('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1', 'admin', '22', null, '15068859212', '山西长治', null, null, '1', 'admin');
INSERT INTO `club_user` VALUES ('2', 'zhangsan', '96e79218965eb72c92a549dd5a330112', '1', '张三', '44', '计算机专业', '13758320912', '山西长治', 'userfiles/zhangsan/a70bf6a4-57e1-494d-adf1-740ea9a09ba6.jpg', '1', '2', '阿三');
INSERT INTO `club_user` VALUES ('3', 'shenjie', '670b14728ad9902aecba32e22fa4f6bd', '2', '沈洁', '22', '计算机专业', '13089789912', '山西长治', null, '1', '4', '阿三');
INSERT INTO `club_user` VALUES ('4', 'doudou', '96e79218965eb72c92a549dd5a330112', '2', '王豆豆', '23', '舞蹈专业', '13087909971', '山西长治', null, '2', '2', '豆豆');
INSERT INTO `club_user` VALUES ('9', 'xlt0623', null, '2', 'vv', '34', '计算机班', null, '山西长治', 'userfiles/xlt0623/eb8f309a-8ea1-4692-9001-c53720f158e9.jpg', null, '4', '向阳');
INSERT INTO `club_user` VALUES ('10', 'lisi', '96e79218965eb72c92a549dd5a330112', '1', '李四', '21', '计算机专业', '13489072311', '山西长治', null, '1', '4', '阿斯');
INSERT INTO `club_user` VALUES ('11', 'xiaiming', '96e79218965eb72c92a549dd5a330112', '1', '张明', '21', '计算机专业', '13456772133', '山西长治', null, '1', '4', '小名');
INSERT INTO `club_user` VALUES ('12', 'huahua', '96e79218965eb72c92a549dd5a330112', '2', '海燕', '22', '舞蹈专业', '15990786222', '山西长治', null, '2', '4', '花花');
INSERT INTO `club_user` VALUES ('13', 'beibei', '96e79218965eb72c92a549dd5a330112', '2', '刘贝贝', '21', '漫画专业', '15098099233', '山西长治', null, '2', '4', '贝贝');
INSERT INTO `club_user` VALUES ('14', 'wanggang', '96e79218965eb72c92a549dd5a330112', '1', '王刚', '23', '舞蹈专业班', '13789763222', '山西长治', null, '15', '2', '刚刚');
INSERT INTO `club_user` VALUES ('15', 'liusan', '96e79218965eb72c92a549dd5a330112', '1', '刘三', '22', '数学班', '13798088823', '山西长治', null, '15', '4', '阿六');
INSERT INTO `club_user` VALUES ('16', 'aaaaaaa', '96e79218965eb72c92a549dd5a330112', '1', 'aa', '23', 'asas', null, 's', null, null, '3', 'aaaa');
INSERT INTO `club_user` VALUES ('17', '', 'd41d8cd98f00b204e9800998ecf8427e', '1', '', null, '', '', '', null, null, '3', '');
INSERT INTO `club_user` VALUES ('19', 'dddddd', '980ac217c6b51e7dc41040bec1edfec8', '1', 'dd', '23', 'qw', '13758320912', 'dd', null, '17', '2', 'ddcc');
INSERT INTO `club_user` VALUES ('20', 'wwwwww', 'd785c99d298a4e9e6e13fe99e602ef42', '1', 'wwwww', '22', 'tt', '13758320912', 'tt', null, '18', '2', 'wwww');
INSERT INTO `club_user` VALUES ('21', 'yangxiaozhi', 'e10adc3949ba59abbe56e057f20f883e', '2', '杨小志', '20', '计算机班', '13098900982', 'ss', 'userfiles/yangxiaozhi/8844b6d6-f69d-4152-83a8-5b4cf5ad06dc.jpg', '1', '4', '小志');
INSERT INTO `club_user` VALUES ('22', 'aaaaaaa', '96e79218965eb72c92a549dd5a330112', '1', 'aa', '11', 'ss', '13098900982', 'dd', null, null, '3', 'aaaa');
INSERT INTO `club_user` VALUES ('23', 'zhangxiaoyang', 'a4580915d673daf4f4cf675a72d0b687', '2', '???', '23', '1', '13888888888', '????', null, null, '3', 'aaaa');
