

public class Group
 {
    String self=null;
    ServeOneClient selfSocket=null;
    String player = null;
    ServeOneClient playerSocket =null;
    int selfColor = 0;
    int playerColor = 0;
    boolean Setting = false;
    int board[][];

    public Group()
	{
        board = new int[15][15];
    }
}