import java.net.Socket;


public class Player 
{
    String self=null;
    ServeOneClient selfSocket=null;
    boolean setting = false;
    int color = 1;
    public Player(){}
/*    public Player(Player pp){
        self = new String(pp.self);
        selfSocket = pp.selfSocket;
        player = new String(pp.player);
        playerSocket = pp.playerSocket;
    }
*/
}