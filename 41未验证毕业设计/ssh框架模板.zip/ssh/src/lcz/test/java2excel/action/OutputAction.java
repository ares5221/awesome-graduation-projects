package lcz.test.java2excel.action;

import com.opensymphony.xwork2.ActionSupport;

import lcz.test.java2excel.service.ComputeStudentService;


public class OutputAction extends ActionSupport{
	private static final long serialVersionUID = 1L;
	private ComputeStudentService computeStudentService; 
	private int sum;
	public String actionMethod()
	{
		sum = computeStudentService.addStudentId();
		return "output";
	}
	public void setComputeStudentService(ComputeStudentService computeStudentService) {
		this.computeStudentService = computeStudentService;
	}
	public ComputeStudentService getComputeStudentService() {
		return computeStudentService;
	}
	public void setSum(int sum) {
		this.sum = sum;
	}
	public int getSum() {
		return sum;
	}
}
