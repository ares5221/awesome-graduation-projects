package lcz.test.java2excel.service;


public interface ComputeStudentService {
	public int addStudentId();
}
