package lcz.test.java2excel.service.impl;

import lcz.test.java2excel.bean.Student;
import lcz.test.java2excel.dao.StudentDao;
import lcz.test.java2excel.service.ComputeStudentService;

public class ComputeStudentServiceImpl implements ComputeStudentService {
	private StudentDao studentDao;
	@Override
	public int addStudentId() {
		int sum = 0;
		Student[] students = new Student[2];
		students[0] = getStudentDao().selectStudent(1);
		students[1] = getStudentDao().selectStudent(4);
		
		for (Student student : students) {
			sum += student.getStudentId();
		}

		return sum;
	}
	public void setStudentDao(StudentDao studentDao) {
		this.studentDao = studentDao;
	}
	public StudentDao getStudentDao() {
		return studentDao;
	}

}
