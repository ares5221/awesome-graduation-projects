package lcz.test.java2excel.dao.impl;

import lcz.test.java2excel.bean.Student;
import lcz.test.java2excel.dao.StudentDao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class StudentDaoImpl implements StudentDao {

	private SessionFactory sessionFactory;	
	private Session session;
	
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	public StudentDaoImpl() {
		super();
	}
	@Override
	public Student selectStudent(int studentId) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		Student student = (Student)session.get(Student.class, new Integer(studentId));
		System.out.println("student object: " + student);
		session.getTransaction().commit();
		return student;
	}
	
}
