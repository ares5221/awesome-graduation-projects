package lcz.test.java2excel.dao;

import lcz.test.java2excel.bean.Student;

public interface StudentDao {
	public Student selectStudent(int studentId);
}
