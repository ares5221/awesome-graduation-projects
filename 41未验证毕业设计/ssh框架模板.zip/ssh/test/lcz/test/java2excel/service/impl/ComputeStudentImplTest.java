package lcz.test.java2excel.service.impl;

import junit.framework.TestCase;
import lcz.test.java2excel.service.ComputeStudentService;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ComputeStudentImplTest extends TestCase{

	ComputeStudentService computeStudentService = null;
	ApplicationContext applicationContext = null;
	
	@Before
	public void setUp() throws Exception {
		applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		computeStudentService = (ComputeStudentServiceImpl) applicationContext.getBean("ComputeStudentServiceImpl");
	}

	
	@Test
	public void testAddStudentId(){
		int sum = computeStudentService.addStudentId();
		System.out.println("sum :"  + sum);
	}
	
	
	
	
}
