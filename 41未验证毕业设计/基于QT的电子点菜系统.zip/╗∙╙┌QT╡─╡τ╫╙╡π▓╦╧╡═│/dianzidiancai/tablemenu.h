#ifndef TABLEMENU_H
#define TABLEMENU_H

#include <QWidget>
#include"QSqlTableModel"

namespace Ui {
    class TableMenu;
}

class TableMenu : public QWidget
{
    Q_OBJECT

public:
    explicit TableMenu(QWidget *parent = 0);
    ~TableMenu();
    void initData();

protected:
    void changeEvent(QEvent *e);
    QSqlTableModel *model;

private slots:
    void on_Button_delete_4_clicked();
    void on_Button_select_4_clicked();
    void on_Button_Edit_4_clicked();
    void on_Button_return_4_clicked();
    void on_Button_add_4_clicked();

private:
    Ui::TableMenu *ui;
};

#endif // TABLEMENU_H
