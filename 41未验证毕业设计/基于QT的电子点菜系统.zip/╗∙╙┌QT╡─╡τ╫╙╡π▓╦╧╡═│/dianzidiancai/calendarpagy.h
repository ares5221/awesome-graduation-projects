#ifndef CALENDARPAGY_H
#define CALENDARPAGY_H

#include <QWidget>
#include"QSqlTableModel"

namespace Ui {
    class CalendarPagy;
}

class CalendarPagy : public QWidget
{
    Q_OBJECT

public:
    explicit CalendarPagy(QWidget *parent = 0);
    ~CalendarPagy();
    void initData();

private:
    Ui::CalendarPagy *ui;
    QSqlTableModel *model;

private slots:
    void on_Button_return_5_clicked();
};

#endif // CALENDARPAGY_H
