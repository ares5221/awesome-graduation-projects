#ifndef TABLEINFO_H
#define TABLEINFO_H

#include <QWidget>
#include"QSqlTableModel"

namespace Ui {
    class TableInfo;
}

class TableInfo : public QWidget
{
    Q_OBJECT

public:
    explicit TableInfo(QWidget *parent = 0);
    ~TableInfo();
    void initData();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::TableInfo *ui;
    QSqlTableModel *model;

private slots:
    void on_Button_delete_3_clicked();
    void on_Button_select_3_clicked();
    void on_Button_Edit_3_clicked();
    void on_Button_return_3_clicked();
    void on_Button_add_3_clicked();
};

#endif // TABLEINFO_H
