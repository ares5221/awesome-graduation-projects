#ifndef MAININTERFACE_H
#define MAININTERFACE_H

#include"QGraphicsView"
#include"QGraphicsScene"
#include"QGraphicsItem"
#include"iconitem.h"
#include"help.h"
#include"menuinfo.h"
#include"tableinfo.h"
#include"tablemenu.h"
#include"calendarpagy.h"

class mainInterface:public QGraphicsView
{
    Q_OBJECT
public:
    mainInterface(QWidget *parent = 0);
    void addItems();//����iconitem
    void HelpManage();
    void MenuInfoManage();
    void TableInfoManage();
    void TableMenuManage();
    void ShowCalendarpagy();
protected:
    void mouseDoubleClickEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
private:
    QGraphicsScene *scene;
    QStringList icon_name;
    iconitem *image;
    help *helptest;
    MenuInfo *menuinfo;
    TableInfo *tableinfo;
    TableMenu *tablemenu;
    CalendarPagy *calendar;
};

#endif // MAININTERFACE_H
