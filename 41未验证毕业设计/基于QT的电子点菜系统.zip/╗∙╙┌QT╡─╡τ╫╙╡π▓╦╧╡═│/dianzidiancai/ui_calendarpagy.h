/********************************************************************************
** Form generated from reading UI file 'calendarpagy.ui'
**
** Created: Thu May 10 17:28:33 2012
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CALENDARPAGY_H
#define UI_CALENDARPAGY_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCalendarWidget>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CalendarPagy
{
public:
    QLabel *label;
    QCalendarWidget *calendarWidget;
    QPushButton *Button_return_5;
    QLabel *labelname;

    void setupUi(QWidget *CalendarPagy)
    {
        if (CalendarPagy->objectName().isEmpty())
            CalendarPagy->setObjectName(QString::fromUtf8("CalendarPagy"));
        CalendarPagy->resize(640, 480);
        label = new QLabel(CalendarPagy);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 641, 480));
        QFont font;
        font.setPointSize(16);
        label->setFont(font);
        label->setPixmap(QPixmap(QString::fromUtf8("images/login.jpg")));
        calendarWidget = new QCalendarWidget(CalendarPagy);
        calendarWidget->setObjectName(QString::fromUtf8("calendarWidget"));
        calendarWidget->setGeometry(QRect(100, 80, 461, 331));
        Button_return_5 = new QPushButton(CalendarPagy);
        Button_return_5->setObjectName(QString::fromUtf8("Button_return_5"));
        Button_return_5->setGeometry(QRect(490, 420, 75, 30));
        labelname = new QLabel(CalendarPagy);
        labelname->setObjectName(QString::fromUtf8("labelname"));
        labelname->setGeometry(QRect(290, 30, 50, 21));
        QFont font1;
        font1.setPointSize(20);
        labelname->setFont(font1);
        labelname->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        retranslateUi(CalendarPagy);

        QMetaObject::connectSlotsByName(CalendarPagy);
    } // setupUi

    void retranslateUi(QWidget *CalendarPagy)
    {
        CalendarPagy->setWindowTitle(QApplication::translate("CalendarPagy", "Form", 0, QApplication::UnicodeUTF8));
        label->setText(QString());
        Button_return_5->setText(QApplication::translate("CalendarPagy", "\350\277\224\345\233\236", 0, QApplication::UnicodeUTF8));
        labelname->setText(QApplication::translate("CalendarPagy", "\346\227\245\345\216\206", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CalendarPagy: public Ui_CalendarPagy {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CALENDARPAGY_H
