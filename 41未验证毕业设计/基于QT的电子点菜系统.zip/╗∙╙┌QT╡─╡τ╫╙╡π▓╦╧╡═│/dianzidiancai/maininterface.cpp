#include "maininterface.h"
#include"QGraphicsPixmapItem"
#include"QMouseEvent"
#include"iconitem.h"
#include"QGraphicsDropShadowEffect"

mainInterface::mainInterface(QWidget *parent )
    :QGraphicsView(parent)
{
    //实例化GraphicsScene
    this->scene=new QGraphicsScene(this);
    scene->setSceneRect(0,0,636,476);
    setGeometry(0,0,640,480);
    setMinimumSize(640, 480);
    setMaximumSize(640, 480);
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    setScene(scene);
    //在场景中加入item
    this->addItems();
    //在mainInterface-GraphicsView中加入scene。
    this->setScene(this->scene);
}
void mainInterface::addItems()
{
    //增加背景图片
    QGraphicsPixmapItem *backimage=this->scene->addPixmap(QPixmap(":/images/login.jpg"));
    backimage->setPos(0,0);
    //初始化图片文本
    QString str="Help#Welcome#Calendar#Menu Info#Table Info#Table Menu";
    this->icon_name=str.split("#");
    //增加向导图标iconitem
    int imageCount=icon_name.count();
    int imageOffset =160;
    int leftMargin = 35;
    int topMargin =50;

    QFont font("Arial", 15, QFont::Bold);

    for (int i = 0; i < imageCount; ++i) {
        QGraphicsTextItem *label = new QGraphicsTextItem;

        int columnOffset = -((i / 3) * 20);
        int x = ((i % 3) * imageOffset) + leftMargin;
        int y = ((i / 3) * imageOffset) + topMargin + columnOffset;

        image = new iconitem(i,QPixmap(tr(":/images/%1.png").arg(i+1)));
        image ->setPos(x, y);
        scene->addItem(image);
        //设置影子
        QGraphicsDropShadowEffect *DropShadow = new QGraphicsDropShadowEffect(this);
        DropShadow->setOffset(10,10);
        image->setGraphicsEffect(DropShadow);
        //设置透明度
        QGraphicsOpacityEffect *opacity = new QGraphicsOpacityEffect(this);
        opacity->setOpacity(0.8);
        image ->setGraphicsEffect(opacity);

        label = scene->addText(icon_name[i],font);
        QPointF labelOffset(((70 - label->boundingRect().width()) / 2), 85);//(51.2 - label->boundingRect().width()) / 2)
        label ->setPos(QPointF(x, y) + labelOffset);
        label ->setDefaultTextColor(QColor(255,255,255));
    }
}
//点菜系统的Help文档
void mainInterface::HelpManage()
{
    this->helptest=new help(this);
    helptest->show();
}
//菜单信息管理
void mainInterface::MenuInfoManage()
{
    this->menuinfo=new MenuInfo(this);
    menuinfo->show();
}
//桌台管理
void mainInterface::TableInfoManage()
{
    this->tableinfo=new TableInfo(this);
    tableinfo->show();
}
//桌台点菜管理
void mainInterface::TableMenuManage()
{
    this->tablemenu=new TableMenu(this);
    tablemenu->show();
}
//日历
void mainInterface::ShowCalendarpagy()
{
    this->calendar=new CalendarPagy(this);
    calendar->show();
}

//鼠标点击相应的iconitem，进入相应的操作界面
void mainInterface::mouseReleaseEvent(QMouseEvent *event)
{
    if (QGraphicsItem *item = itemAt(event->pos())) {
        if (iconitem *image = qgraphicsitem_cast<iconitem *>(item))
            switch (image->id())
            {
                case 0:this->HelpManage();break;
                case 1:break;
                case 2:this->ShowCalendarpagy();break;
                case 3:this->MenuInfoManage();break;
                case 4:this->TableInfoManage();break;
                case 5:this->TableMenuManage();break;
            }
    }
    QGraphicsView::mouseReleaseEvent(event);
}
//双击鼠标左键，结束应用程序
void mainInterface::mouseDoubleClickEvent(QMouseEvent *event)
{
    if(event->button()==Qt::LeftButton)
    {
        this->close();
    }
}
