#ifndef HELP_H
#define HELP_H

#include <QWidget>

namespace Ui {
    class help;
}

class help : public QWidget {
    Q_OBJECT
public:
    help(QWidget *parent = 0);
    ~help();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::help *ui;

private slots:
    void on_pushButton_clicked();
};

#endif // HELP_H
