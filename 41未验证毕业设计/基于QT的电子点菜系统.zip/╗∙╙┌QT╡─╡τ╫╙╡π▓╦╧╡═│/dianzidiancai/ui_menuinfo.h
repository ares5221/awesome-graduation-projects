/********************************************************************************
** Form generated from reading UI file 'menuinfo.ui'
**
** Created: Thu May 10 17:28:33 2012
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MENUINFO_H
#define UI_MENUINFO_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QTableView>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MenuInfo
{
public:
    QLabel *label;
    QTableView *tableView;
    QLabel *labelname;
    QPushButton *Button_delete_2;
    QPushButton *Button_return_2;
    QPushButton *Button_add_2;
    QPushButton *Button_Edit_2;
    QLabel *label2_2;
    QPushButton *Button_select_2;
    QLineEdit *Edit_search_2;

    void setupUi(QWidget *MenuInfo)
    {
        if (MenuInfo->objectName().isEmpty())
            MenuInfo->setObjectName(QString::fromUtf8("MenuInfo"));
        MenuInfo->resize(640, 480);
        label = new QLabel(MenuInfo);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 641, 480));
        label->setPixmap(QPixmap(QString::fromUtf8(":/images/login.jpg")));
        tableView = new QTableView(MenuInfo);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(20, 40, 420, 361));
        labelname = new QLabel(MenuInfo);
        labelname->setObjectName(QString::fromUtf8("labelname"));
        labelname->setGeometry(QRect(150, 10, 150, 21));
        QFont font;
        font.setPointSize(16);
        labelname->setFont(font);
        labelname->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        Button_delete_2 = new QPushButton(MenuInfo);
        Button_delete_2->setObjectName(QString::fromUtf8("Button_delete_2"));
        Button_delete_2->setGeometry(QRect(510, 210, 75, 50));
        Button_return_2 = new QPushButton(MenuInfo);
        Button_return_2->setObjectName(QString::fromUtf8("Button_return_2"));
        Button_return_2->setGeometry(QRect(510, 350, 75, 50));
        Button_add_2 = new QPushButton(MenuInfo);
        Button_add_2->setObjectName(QString::fromUtf8("Button_add_2"));
        Button_add_2->setGeometry(QRect(510, 70, 75, 50));
        Button_Edit_2 = new QPushButton(MenuInfo);
        Button_Edit_2->setObjectName(QString::fromUtf8("Button_Edit_2"));
        Button_Edit_2->setGeometry(QRect(510, 140, 75, 50));
        label2_2 = new QLabel(MenuInfo);
        label2_2->setObjectName(QString::fromUtf8("label2_2"));
        label2_2->setGeometry(QRect(30, 420, 75, 30));
        label2_2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        Button_select_2 = new QPushButton(MenuInfo);
        Button_select_2->setObjectName(QString::fromUtf8("Button_select_2"));
        Button_select_2->setGeometry(QRect(370, 420, 75, 30));
        Edit_search_2 = new QLineEdit(MenuInfo);
        Edit_search_2->setObjectName(QString::fromUtf8("Edit_search_2"));
        Edit_search_2->setGeometry(QRect(110, 420, 220, 30));
        Edit_search_2->setStyleSheet(QString::fromUtf8("font: italic 11pt \"\345\256\213\344\275\223\";"));

        retranslateUi(MenuInfo);

        QMetaObject::connectSlotsByName(MenuInfo);
    } // setupUi

    void retranslateUi(QWidget *MenuInfo)
    {
        MenuInfo->setWindowTitle(QApplication::translate("MenuInfo", "Form", 0, QApplication::UnicodeUTF8));
        label->setText(QString());
        labelname->setText(QApplication::translate("MenuInfo", "\350\217\234\345\223\201\344\277\241\346\201\257\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        Button_delete_2->setText(QApplication::translate("MenuInfo", "\345\210\240\351\231\244", 0, QApplication::UnicodeUTF8));
        Button_return_2->setText(QApplication::translate("MenuInfo", "\350\277\224\345\233\236", 0, QApplication::UnicodeUTF8));
        Button_add_2->setText(QApplication::translate("MenuInfo", "\345\242\236\345\212\240", 0, QApplication::UnicodeUTF8));
        Button_Edit_2->setText(QApplication::translate("MenuInfo", "\344\277\256\346\224\271", 0, QApplication::UnicodeUTF8));
        label2_2->setText(QApplication::translate("MenuInfo", "\350\217\234\345\223\201\345\220\215\347\247\260\357\274\232", 0, QApplication::UnicodeUTF8));
        Button_select_2->setText(QApplication::translate("MenuInfo", "\346\237\245\346\211\276", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MenuInfo: public Ui_MenuInfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MENUINFO_H
