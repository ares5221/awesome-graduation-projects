/********************************************************************************
** Form generated from reading UI file 'tablemenu.ui'
**
** Created: Thu May 10 17:28:33 2012
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TABLEMENU_H
#define UI_TABLEMENU_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QTableView>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TableMenu
{
public:
    QLabel *label;
    QLabel *labelname;
    QTableView *tableView;
    QPushButton *Button_add_4;
    QPushButton *Button_Edit_4;
    QPushButton *Button_delete_4;
    QPushButton *Button_return_4;
    QLabel *label2_4;
    QLineEdit *Edit_search_4;
    QPushButton *Button_select_4;

    void setupUi(QWidget *TableMenu)
    {
        if (TableMenu->objectName().isEmpty())
            TableMenu->setObjectName(QString::fromUtf8("TableMenu"));
        TableMenu->resize(640, 480);
        label = new QLabel(TableMenu);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 641, 480));
        label->setPixmap(QPixmap(QString::fromUtf8(":/images/login.jpg")));
        labelname = new QLabel(TableMenu);
        labelname->setObjectName(QString::fromUtf8("labelname"));
        labelname->setGeometry(QRect(150, 10, 219, 21));
        QFont font;
        font.setPointSize(16);
        labelname->setFont(font);
        labelname->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        tableView = new QTableView(TableMenu);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(20, 40, 430, 361));
        Button_add_4 = new QPushButton(TableMenu);
        Button_add_4->setObjectName(QString::fromUtf8("Button_add_4"));
        Button_add_4->setGeometry(QRect(510, 70, 75, 50));
        Button_Edit_4 = new QPushButton(TableMenu);
        Button_Edit_4->setObjectName(QString::fromUtf8("Button_Edit_4"));
        Button_Edit_4->setGeometry(QRect(510, 140, 75, 50));
        Button_delete_4 = new QPushButton(TableMenu);
        Button_delete_4->setObjectName(QString::fromUtf8("Button_delete_4"));
        Button_delete_4->setGeometry(QRect(510, 210, 75, 50));
        Button_return_4 = new QPushButton(TableMenu);
        Button_return_4->setObjectName(QString::fromUtf8("Button_return_4"));
        Button_return_4->setGeometry(QRect(510, 350, 75, 50));
        label2_4 = new QLabel(TableMenu);
        label2_4->setObjectName(QString::fromUtf8("label2_4"));
        label2_4->setGeometry(QRect(30, 420, 75, 30));
        label2_4->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        Edit_search_4 = new QLineEdit(TableMenu);
        Edit_search_4->setObjectName(QString::fromUtf8("Edit_search_4"));
        Edit_search_4->setGeometry(QRect(110, 420, 220, 30));
        Edit_search_4->setStyleSheet(QString::fromUtf8("font: italic 11pt \"\345\256\213\344\275\223\";"));
        Button_select_4 = new QPushButton(TableMenu);
        Button_select_4->setObjectName(QString::fromUtf8("Button_select_4"));
        Button_select_4->setGeometry(QRect(370, 420, 75, 30));

        retranslateUi(TableMenu);

        QMetaObject::connectSlotsByName(TableMenu);
    } // setupUi

    void retranslateUi(QWidget *TableMenu)
    {
        TableMenu->setWindowTitle(QApplication::translate("TableMenu", "Form", 0, QApplication::UnicodeUTF8));
        label->setText(QString());
        labelname->setText(QApplication::translate("TableMenu", "\351\244\220\346\241\214\350\217\234\345\223\201\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        Button_add_4->setText(QApplication::translate("TableMenu", "\345\242\236\345\212\240", 0, QApplication::UnicodeUTF8));
        Button_Edit_4->setText(QApplication::translate("TableMenu", "\344\277\256\346\224\271", 0, QApplication::UnicodeUTF8));
        Button_delete_4->setText(QApplication::translate("TableMenu", "\345\210\240\351\231\244", 0, QApplication::UnicodeUTF8));
        Button_return_4->setText(QApplication::translate("TableMenu", "\350\277\224\345\233\236", 0, QApplication::UnicodeUTF8));
        label2_4->setText(QApplication::translate("TableMenu", "\351\244\220\346\241\214\347\274\226\345\217\267\357\274\232", 0, QApplication::UnicodeUTF8));
        Button_select_4->setText(QApplication::translate("TableMenu", "\346\237\245\346\211\276", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class TableMenu: public Ui_TableMenu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TABLEMENU_H
