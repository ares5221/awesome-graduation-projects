#include "login.h"
#include "ui_login.h"
#include"QSqlQuery"
#include"QMessageBox"
#include"QDebug"
#include"QFile"
login::login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
    this->dbtest=new database();
    this->dbtest->opendatabase("/home/briup/dianzidiancai/menusys.db");
    this->dbtest->createtable();
}

login::~login()
{
    this->dbtest->closedatabase();
    delete ui;
}

void login::changeEvent(QEvent *e)
{
    QWidget::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}


//点击登录按钮，进行验证
void login::on_pushButton_login_clicked()
{
    QSqlQuery query;
    if(this->ui->lineEdit_user->text() == "")
                    QMessageBox::warning(this,"notice","no user");
    else if(this->ui->lineEdit_passwd->text()== "")
                    QMessageBox::warning(this,"notice","no password");
    else
    {
            QString user=this->ui->lineEdit_user->text();
            QString passwd=this->ui->lineEdit_passwd->text();


            query.exec("select passwd from user where name='"+user+"'");
            query.next();
            QString temp = query.value(0).toString();
            qDebug()<<passwd;

            if(passwd == temp)
            {
                    this->mainFace=new mainInterface();
                    this->mainFace->show();
                    this->close();
            }
            else{
                    QMessageBox::information(this,"notice","user or passwd is error!");
                    this->close();
            }
    }
}
//点击取消按钮
void login::on_pushButton_cancle_clicked()
{
    this->close();
}
