#ifndef MENUINFO_H
#define MENUINFO_H

#include <QWidget>
#include"QSqlTableModel"

namespace Ui {
    class MenuInfo;
}

class MenuInfo : public QWidget
{
    Q_OBJECT

public:
    MenuInfo(QWidget *parent = 0);
    ~MenuInfo();
    void initData();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::MenuInfo *ui;
    QSqlTableModel *model;

private slots:
    void on_Button_delete_2_clicked();
    void on_Button_select_2_clicked();
    void on_Button_Edit_2_clicked();
    void on_Button_return_2_clicked();
    void on_Button_add_2_clicked();
};

#endif // MENUINFO_H
