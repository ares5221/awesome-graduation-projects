#include "calendarpagy.h"
#include "ui_calendarpagy.h"
#include"QFile"
#include"QTextStream"
#include"QMessageBox"
#include"QSqlError"
#include <QTextCodec>

CalendarPagy::CalendarPagy(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CalendarPagy)
{
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
    ui->setupUi(this);
    this->initData();

    QFile file(":/qss/style_set.qss");
    file.open(QFile::ReadOnly);
    QTextStream filetext(&file);
    QString stylesheet = filetext.readAll();
    this->ui->Button_return_5->setStyleSheet(stylesheet);
}

void CalendarPagy::initData()
{

    this->model=new QSqlTableModel();
    this->model->setTable("menu");
    this->model->setEditStrategy(QSqlTableModel::OnManualSubmit);
        //升序排列
    this->model->setSort(0,Qt::AscendingOrder);
}

CalendarPagy::~CalendarPagy()
{
    delete ui;
}

void CalendarPagy::on_Button_return_5_clicked()
{
    this->close();
}
