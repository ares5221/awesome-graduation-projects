#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include"maininterface.h"
#include"database.h"

namespace Ui {
    class login;
}

class login : public QWidget {
    Q_OBJECT
public:
    login(QWidget *parent = 0);
    ~login();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::login *ui;
    mainInterface *mainFace;
    database *dbtest;

private slots:
    void on_pushButton_cancle_clicked();
    void on_pushButton_login_clicked();
};

#endif // LOGIN_H
