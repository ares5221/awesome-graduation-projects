#include <QtGui/QApplication>
#include"maininterface.h"
#include"login.h"
#include"QTextCodec"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //QTextCodec::setCodecForTr(QTextCodec::codecForLocale());
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
    login *login_test=new login();
    login_test->show();
    return a.exec();
}
