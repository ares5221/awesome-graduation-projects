#include "help.h"
#include "ui_help.h"
#include"QFile"
#include"QTextStream"
#include"QGraphicsOpacityEffect"

help::help(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::help)
{
    ui->setupUi(this);

    QFile file(":/qss/style_set.qss");
    file.open(QFile::ReadOnly);
    QTextStream filetext(&file);
    QString stylesheet = filetext.readAll();
    this->ui->pushButton->setStyleSheet(stylesheet);
    this->ui->label->setStyleSheet(stylesheet);

    QGraphicsOpacityEffect *opacity = new QGraphicsOpacityEffect(this);
    opacity->setOpacity(1);
    this->setGraphicsEffect(opacity);
}

help::~help()
{
    delete ui;
}

void help::changeEvent(QEvent *e)
{
    QWidget::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void help::on_pushButton_clicked()
{
    this->close();
}
