#include "database.h"
#include"QMessageBox"
#include"QSqlQuery"
database::database()
{
}
bool database::opendatabase(QString dbname)
{
    this->db=QSqlDatabase::addDatabase("QSQLITE");
    this->db.setDatabaseName(dbname);
    if(!db.open())
    {
        QMessageBox::critical(0,"Can't open database",
                              "Unable to establish a database connection.",
                              QMessageBox::Cancel);

        return false;
    }
     return true;
}
void database::closedatabase()
{
    this->db.close();
}
void database::createtable()
{
    QSqlQuery query;
    //创建menu表
    query.exec("create table menu(FoodId int primary key,"
               "FoodName varchar(20),"
               "Price int,"
               "Remark varchar(50))");
    //menu表中插入数据
    query.exec("insert into menu values(1,'fish',19,'')");
    query.exec("insert into menu values(2,'meal',20,'turkey')");

    //创建tableinfo表
    query.exec("create table tableinfo(TableId int primary key,"
                "TotlePrice int,"
                "CountPerson int,"
                "Remark varchar(50))");
    //tableinfo表中插入数据
    query.exec("insert into tableinfo values(1,38,8,'')");
    query.exec("insert into tableinfo values(2,39,10,'')");

    //创建tablemenu表
    query.exec("create table tablemenu(OlderId int primary key,"
                "TableId int,"
                "FoodName varchar(10),"
                "Count int,"
                "TotlePrice int,"
                "Remark varchar(50))");
    //tablemenu表中插入数据
    query.exec("insert into tablemenu values(1,1,'fish',2,38,'')");
    query.exec("insert into tablemenu values(2,2,'meal',1,20,'')");
    query.exec("insert into tablemenu values(3,1,'meal',1,19,'')");

    //创建user表
    query.exec("create table user(name varchar(20) primary key,"
               "passwd varchar(20))");
    //user表中插入数据
    query.exec("insert into user values('admin','123456')");
}
