/********************************************************************************
** Form generated from reading UI file 'help.ui'
**
** Created: Thu May 10 17:28:33 2012
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HELP_H
#define UI_HELP_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_help
{
public:
    QLabel *label;
    QLabel *label_2;
    QPushButton *pushButton;
    QTextEdit *textEdit;
    QTextEdit *textEdit_2;

    void setupUi(QWidget *help)
    {
        if (help->objectName().isEmpty())
            help->setObjectName(QString::fromUtf8("help"));
        help->resize(640, 480);
        help->setStyleSheet(QString::fromUtf8(""));
        label = new QLabel(help);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 640, 480));
        label->setPixmap(QPixmap(QString::fromUtf8("images/login.jpg")));
        label_2 = new QLabel(help);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(60, 80, 50, 20));
        label_2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        pushButton = new QPushButton(help);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(480, 390, 75, 30));
        textEdit = new QTextEdit(help);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(110, 110, 441, 261));
        textEdit->setReadOnly(true);
        textEdit_2 = new QTextEdit(help);
        textEdit_2->setObjectName(QString::fromUtf8("textEdit_2"));
        textEdit_2->setEnabled(false);
        textEdit_2->setGeometry(QRect(120, 120, 421, 241));

        retranslateUi(help);

        QMetaObject::connectSlotsByName(help);
    } // setupUi

    void retranslateUi(QWidget *help)
    {
        help->setWindowTitle(QApplication::translate("help", "Form", 0, QApplication::UnicodeUTF8));
        label->setText(QString());
        label_2->setText(QApplication::translate("help", "\350\257\264\346\230\216\357\274\232", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("help", "\350\277\224\345\233\236", 0, QApplication::UnicodeUTF8));
        textEdit_2->setHtml(QApplication::translate("help", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<table border=\"0\" style=\"-qt-table-type: root; margin-top:4px; margin-bottom:4px; margin-left:4px; margin-right:4px;\">\n"
"<tr>\n"
"<td style=\"border: none;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\346\254\242\350\277\216\344\275\277\347\224\250\346\234\254\351\244\220\345\216\205\347\224\265\345\255\220\347\202\271\350\217\234\347\263\273\347\273\237\357\274\232</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">	Menu Info</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -q"
                        "t-block-indent:0; text-indent:0px;\">		\351\241\265\351\235\242\347\224\250\344\272\216\347\256\241\347\220\206\351\244\220\345\216\205\350\217\234\345\223\201\344\277\241\346\201\257</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">	Table Info</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">		\351\241\265\351\235\242\347\224\250\344\272\216\346\237\245\347\234\213\351\244\220\345\216\205\351\244\220\346\241\214\344\277\241\346\201\257</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">	Tabel Menu</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">		\351\241\265\351\235\242\347\224\250\344\272\216\346\237\245\347\234\213\351\244\220\346\241\214\344\273\245\347\202\271\350\217\234\345\223\201\344\277"
                        "\241\346\201\257</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">            \346\267\273\345\212\240\346\214\211\351\222\256   \345\217\257\344\273\245\346\267\273\345\212\240\347\251\272\350\241\214</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">            \345\210\240\351\231\244\346\214\211\351\222\256   \345\217\257\344\273\245\345\210\240\351\231\244\351\200\211\345\256\232\350\241\214</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">            \344\277\256\346\224\271\346\214\211\351\222\256   \345\217\257\344\273\245\344\277\256\346\224\271\351\200\211\345\256\232\350\241\214\346\210\226\345\215\225\345\205\203"
                        "\346\240\274\344\277\241\346\201\257</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">            \350\277\224\345\233\236\346\214\211\351\222\256   \345\217\257\344\273\245\350\277\224\345\233\236\344\270\212\344\270\200\347\272\247\350\217\234\345\215\225</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">            \346\237\245\346\211\276\346\214\211\351\222\256   \345\217\257\344\273\245\346\237\245\346\211\276\345\257\271\345\272\224\344\277\241\346\201\257</p></td></tr></table></body></html>", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class help: public Ui_help {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HELP_H
