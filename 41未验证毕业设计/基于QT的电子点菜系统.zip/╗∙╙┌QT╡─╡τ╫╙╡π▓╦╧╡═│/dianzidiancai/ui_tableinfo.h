/********************************************************************************
** Form generated from reading UI file 'tableinfo.ui'
**
** Created: Thu May 10 17:28:33 2012
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TABLEINFO_H
#define UI_TABLEINFO_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QTableView>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TableInfo
{
public:
    QLabel *label;
    QPushButton *Button_Edit_3;
    QPushButton *Button_return_3;
    QPushButton *Button_select_3;
    QLineEdit *Edit_search_3;
    QLabel *label_3;
    QTableView *tableView;
    QLabel *labelname;
    QPushButton *Button_add_3;
    QPushButton *Button_delete_3;

    void setupUi(QWidget *TableInfo)
    {
        if (TableInfo->objectName().isEmpty())
            TableInfo->setObjectName(QString::fromUtf8("TableInfo"));
        TableInfo->resize(640, 480);
        label = new QLabel(TableInfo);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 641, 480));
        label->setPixmap(QPixmap(QString::fromUtf8(":/images/login.jpg")));
        Button_Edit_3 = new QPushButton(TableInfo);
        Button_Edit_3->setObjectName(QString::fromUtf8("Button_Edit_3"));
        Button_Edit_3->setGeometry(QRect(510, 140, 75, 50));
        Button_return_3 = new QPushButton(TableInfo);
        Button_return_3->setObjectName(QString::fromUtf8("Button_return_3"));
        Button_return_3->setGeometry(QRect(510, 350, 75, 50));
        Button_select_3 = new QPushButton(TableInfo);
        Button_select_3->setObjectName(QString::fromUtf8("Button_select_3"));
        Button_select_3->setGeometry(QRect(370, 420, 75, 30));
        Edit_search_3 = new QLineEdit(TableInfo);
        Edit_search_3->setObjectName(QString::fromUtf8("Edit_search_3"));
        Edit_search_3->setGeometry(QRect(110, 420, 211, 30));
        label_3 = new QLabel(TableInfo);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(30, 420, 70, 30));
        label_3->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        tableView = new QTableView(TableInfo);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(20, 40, 430, 361));
        labelname = new QLabel(TableInfo);
        labelname->setObjectName(QString::fromUtf8("labelname"));
        labelname->setGeometry(QRect(150, 10, 150, 21));
        QFont font;
        font.setPointSize(16);
        labelname->setFont(font);
        labelname->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        Button_add_3 = new QPushButton(TableInfo);
        Button_add_3->setObjectName(QString::fromUtf8("Button_add_3"));
        Button_add_3->setGeometry(QRect(510, 70, 75, 50));
        Button_delete_3 = new QPushButton(TableInfo);
        Button_delete_3->setObjectName(QString::fromUtf8("Button_delete_3"));
        Button_delete_3->setGeometry(QRect(510, 210, 75, 50));

        retranslateUi(TableInfo);

        QMetaObject::connectSlotsByName(TableInfo);
    } // setupUi

    void retranslateUi(QWidget *TableInfo)
    {
        TableInfo->setWindowTitle(QApplication::translate("TableInfo", "Form", 0, QApplication::UnicodeUTF8));
        label->setText(QString());
        Button_Edit_3->setText(QApplication::translate("TableInfo", "\344\277\256\346\224\271", 0, QApplication::UnicodeUTF8));
        Button_return_3->setText(QApplication::translate("TableInfo", "\350\277\224\345\233\236", 0, QApplication::UnicodeUTF8));
        Button_select_3->setText(QApplication::translate("TableInfo", "\346\237\245\350\257\242", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("TableInfo", "\351\244\220\346\241\214\347\274\226\345\217\267\357\274\232", 0, QApplication::UnicodeUTF8));
        labelname->setText(QApplication::translate("TableInfo", "\351\244\220\346\241\214\344\277\241\346\201\257\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
        Button_add_3->setText(QApplication::translate("TableInfo", "\345\242\236\345\212\240", 0, QApplication::UnicodeUTF8));
        Button_delete_3->setText(QApplication::translate("TableInfo", "\345\210\240\351\231\244", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class TableInfo: public Ui_TableInfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TABLEINFO_H
