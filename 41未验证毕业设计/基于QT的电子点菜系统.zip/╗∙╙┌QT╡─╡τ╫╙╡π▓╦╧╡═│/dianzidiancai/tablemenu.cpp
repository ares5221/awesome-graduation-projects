#include "tablemenu.h"
#include "ui_tablemenu.h"
#include"QFile"
#include"QTextStream"
#include"QMessageBox"
#include"QSqlError"
#include <QTextCodec>

TableMenu::TableMenu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TableMenu)
{
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
    ui->setupUi(this);
    this->initData();

    QFile file(":/qss/style_set.qss");
    file.open(QFile::ReadOnly);
    QTextStream filetext(&file);
    QString stylesheet = filetext.readAll();
    this->ui->tableView->setStyleSheet(stylesheet);
    this->ui->Button_add_4->setStyleSheet(stylesheet);
    this->ui->Button_delete_4->setStyleSheet(stylesheet);
    this->ui->Button_Edit_4->setStyleSheet(stylesheet);
    this->ui->Button_return_4->setStyleSheet(stylesheet);
    this->ui->Button_select_4->setStyleSheet(stylesheet);
    this->ui->Edit_search_4->setStyleSheet(stylesheet);
}

void TableMenu::initData()
{

    this->model=new QSqlTableModel();
    this->model->setTable("tablemenu");
    this->model->setEditStrategy(QSqlTableModel::OnManualSubmit);
        //升序排列
    this->model->setSort(0,Qt::AscendingOrder);
    this->model->select();
    this->ui->tableView->setModel(model);
}

TableMenu::~TableMenu()
{
    delete ui;
}

void TableMenu::changeEvent(QEvent *e)
{
    QWidget::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void TableMenu::on_Button_add_4_clicked()
{
    int row=this->model->rowCount();
    this->model->insertRow(row);
}

void TableMenu::on_Button_return_4_clicked()
{
    this->close();
}

void TableMenu::on_Button_Edit_4_clicked()
{
    this->model->database().transaction();
    int ok = QMessageBox::question(this,tr("提示"),tr("确定修改吗？"),QMessageBox::Yes|QMessageBox::No);
    if(ok == QMessageBox::Yes)
    {
        if(this->model->submitAll())
        {
            this->model->database().commit();
        }
        else
        {
            this->model->database().rollback();
            QMessageBox::warning(this,tr("Error"),tr("DB Error:%1").arg(this->model->lastError().text()));
        }
    }
    else
        this->model->revertAll();
}

void TableMenu::on_Button_select_4_clicked()
{
    QString dishName = ui->Edit_search_4->text();
    this->model->setFilter(tr("TableId='%1'").arg(dishName));
    this->model->select();
    ui->tableView->setModel(this->model);
}

void TableMenu::on_Button_delete_4_clicked()
{
    int currentRow = ui->tableView->currentIndex().row();

    int ok = QMessageBox::warning(this,tr("提示"),tr("确认删除？"),QMessageBox::Yes|QMessageBox::No);
    if(ok == QMessageBox::Yes){
        this->model->removeRow(currentRow);
        this->model->submitAll();
    }
    else
        this->model->revertAll();
}
