#include <QApplication>
#include <QTextCodec>
#include <QWidget>

#include "chinese_chess.h"

int main(int argc, char *argv[])
{
	QApplication app(argc, argv);
	QTextCodec::setCodecForTr(QTextCodec::codecForName("gb18030"));
	
	FristPageClass *page = new FristPageClass();
	page -> show();            //��ʾ��һ������

	app.exec();
}
