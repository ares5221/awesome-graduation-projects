#include "login.h"

static char usrname[] = "duke"; /* username */
static char passwd[] = "duke";  /* passwd */

/* *
 * clear I/O buffer
 * */
static void clear()
{
    char c;
    while(((c = getchar()) != '\n')&&(c != EOF));
}

/* *
 * user lonin
 * */
void login()
{
    char i_usrname[10];
    char i_passwd[10];
    int i = 0;
    while(i < 3)
    {
        printf("login:");
        scanf("%s", i_usrname);
        clear();
        printf("passwd:");
        fflush(stdout);


    	struct termios new_setting,init_setting;
    		
    	tcgetattr(0,&init_setting);
    	new_setting=init_setting;
    		
    	/* get termios setting and save it */
    	new_setting.c_lflag &= ~ECHO;
    	tcsetattr(0,TCSANOW,&new_setting);
    	
        scanf("%s", i_passwd); 
        	
        /* set termios setting and sive it */
        new_setting.c_lflag |= ECHO; 
        tcsetattr(0,TCSANOW,&new_setting);
        printf("\n");		


        clear();
  
        if((0 == strcmp(usrname, i_usrname))&&(0 == strcmp(passwd, i_passwd)))
        {
            break;
        }else
        {
            printf("login name or passwd match failed\n");
            printf("input again...\n");
        }
        i++;
        if(3 == i)
        {
            printf("you input than three times, please try later...\n");
            exit(1);
        }
    }
}

