#include "main.h"

int main(int argc, char ** argv) {
    char command[MAX_COMMAND_LEN + 1];
    char * nextCommand = NULL;
    struct jobSet jobList = { NULL, NULL };
    struct job newJob;
    FILE * input = stdin;
    int i;
    int status;
    int inBg;
    
    /* login */
    login();

	/* show welcome info */
	showWelInfo();

    if (argc > 2) {
        fprintf(stderr, "unexpected arguments; usage: ladsh1 "
                        "<commands>\n");
        exit(1);
    } else if (argc == 2) {
        input = fopen(argv[1], "r");
        if (!input) {
            perror("fopen");
            exit(1);
        }
    }

    /* *
	 * don't pay any attention to this signal; it just confuses 
     * things and isn't really meant for shells anyway 
	 * */
    signal(SIGTTOU, SIG_IGN);
    
    while (1) {
        if (!jobList.fg) {
            /* no job is in the foreground */

            /* see if any background processes have exited */
            checkJobs(&jobList);

            if (!nextCommand) {
                if (getCommand(input, command)) break;
                nextCommand = command;
            }

            if (!parseCommand(&nextCommand, &newJob, &inBg) &&
                              newJob.numProgs) {
                runCommand(newJob, &jobList, inBg);
            }
        } else {
            /* a job is running in the foreground; wait for it */
            i = 0;
            while (!jobList.fg->progs[i].pid ||
                   jobList.fg->progs[i].isStopped) i++;

            waitpid(jobList.fg->progs[i].pid, &status, WUNTRACED);

            if (WIFEXITED(status) || WIFSIGNALED(status)) {
                /* the child exited */
                jobList.fg->runningProgs--;
                jobList.fg->progs[i].pid = 0;
            
                if (!jobList.fg->runningProgs) {
                    /* child exited */

                    removeJob(&jobList, jobList.fg);
                    jobList.fg = NULL;

                    /* move the shell to the foreground */
                    if (tcsetpgrp(0, getpid()))
                        perror("tcsetpgrp");
                }
            } else {
                /* the child was stopped */
                jobList.fg->stoppedProgs++;
                jobList.fg->progs[i].isStopped = 1;

                if (jobList.fg->stoppedProgs == jobList.fg->runningProgs) {
                    printf("\n" JOB_STATUS_FORMAT, jobList.fg->jobId, 
                                "Stopped", jobList.fg->text);
                    jobList.fg = NULL;
                }
            }

            if (!jobList.fg) {
                /* move the shell to the foreground */
                if (tcsetpgrp(0, getpid()))
                    perror("tcsetpgrp");
            }
        }
    }

    return 0;
}
