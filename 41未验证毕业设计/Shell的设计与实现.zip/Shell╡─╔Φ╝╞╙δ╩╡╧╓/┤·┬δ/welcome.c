#include "welcome.h"

void showWelInfo(){
	printf("\n\n      ");
	date();
	printf("\n\n\n");
	printf("==========================================\n");
	printf("=  	    Name: Mini Shell             =\n");
	printf("= 	Features: A Simple Shell         =\n");
	printf("=  	    Time: 2010-05-14             =\n");
	printf("=  	  Author: An Hailong             =\n");
	printf("==========================================\n");
	printf("\n\n\n");
}

/* *
 * command
 * show systime date
 * */
int date()
{
    time_t caltime;
    struct tm * p_tm;
    char timebuf[1024];

    if(-1 == (caltime = time(NULL)))
    {
        printf("time error: %s\n", strerror(errno));
        return -1;
    }

    if(NULL == (p_tm = localtime(&caltime)))
    {
        printf("localtime error: %s\n", strerror(errno));
        return -1;
    }

    if(0 == strftime(timebuf, 1024, "%Y-%b-%d  %a  %X %Z\n", p_tm))
    {
        printf("strftime error: %s\n", strerror(errno));
        return -1;
    }

    fputs(timebuf, stdout);

    return 0;
}

