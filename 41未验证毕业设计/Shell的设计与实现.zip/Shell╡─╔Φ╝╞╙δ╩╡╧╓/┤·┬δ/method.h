#ifndef _METHOD_H
#define _METHOD_H

#include "include.h"

void freeJob(struct job * cmd);

int getCommand(FILE * source, char * command);

void globLastArgument(struct childProgram * prog, int * argcPtr, int * argcAllocedPtr);

/* * 
 * Return cmd->numProgs as 0 if no command is present (e.g. an empty
 * line). If a valid command is found, commandPtr is set to point to
 * the beginning of the next command (if the original command had more 
 * then one job associated with it) or NULL if no more commands are 
 * present. 
 * */
int parseCommand(char ** commandPtr, struct job * job, int * isBg);

int setupRedirections(struct childProgram * prog);

int runCommand(struct job newJob, struct jobSet * jobList, int inBg);

void removeJob(struct jobSet * jobList, struct job * job);

/* *
 * Checks to see if any background processes have exited -- if they 
 * have, figure out why and see if a job has completed 
 * */
void checkJobs(struct jobSet * jobList);


#endif
