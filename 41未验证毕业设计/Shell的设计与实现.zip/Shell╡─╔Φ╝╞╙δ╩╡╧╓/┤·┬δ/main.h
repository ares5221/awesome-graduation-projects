#ifndef _MAIN_H
#define _MAIN_H

#include "login.h"
#include "method.h"
#include "welcome.h"

int main(int argc, char ** argv);

#endif
