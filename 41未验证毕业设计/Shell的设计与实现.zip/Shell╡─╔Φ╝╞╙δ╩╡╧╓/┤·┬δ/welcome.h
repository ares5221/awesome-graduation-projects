#ifndef _WELCOME_H
#define _WELCOME_H

#include "include.h"

int date();
void showWelInfo();

#endif
