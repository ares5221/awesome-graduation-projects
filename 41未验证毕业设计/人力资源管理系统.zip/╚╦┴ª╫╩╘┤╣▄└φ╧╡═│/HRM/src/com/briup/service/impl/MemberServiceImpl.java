package com.briup.service.impl;

import java.io.File;
import java.util.List;

import com.briup.common.exception.MemberException;
import com.briup.common.transaction.HibernateTransaction;
import com.briup.common.util.BeanFactory;
import com.briup.common.util.MD5;
import com.briup.dao.IMemberDao;
import com.briup.dao.bean.Department;
import com.briup.dao.bean.Employee;
import com.briup.dao.bean.Member;
import com.briup.dao.bean.Zw;
import com.briup.service.IMemberService;

public class MemberServiceImpl implements IMemberService{
	public void addEmployee(Employee employee) throws MemberException {
		// TODO Auto-generated method stub
		HibernateTransaction trans=new HibernateTransaction();
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		try{
			trans.beginTransaction();
			dao.addEmployee(employee);
			trans.commit();
		}catch(Exception e){
			trans.rollback();
			e.printStackTrace();
			throw new MemberException("添加雇员档案失败！");
		}
	}

	public Employee findEmployee(String bianhao) throws MemberException {
		// TODO Auto-generated method stub
		HibernateTransaction trans=new HibernateTransaction();
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		try{
			trans.beginTransaction();
			Employee employee=dao.findEmployee(bianhao);
			trans.commit();
			return employee;
		}catch(Exception e){
			trans.rollback();
			throw new MemberException("员工信息查找失败！");
		}
	}

	public Department findDept(Long id) throws MemberException {
		// TODO Auto-generated method stub
		HibernateTransaction trans=new HibernateTransaction();
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		try{
			trans.beginTransaction();
			Department dept=dao.findDept(id);
			trans.commit();
			return dept;
		}catch(Exception e){
			trans.rollback();
			throw new MemberException("部门信息查找失败！");
		}
	}

	@SuppressWarnings("unchecked")
	public List<Department> listDept() throws MemberException {
		// TODO Auto-generated method stub
		HibernateTransaction trans=new HibernateTransaction();
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		try{
			trans.beginTransaction();
			List list=dao.listDept();
			trans.commit();
			return list;
		}catch(Exception e){
			trans.rollback();
			throw new MemberException("查询所有部门信息失败！");
		}
	}

	public Zw findZw(String name) throws MemberException {
		// TODO Auto-generated method stub
		HibernateTransaction trans=new HibernateTransaction();
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		try{
			trans.beginTransaction();
			Zw zw=dao.findZw(name);
			trans.commit();
			return zw;
		}catch(Exception e){
			trans.rollback();
			throw new MemberException("职位信息查找失败！");
		}
	}

	public void addMember(Member member) throws MemberException {
		// TODO Auto-generated method stub
		HibernateTransaction trans=new HibernateTransaction();
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		try{
			trans.beginTransaction();
			dao.addMember(member);
			trans.commit();
		}catch(Exception e){
			trans.rollback();
			e.printStackTrace();
			throw new MemberException("添加系统用户失败！");
		}
	}
	//用户注册
	public void register(Member member) throws MemberException {
		// TODO Auto-generated method stub
		HibernateTransaction trans=new HibernateTransaction();
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		try{
			trans.beginTransaction();
			Member m=dao.findMember(member.getAccountno());
			if(m!=null)
				throw new MemberException("用户名已经存在！");
			dao.addMember(member);
			trans.commit();
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
			throw new MemberException(e.getMessage(),e);
		}
	}
	//用户登录
	public Member login(String accountno, String password, String type) throws MemberException {
		// TODO Auto-generated method stub
		
		HibernateTransaction trans=new HibernateTransaction();
		System.out.println("in the service");
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		System.out.println(dao);
		try{
			trans.beginTransaction();
			Member m=dao.findMember(accountno);
			System.out.println(m);
			System.out.println(accountno);
			if(m==null){
				throw new MemberException("该帐号不存在，请与管理员联系！");
			}else if(m.getStatus().equals("1")){
				throw new MemberException("该帐号已被注销！");
			}else if(!m.getPassword().equals(password)){
				System.out.println(password+"=======");
				System.out.println(m.getPassword()+"--------");
				String pwd = MD5.getMD5Str(password);
				System.out.println(pwd + "---*****-----");
				throw new MemberException("密码不正确！");
			}else if(!m.getType().equals(type)){
				System.out.println(type + "=============");
				throw new MemberException("用户类型选择错误！");
			}
			trans.commit();
			return m;
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
			throw new MemberException(e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	public List<Employee> listEmployee() throws MemberException {
		// TODO Auto-generated method stub
		HibernateTransaction trans=new HibernateTransaction();
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		try{
			trans.beginTransaction();
			List list=dao.listEmployee();
			trans.commit();
			return list;
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
			throw new MemberException("员工信息查找失败！");
		}
	}

	@SuppressWarnings("unchecked")
	public List<Employee> findEmployee(String accountno, String gender,Long deptid) throws MemberException {
		// TODO Auto-generated method stub
		HibernateTransaction trans=new HibernateTransaction();
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		try{
			trans.beginTransaction();
			List list=dao.findEmployee(accountno, gender,deptid);
			trans.commit();
			return list;
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
			throw new MemberException("员工信息查找失败！");
		}
	}

	public void delEmployee(List<Long> list) throws MemberException {
		// TODO Auto-generated method stub
		HibernateTransaction trans=new HibernateTransaction();
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		try{
			trans.beginTransaction();
			for(Long id:list){
				Employee e=dao.QueryEmployee(id);
				if(e==null)
					throw new MemberException("删除员工档案失败！");
				dao.delEmployee(e);
				String path="src"+e.getIcon();
				File file=new File(path);
				if(file.exists())
					file.delete();
				String path2="/opt/jakarta-tomcat-5.0.28/webapps/HRM/pictures/"+e.getBianhao();
				File file2=new File(path2);
				if(file2.exists())
					file2.delete();
				Member m=dao.findMember(e.getBianhao());
				dao.delMember(m);
			}
			trans.commit();
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
			throw new MemberException("注销员工档案失败！",e);
		}
	}

	//遍历所有用户
	@SuppressWarnings("unchecked")
	public List<Member> listMember() throws MemberException {
		// TODO Auto-generated method stub
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			List list=dao.listMember();
			trans.commit();
			return list;
		}catch(Exception e){
			e.printStackTrace();
			throw new MemberException("查询用户信息失败！");
		}
	}

	//删除用户
	public void DelMember(String name) throws MemberException {
		// TODO Auto-generated method stub
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		@SuppressWarnings("unused")
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			Member member=dao.findMember(name);
			dao.delMember(member);
			trans.commit();
		}catch(Exception e){
			trans.rollback();
			e.printStackTrace();
			throw new MemberException("删除用户失败！");
		}
	}

	//添加管理员
	public void addAdmin(String accountno) throws MemberException {
		// TODO Auto-generated method stub
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			Member member=dao.findMember(accountno);
			member.setType("0");
			dao.addMember(member);
			trans.commit();
		}catch(Exception e){
			trans.rollback();
			throw new MemberException("添加管理员失败！");
		}
	}

	public void ZxEmployee(List<Long> list) throws MemberException {
		// TODO Auto-generated method stub
		HibernateTransaction trans=new HibernateTransaction();
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		try{
			trans.beginTransaction();
			for(Long id:list){
				Employee e=dao.QueryEmployee(id);
				if(e==null)
					throw new MemberException("注销员工档案失败！");
				e.setStatus("1");
				dao.addEmployee(e);
				Member m=dao.findMember(e.getBianhao());
				dao.delMember(m);
			}
			trans.commit();
		}catch(Exception e){
			trans.rollback();
			throw new MemberException(e.getMessage());
		}
	}

	//取消管理员
	public void qxAddmin(String accountno) throws MemberException {
		// TODO Auto-generated method stub
		HibernateTransaction trans=new HibernateTransaction();
		IMemberDao dao=(IMemberDao)BeanFactory.getBean("memberDao");
		try{
			trans.beginTransaction();
			Member member=dao.findMember(accountno);
			member.setType("1");
			dao.addMember(member);
			trans.commit();
		}catch(Exception e){
			trans.rollback();
		}
	}
}
