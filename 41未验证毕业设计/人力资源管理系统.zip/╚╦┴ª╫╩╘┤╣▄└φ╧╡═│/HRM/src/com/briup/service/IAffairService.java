package com.briup.service;

import java.util.List;

import com.briup.common.exception.AffairException;
import com.briup.dao.bean.Jc;
import com.briup.dao.bean.Loadfile;
import com.briup.dao.bean.Recruit;
import com.briup.dao.bean.Salary;
import com.briup.dao.bean.Train;

public interface IAffairService {
	
	//招聘
	List listZP() throws AffairException;
	void addRecruit(Recruit recruit) throws AffairException;
	void deleteRecruit(Long id)throws AffairException;
	//应聘		
	List listYp() throws AffairException;
	//培训
	void addTrain(Train train)throws AffairException;
	void deleteTrain(List<Long> list)throws AffairException;
	List listTrain() throws AffairException;
	List queryTrain(String name,String teacher)throws AffairException;
	Train train(Long id)throws AffairException;
	//奖惩
	void addJc(Jc jc)throws AffairException;
	List listJc() throws AffairException;
	List queryJc(String name,String member)throws AffairException;
	void deleteJc(Long id)throws AffairException;
	void deleteJc(List<Long> list)throws AffairException;
	//薪资	
	void addSalary(Salary salary)throws AffairException;
	List listSalary()throws AffairException;
	List querySalary(String bianhao,String month)throws AffairException;
	void deleteSalary(List<Long> list)throws AffairException;
	//文件
	void saveFile(Loadfile file)throws AffairException;
	List listFile()throws AffairException;
	void delFiles(List<Long> id)throws AffairException;
	void delFile(Long id)throws AffairException;
}
