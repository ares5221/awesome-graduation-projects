package com.briup.service.impl;

import java.util.List;


import com.briup.common.exception.AffairException;
import com.briup.common.transaction.HibernateTransaction;
import com.briup.common.util.BeanFactory;
import com.briup.dao.IAffairDao;
import com.briup.dao.bean.Jc;
import com.briup.dao.bean.Loadfile;
import com.briup.dao.bean.Recruit;
import com.briup.dao.bean.Salary;
import com.briup.dao.bean.Train;
import com.briup.service.IAffairService;

public class AffairServiceImpl implements IAffairService {
	
	//遍历招聘信息
	public List listZP() throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			List list=dao.listZP();
			trans.commit();
			return list;
		}catch(Exception e){
			trans.rollback();
			throw new AffairException("查询招聘信息失败！");
		}
	}
	
	//发布招聘信息
	public void addRecruit(Recruit recruit) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			dao.addRecruit(recruit);
			trans.commit();
		}catch(Exception e){
			trans.rollback();
			throw new AffairException("发布失败！");
		}
	}
	
	//删除招聘信息
	public void deleteRecruit(Long id) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			dao.deleteRecruit(id);
			trans.commit();
		}catch(Exception e){
			trans.rollback();
			throw new AffairException("删除招聘信息失败！");
		}
	}
	
	public List listYp() throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			List list=dao.listYp();
			trans.commit();
			return list;
		}catch(Exception e){
			trans.rollback();
			throw new AffairException("应聘信息查询失败！");
		}
	}
	public void addTrain(Train train) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			dao.addTrain(train);
			trans.commit();
		}catch(Exception e){
			trans.rollback();
			throw new AffairException("添加培训信息失败！");
		}
	}
	public List listTrain() throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			List list=dao.listTrain();
			trans.commit();
			return list;
		}catch(Exception e){
			trans.rollback();
			throw new AffairException("查询培训信息失败！");
		}
	}
	public List queryTrain(String name, String teacher) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			List list=dao.queryTrain(name, teacher);
			trans.commit();
			return list;
		}catch(Exception e){
			trans.rollback();
			e.printStackTrace();
			throw new AffairException("查询培训信息失败！");
		}
	}
	public void addJc(Jc jc) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			dao.addJc(jc);
			trans.commit();
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
			throw new AffairException("奖惩信息添加失败！");
		}
	}
	public List listJc() throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			List list=dao.listJc();
			trans.commit();
			return list;
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
			throw new AffairException("查询奖惩信息失败！");
		}
	}
	public List queryJc(String name, String member) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			List list=dao.queryJc(name, member);
			trans.commit();
			return list;
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
			throw new AffairException("查询奖惩信息失败！");
		}
	}
	public void deleteJc(Long id) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			dao.deleteJc(id);
			trans.commit();
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
			throw new AffairException("删除奖惩信息失败！");
		}
	}
	public Train train(Long id) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			Train train=dao.train(id);
			trans.commit();
			return train;
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
			throw new AffairException("查看培训信息失败！");
		}
	}
	public void deleteTrain(List<Long> list) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			for(Long id:list){
				Train train=dao.train(id);
				if(train==null)
					throw new AffairException("删除培训记录失败！");
				dao.deleteTrain(train);
			}
			trans.commit();
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
			throw new AffairException("删除培训记录失败！",e);
		}
	}
	public void deleteJc(List<Long> list) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			for(Long id:list){
				dao.deleteJc(id);
			}
			trans.commit();
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
			throw new AffairException("删除奖惩记录失败！");
		}
	}
	public void addSalary(Salary salary) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			Salary s=dao.querySalary(salary.getEbianhao(),salary.getSmonth());
			if(s!=null)
				throw new AffairException("该员工该月薪资信息已存在，请不要重复输入！");
			dao.addSalary(salary);
			trans.commit();
		}catch(Exception e){
			trans.rollback();
			e.printStackTrace();
			throw new AffairException(e.getMessage());
		}
	}
	public List listSalary() throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			List list=dao.listSalary();
			trans.commit();
			return list;
		}catch(Exception e){
			trans.rollback();
			throw new AffairException("薪资查询失败！");
		}
	}
	public List querySalary(String bianhao, String month) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			List list=dao.findSalary(bianhao, month);
			trans.commit();
			return list;
		}catch(Exception e){
			trans.rollback();
			throw new AffairException("薪资查询失败！");
		}
	}
	public void deleteSalary(List<Long> list) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			for(Long id:list){
				Salary salary=dao.salary(id);
				if(salary==null)
					throw new AffairException("删除薪资记录失败！");
				dao.deleteSalary(salary);
			}
			trans.commit();
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
			throw new AffairException(e.getMessage());
		}
	}
	public void saveFile(Loadfile file) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			dao.saveFile(file);
			trans.commit();
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
			throw new AffairException("上传文件失败！");
		}
	}
	public List listFile() throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			List list=dao.listFile();
			trans.commit();
			return list;
		}catch(Exception e){
			trans.rollback();
			throw new AffairException("查询文件列表失败！");
		}
	}
	public void delFiles(List<Long> id) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			for(Long i:id){
				Loadfile f=dao.findFile(i);
				dao.delFile(f);
			}
			trans.commit();
		}catch(Exception e){
			trans.rollback();
			throw new AffairException("文件删除失败！");
		}
	}
	public void delFile(Long id) throws AffairException {
		// TODO Auto-generated method stub
		IAffairDao dao=(IAffairDao)BeanFactory.getBean("affairDao");
		HibernateTransaction trans=new HibernateTransaction();
		try{
			trans.beginTransaction();
			Loadfile file=dao.findFile(id);
			dao.delFile(file);
			trans.commit();
		}catch(Exception e){
			trans.rollback();
			throw new AffairException("文件删除失败！");
		}
	}
}
