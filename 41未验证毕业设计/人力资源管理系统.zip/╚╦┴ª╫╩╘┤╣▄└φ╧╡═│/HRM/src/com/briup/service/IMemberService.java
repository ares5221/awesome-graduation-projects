package com.briup.service;

import java.util.List;

import com.briup.common.exception.MemberException;
import com.briup.dao.bean.Department;
import com.briup.dao.bean.Employee;
import com.briup.dao.bean.Member;
import com.briup.dao.bean.Zw;

public interface IMemberService {
	
	//用户注册
	void register(Member member) throws MemberException;
	//用户登录
	Member login(String accountno,String password,String type)throws MemberException;
	//添加或修改用户
	void addMember(Member member) throws MemberException;
	//删除用户
	void DelMember(String name)throws MemberException;
	//遍历所有用户
	List<Member> listMember()throws MemberException;
	//添加管理员
	void addAdmin(String accountno)throws MemberException;
	//取消管理员
	void qxAddmin(String accountno) throws MemberException;
	//根据id查找部门
	Department findDept(Long id) throws MemberException;
	//遍历部门信息
	List<Department> listDept() throws MemberException;
	//删除档案
	void delEmployee(List<Long> list)throws MemberException;
	//增加员工信息
	void addEmployee(Employee employee) throws MemberException;
	//根据编号查找员工
	Employee findEmployee(String bianhao)throws MemberException;
	//遍历员工
	List<Employee> listEmployee()throws MemberException;
	//根据条件查找员工
	List<Employee> findEmployee(String accountno,String gender,Long deptid) throws MemberException;
	//注销员工
	void ZxEmployee(List<Long> list)throws MemberException;
	//根据名字查找职位	
	Zw findZw(String name)throws MemberException;
	
	
}
