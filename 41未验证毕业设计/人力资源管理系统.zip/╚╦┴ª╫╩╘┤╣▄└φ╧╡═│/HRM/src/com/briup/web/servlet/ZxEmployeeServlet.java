package com.briup.web.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.briup.common.exception.MemberException;
import com.briup.common.util.BeanFactory;
import com.briup.service.IMemberService;

@SuppressWarnings("serial")
public class ZxEmployeeServlet extends HttpServlet {


	@SuppressWarnings("unchecked")
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id[]=request.getParameterValues("zpid");
		List list=new ArrayList();
		for(String i:id)
			list.add(Long.parseLong(i));
		IMemberService service=(IMemberService)BeanFactory.getBean("memberService");
		try{
			service.ZxEmployee(list);
			request.getSession().setAttribute("message","注销员工档案成功！");
		}catch(MemberException e){
			e.printStackTrace();
			request.getSession().setAttribute("message",e.getMessage());
		}
		request.getRequestDispatcher("/listEmployee").forward(request,response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}

}
