package com.briup.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.briup.common.util.BeanFactory;
import com.briup.service.IAffairService;

@SuppressWarnings("serial")
public class DeleteZpServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Long zpid=Long.valueOf(request.getParameter("zpid"));
		IAffairService service=(IAffairService)BeanFactory.getBean("affairService");
		try{
			service.deleteRecruit(zpid);
			request.setAttribute("message","删除成功！");
			request.getSession().getServletContext().removeAttribute("zp");
			List list=service.listZP();
			request.getSession().setAttribute("zp",list);
			
			//request.getRequestDispatcher("/jsp/affair/Recruit.jsp").forward(request,response);
		}catch(Exception e){
			request.setAttribute("message",e.getMessage());
		}
		response.sendRedirect(request.getContextPath()+"/jsp/affair/Recruit.jsp");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}

}
