package com.briup.web.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.briup.common.exception.AffairException;
import com.briup.common.util.BeanFactory;
import com.briup.service.IAffairService;

@SuppressWarnings("serial")
public class DelJcsServlet extends HttpServlet {

	@SuppressWarnings("unchecked")
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id[]=request.getParameterValues("jid");
		List list=new ArrayList();
		for(String i:id)
			list.add(Long.parseLong(i));
		IAffairService service=(IAffairService)BeanFactory.getBean("affairService");
		try{
			service.deleteJc(list);
			request.getSession().setAttribute("message","删除奖惩记录成功！");
		}catch(AffairException e){
			e.printStackTrace();
			request.getSession().setAttribute("message",e.getMessage());
		}
		request.getRequestDispatcher("/listJc").forward(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}

}
