package com.briup.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.briup.common.util.BeanFactory;
import com.briup.dao.bean.Member;
import com.briup.service.IAffairService;

@SuppressWarnings("serial")
public class ListTrainServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public ListTrainServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		IAffairService service=(IAffairService)BeanFactory.getBean("affairService");
		request.getSession().removeAttribute("train");
		try{
			List list=service.listTrain();
			request.getSession().setAttribute("train",list);
		}catch(Exception e){
			request.setAttribute("message",e.getMessage());
		}
		Member m=(Member) request.getSession().getAttribute("member");
		if(m.getType().equals("0")){
			response.sendRedirect(request.getContextPath()+"/jsp/affair/queryTrain.jsp");
		}else{
			response.sendRedirect(request.getContextPath()+"/jsp/affair/selfqueryTrain.jsp");
		}
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}
	public void init() throws ServletException {
		// Put your code here
	}

}
