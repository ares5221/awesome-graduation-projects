package com.briup.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.briup.common.exception.MemberException;
import com.briup.common.util.BeanFactory;
import com.briup.dao.bean.Member;
import com.briup.service.IMemberService;

@SuppressWarnings("serial")
public class ListMemberServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		IMemberService service=(IMemberService)BeanFactory.getBean("memberService");
		try{
			Member m=(Member) request.getSession().getAttribute("member");
			System.out.println(m.getAccountno());
			//sc001相当于一个超级管理员 sc001/welcome
			if(!m.getAccountno().equals("sc001")){
				request.getSession().setAttribute("message","您无权进行此操作！");
				response.sendRedirect(request.getContextPath()+"/jsp/frame/right.jsp");
			}else{
				List<Member> list=service.listMember();
				list.remove(m);
				request.getSession().setAttribute("listMember",list);
				response.sendRedirect(request.getContextPath()+"/jsp/affair/member.jsp");
			}
		}catch(MemberException e){
			e.printStackTrace();
			request.getSession().setAttribute("message",e.getMessage());
		}
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}

}
