package com.briup.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.briup.common.exception.AffairException;
import com.briup.common.util.BeanFactory;
import com.briup.dao.bean.Jc;
import com.briup.service.IAffairService;

@SuppressWarnings("serial")
public class ListJcServlet extends HttpServlet {

	@SuppressWarnings("unchecked")
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		IAffairService service=(IAffairService)BeanFactory.getBean("affairService");
		try{
			List<Jc> list=service.listJc();
			request.getSession().setAttribute("jc",list);
		}catch(AffairException e){
			e.printStackTrace();
			request.getSession().setAttribute("message",e.getMessage());
		}
		response.sendRedirect(request.getContextPath()+"/jsp/affair/queryJc.jsp");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}

}
