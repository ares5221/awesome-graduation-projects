package com.briup.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.briup.common.exception.MemberException;
import com.briup.common.util.BeanFactory;
import com.briup.dao.bean.Department;
import com.briup.dao.bean.Employee;
import com.briup.service.IMemberService;

@SuppressWarnings("serial")
public class ListEmployeeServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		IMemberService service=(IMemberService)BeanFactory.getBean("memberService");
		try{
			List<Employee> list=service.listEmployee();
			request.getSession().setAttribute("employee",list);
			if(request.getSession().getAttribute("department")==null){
				List<Department> list1=service.listDept();
				request.getSession().setAttribute("department",list1);
			}
		}catch(MemberException e){
			request.getSession().setAttribute("message",e.getMessage());
		}
		response.sendRedirect(request.getContextPath()+"/jsp/member/glEmployee.jsp");
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}

}
