package com.briup.web.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.briup.common.exception.AffairException;
import com.briup.common.util.BeanFactory;
import com.briup.service.IAffairService;

@SuppressWarnings("serial")
public class DelFileServlet extends HttpServlet {


	@SuppressWarnings("unchecked")
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		IAffairService service=(IAffairService)BeanFactory.getBean("affairService");
		String ids[]=request.getParameterValues("fid");
		List<Long> listId=new ArrayList();
		for(String id:ids){
			listId.add(Long.valueOf(id));
		}
		try{
			service.delFiles(listId);
		}catch(AffairException e){
			e.printStackTrace();
		}
		response.sendRedirect(request.getContextPath()+"/listFile?type=0");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}

}
