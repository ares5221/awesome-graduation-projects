package com.briup.web.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.briup.common.util.BeanFactory;
import com.briup.dao.bean.Department;
import com.briup.dao.bean.Zw;
import com.briup.service.IMemberService;

@SuppressWarnings("serial")
public class ListTitleServlet extends HttpServlet {

	@SuppressWarnings("unchecked")
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/xml");
		response.setCharacterEncoding("UTF-8");
		response.setHeader("Cache-Control","no-cache");
		response.setHeader("Pragma","no-cache");
		
		PrintWriter out = response.getWriter();
		IMemberService service=(IMemberService)BeanFactory.getBean("memberService");
		Long deptid=Long.valueOf(request.getParameter("deptid"));
		try{
			Department dept=service.findDept(deptid);
			Set<Zw> set=dept.getLyZws();
			List<Zw> zwList=new ArrayList();
			for(Zw zw:set){
				zwList.add(zw);
			}
			StringBuffer bf = null;
			if(zwList != null){
				bf = new StringBuffer();
				bf.append("<?xml version='1.0' encoding='UTF-8'?>");
				bf.append("<zwList>");
				for(Zw zw:zwList){
					bf.append("<zw>"+zw.getName()+"</zw>");
				}
				bf.append("</zwList>");
			}
			out.println(bf.toString());
		}catch(Exception e){
			request.setAttribute("message",e.getMessage());
		}
		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}

}
