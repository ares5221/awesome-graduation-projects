package com.briup.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.briup.common.util.BeanFactory;
import com.briup.dao.bean.Employee;
import com.briup.service.IMemberService;

@SuppressWarnings("serial")
public class XqEmployeeServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String bianhao=null;
		/*
		 * 在jsp/member/glEmployee.jsp页面中   根据eid=${e.bianhao}跳转到xqEmployee.jsp页面
		 * <td width="10%" align="center">
			<img src="../../images/icon07.gif" alt="管理档案" 
			onclick="self.location='<c:url value='/xqEmployee?eid=${e.bianhao}'/>'"/>
		</td>
		
		28行中的eid 是由上面的jsp页面中获取  
		 */
		if(request.getSession().getAttribute("eid")!=null){
			bianhao=request.getParameter("eid");
		}
		if(request.getParameter("eid")!=null){
			bianhao=request.getParameter("eid");
		}
		IMemberService service=(IMemberService)BeanFactory.getBean("memberService");
		try{
			Employee e=service.findEmployee(bianhao);
			request.getSession().setAttribute("dqEmployee",e);
			response.sendRedirect(request.getContextPath()+"/jsp/member/xqEmployee.jsp");
		}catch(Exception e){
			e.printStackTrace();
			request.setAttribute("message","雇员信息查找失败！");
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}

}
