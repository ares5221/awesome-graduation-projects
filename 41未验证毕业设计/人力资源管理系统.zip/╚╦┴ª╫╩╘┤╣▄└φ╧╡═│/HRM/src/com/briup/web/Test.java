package com.briup.web;

public class Test {
	public static void main(String[] args) {
		String s="123456";
		System.out.println(s.substring(0,2));
	}
}
