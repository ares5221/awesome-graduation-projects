package com.briup.common.transaction;
//事务的开启，提交，回滚
public interface Transaction {
	void beginTransaction();

	void commit();

	void rollback();
}
