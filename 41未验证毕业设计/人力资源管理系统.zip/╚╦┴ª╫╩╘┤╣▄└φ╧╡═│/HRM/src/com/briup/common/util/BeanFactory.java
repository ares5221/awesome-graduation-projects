package com.briup.common.util;

import com.briup.dao.IAffairDao;
import com.briup.dao.IMemberDao;
import com.briup.dao.impl.AffairDaoImpl;
import com.briup.dao.impl.MemberDaoImpl;
import com.briup.service.IAffairService;
import com.briup.service.IMemberService;
import com.briup.service.impl.AffairServiceImpl;
import com.briup.service.impl.MemberServiceImpl;

public class BeanFactory {
	private static IMemberDao memberDao;
	private static IMemberService memberService;
	private static IAffairDao affairDao;
	private static IAffairService affairService;
	public static Object getBean(String beanName){
		if (beanName.equals("memberDao")) {
			memberDao = getMemberDao();
			return memberDao;
		}
		if(beanName.equals("memberService")){
			memberService=getMemberService();
			return memberService;
		}
		if (beanName.equals("affairDao")) {
			affairDao = getAffairDao();
			return affairDao;
		}
		if(beanName.equals("affairService")){
			affairService=getAffairService();
			return affairService;
		}
		return null;
	}
	synchronized private static IAffairService getAffairService() {
		// TODO Auto-generated method stub
		if(affairService==null)
			affairService=new AffairServiceImpl();
		return affairService;
	}
	synchronized private static IAffairDao getAffairDao() {
		// TODO Auto-generated method stub
		if (affairDao == null)
			affairDao = new AffairDaoImpl();
		return affairDao;
	}
	synchronized private static IMemberService getMemberService() {
		// TODO Auto-generated method stub
		if(memberService==null)
			memberService=new MemberServiceImpl();
		return memberService;
	}
	synchronized private static IMemberDao getMemberDao() {
		// TODO Auto-generated method stub
		if (memberDao == null)
			memberDao = new MemberDaoImpl();
		return memberDao;
	}
}
