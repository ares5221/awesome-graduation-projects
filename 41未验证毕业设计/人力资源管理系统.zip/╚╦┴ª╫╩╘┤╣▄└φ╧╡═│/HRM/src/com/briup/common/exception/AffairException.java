package com.briup.common.exception;

@SuppressWarnings("serial")
public class AffairException extends Exception {

	public AffairException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AffairException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AffairException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AffairException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
