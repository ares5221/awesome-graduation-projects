package com.briup.dao.bean;

import java.io.Serializable;
import java.util.Date;
@SuppressWarnings("serial")
public class Jc implements Serializable {
	private long id;
	private String name;
	private String reason;
	private String member;
	private String descr;
	private Date fbdate;
	private String fbMember;
	public String getDescr() {
		return descr;
	}
	public void setDescr(String descr) {
		this.descr = descr;
	}
	public Date getFbdate() {
		return fbdate;
	}
	public void setFbdate(Date fbdate) {
		this.fbdate = fbdate;
	}
	public String getFbMember() {
		return fbMember;
	}
	public void setFbMember(String fbMember) {
		this.fbMember = fbMember;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getMember() {
		return member;
	}
	public void setMember(String member) {
		this.member = member;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	
}
