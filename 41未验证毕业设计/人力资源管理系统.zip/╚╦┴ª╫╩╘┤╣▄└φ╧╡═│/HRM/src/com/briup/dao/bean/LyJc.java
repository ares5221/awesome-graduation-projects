package com.briup.dao.bean;

import java.util.Date;

/**
 * LyJc entity. @author MyEclipse Persistence Tools
 */

public class LyJc implements java.io.Serializable {

	// Fields

	private short id;
	private String name;
	private String reason;
	private String member;
	private String descr;
	private Date fbdate;
	private String fbmember;

	// Constructors

	/** default constructor */
	public LyJc() {
	}

	/** minimal constructor */
	public LyJc(String name) {
		this.name = name;
	}

	/** full constructor */
	public LyJc(String name, String reason, String member, String descr,
			Date fbdate, String fbmember) {
		this.name = name;
		this.reason = reason;
		this.member = member;
		this.descr = descr;
		this.fbdate = fbdate;
		this.fbmember = fbmember;
	}

	// Property accessors

	public short getId() {
		return this.id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getReason() {
		return this.reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getMember() {
		return this.member;
	}

	public void setMember(String member) {
		this.member = member;
	}

	public String getDescr() {
		return this.descr;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}

	public Date getFbdate() {
		return this.fbdate;
	}

	public void setFbdate(Date fbdate) {
		this.fbdate = fbdate;
	}

	public String getFbmember() {
		return this.fbmember;
	}

	public void setFbmember(String fbmember) {
		this.fbmember = fbmember;
	}

}