package com.briup.dao;

import java.sql.Date;

public class DateTest {
@SuppressWarnings("deprecation")
public static void main(String[] args) {
	String s="20120514";
	
	int year=Integer.parseInt(s.substring(0,4 ))-1900;
	System.out.println(year);
	
	int month=Integer.parseInt(s.substring(4, 6))-1;
	System.out.println(month);
	
	int day=Integer.parseInt(s.substring(6, 8));
	System.out.println(day);

	System.out.println(new Date(year,month,day));
	
	long testTime=new Date(year,month,day).getTime();
	System.out.println(testTime);
	
	long currentTime=System.currentTimeMillis();
	System.out.println(currentTime);
	
	System.out.println((currentTime-testTime)/(24*3600*1000));
	
	
	
}
}
