package com.briup.dao.bean;

import java.util.Date;

/**
 * LyTrain entity. @author MyEclipse Persistence Tools
 */

public class LyTrain implements java.io.Serializable {

	// Fields

	private short id;
	private String tname;
	private String tgoal;
	private String tjc;
	private String tmember;
	private String kdate;
	private String jdate;
	private short tnumber;
	private String teacher;
	private String jibie;
	private String yx;
	private Date fbdate;

	// Constructors

	/** default constructor */
	public LyTrain() {
	}

	/** full constructor */
	public LyTrain(String tname, String tgoal, String tjc, String tmember,
			String kdate, String jdate, short tnumber, String teacher,
			String jibie, String yx, Date fbdate) {
		this.tname = tname;
		this.tgoal = tgoal;
		this.tjc = tjc;
		this.tmember = tmember;
		this.kdate = kdate;
		this.jdate = jdate;
		this.tnumber = tnumber;
		this.teacher = teacher;
		this.jibie = jibie;
		this.yx = yx;
		this.fbdate = fbdate;
	}

	// Property accessors

	public short getId() {
		return this.id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public String getTname() {
		return this.tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getTgoal() {
		return this.tgoal;
	}

	public void setTgoal(String tgoal) {
		this.tgoal = tgoal;
	}

	public String getTjc() {
		return this.tjc;
	}

	public void setTjc(String tjc) {
		this.tjc = tjc;
	}

	public String getTmember() {
		return this.tmember;
	}

	public void setTmember(String tmember) {
		this.tmember = tmember;
	}

	public String getKdate() {
		return this.kdate;
	}

	public void setKdate(String kdate) {
		this.kdate = kdate;
	}

	public String getJdate() {
		return this.jdate;
	}

	public void setJdate(String jdate) {
		this.jdate = jdate;
	}

	public short getTnumber() {
		return this.tnumber;
	}

	public void setTnumber(short tnumber) {
		this.tnumber = tnumber;
	}

	public String getTeacher() {
		return this.teacher;
	}

	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}

	public String getJibie() {
		return this.jibie;
	}

	public void setJibie(String jibie) {
		this.jibie = jibie;
	}

	public String getYx() {
		return this.yx;
	}

	public void setYx(String yx) {
		this.yx = yx;
	}

	public Date getFbdate() {
		return this.fbdate;
	}

	public void setFbdate(Date fbdate) {
		this.fbdate = fbdate;
	}

}