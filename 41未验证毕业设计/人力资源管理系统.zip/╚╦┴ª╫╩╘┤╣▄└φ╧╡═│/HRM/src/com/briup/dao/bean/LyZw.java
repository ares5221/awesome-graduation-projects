package com.briup.dao.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * LyZw entity. @author MyEclipse Persistence Tools
 */

public class LyZw implements java.io.Serializable {

	// Fields

	private short id;
	private LyDepartment lyDepartment;
	private String name;
	private Set lyEmployees = new HashSet(0);

	// Constructors

	/** default constructor */
	public LyZw() {
	}

	/** minimal constructor */
	public LyZw(String name) {
		this.name = name;
	}

	/** full constructor */
	public LyZw(LyDepartment lyDepartment, String name, Set lyEmployees) {
		this.lyDepartment = lyDepartment;
		this.name = name;
		this.lyEmployees = lyEmployees;
	}

	// Property accessors

	public short getId() {
		return this.id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public LyDepartment getLyDepartment() {
		return this.lyDepartment;
	}

	public void setLyDepartment(LyDepartment lyDepartment) {
		this.lyDepartment = lyDepartment;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set getLyEmployees() {
		return this.lyEmployees;
	}

	public void setLyEmployees(Set lyEmployees) {
		this.lyEmployees = lyEmployees;
	}

}