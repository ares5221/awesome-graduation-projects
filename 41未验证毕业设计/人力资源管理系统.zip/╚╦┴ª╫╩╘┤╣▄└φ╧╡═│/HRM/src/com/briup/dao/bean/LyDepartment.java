package com.briup.dao.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * LyDepartment entity. @author MyEclipse Persistence Tools
 */

public class LyDepartment implements java.io.Serializable {

	// Fields

	private short id;
	private String name;
	private Set lyEmployees = new HashSet(0);
	private Set lyZws = new HashSet(0);

	// Constructors

	/** default constructor */
	public LyDepartment() {
	}

	/** full constructor */
	public LyDepartment(String name, Set lyEmployees, Set lyZws) {
		this.name = name;
		this.lyEmployees = lyEmployees;
		this.lyZws = lyZws;
	}

	// Property accessors

	public short getId() {
		return this.id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set getLyEmployees() {
		return this.lyEmployees;
	}

	public void setLyEmployees(Set lyEmployees) {
		this.lyEmployees = lyEmployees;
	}

	public Set getLyZws() {
		return this.lyZws;
	}

	public void setLyZws(Set lyZws) {
		this.lyZws = lyZws;
	}

}