package com.briup.dao.bean;

/**
 * LyMember entity. @author MyEclipse Persistence Tools
 */

public class LyMember implements java.io.Serializable {

	// Fields

	private short id;
	private String accountno;
	private String password;
	private String type;
	private String status;

	// Constructors

	/** default constructor */
	public LyMember() {
	}

	/** full constructor */
	public LyMember(String accountno, String password, String type,
			String status) {
		this.accountno = accountno;
		this.password = password;
		this.type = type;
		this.status = status;
	}

	// Property accessors

	public short getId() {
		return this.id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public String getAccountno() {
		return this.accountno;
	}

	public void setAccountno(String accountno) {
		this.accountno = accountno;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}