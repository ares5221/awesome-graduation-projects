package com.briup.dao.bean;

import java.util.Date;

/**
 * LyEmployee entity. @author MyEclipse Persistence Tools
 */

public class LyEmployee implements java.io.Serializable {

	// Fields

	private short id;
	private LyZw lyZw;
	private LyDepartment lyDepartment;
	private String name;
	private String pinyin;
	private String gender;
	private String birthspace;
	private String nation;
	private String birthtime;
	private String title;
	private String cellphone;
	private String wphone;
	private String fphone;
	private String email;
	private String zz;
	private String health;
	private String profession;
	private String xl;
	private String marry;
	private String sfz;
	private String address;
	private String bianhao;
	private String icon;
	private Date luruDate;
	private Date lastmodifydate;
	private String luruAdminbianhao;
	private String status;

	// Constructors

	/** default constructor */
	public LyEmployee() {
	}

	/** minimal constructor */
	public LyEmployee(String name, String gender) {
		this.name = name;
		this.gender = gender;
	}

	/** full constructor */
	public LyEmployee(LyZw lyZw, LyDepartment lyDepartment, String name,
			String pinyin, String gender, String birthspace, String nation,
			String birthtime, String title, String cellphone, String wphone,
			String fphone, String email, String zz, String health,
			String profession, String xl, String marry, String sfz,
			String address, String bianhao, String icon, Date luruDate,
			Date lastmodifydate, String luruAdminbianhao, String status) {
		this.lyZw = lyZw;
		this.lyDepartment = lyDepartment;
		this.name = name;
		this.pinyin = pinyin;
		this.gender = gender;
		this.birthspace = birthspace;
		this.nation = nation;
		this.birthtime = birthtime;
		this.title = title;
		this.cellphone = cellphone;
		this.wphone = wphone;
		this.fphone = fphone;
		this.email = email;
		this.zz = zz;
		this.health = health;
		this.profession = profession;
		this.xl = xl;
		this.marry = marry;
		this.sfz = sfz;
		this.address = address;
		this.bianhao = bianhao;
		this.icon = icon;
		this.luruDate = luruDate;
		this.lastmodifydate = lastmodifydate;
		this.luruAdminbianhao = luruAdminbianhao;
		this.status = status;
	}

	// Property accessors

	public short getId() {
		return this.id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public LyZw getLyZw() {
		return this.lyZw;
	}

	public void setLyZw(LyZw lyZw) {
		this.lyZw = lyZw;
	}

	public LyDepartment getLyDepartment() {
		return this.lyDepartment;
	}

	public void setLyDepartment(LyDepartment lyDepartment) {
		this.lyDepartment = lyDepartment;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPinyin() {
		return this.pinyin;
	}

	public void setPinyin(String pinyin) {
		this.pinyin = pinyin;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBirthspace() {
		return this.birthspace;
	}

	public void setBirthspace(String birthspace) {
		this.birthspace = birthspace;
	}

	public String getNation() {
		return this.nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public String getBirthtime() {
		return this.birthtime;
	}

	public void setBirthtime(String birthtime) {
		this.birthtime = birthtime;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCellphone() {
		return this.cellphone;
	}

	public void setCellphone(String cellphone) {
		this.cellphone = cellphone;
	}

	public String getWphone() {
		return this.wphone;
	}

	public void setWphone(String wphone) {
		this.wphone = wphone;
	}

	public String getFphone() {
		return this.fphone;
	}

	public void setFphone(String fphone) {
		this.fphone = fphone;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getZz() {
		return this.zz;
	}

	public void setZz(String zz) {
		this.zz = zz;
	}

	public String getHealth() {
		return this.health;
	}

	public void setHealth(String health) {
		this.health = health;
	}

	public String getProfession() {
		return this.profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	public String getXl() {
		return this.xl;
	}

	public void setXl(String xl) {
		this.xl = xl;
	}

	public String getMarry() {
		return this.marry;
	}

	public void setMarry(String marry) {
		this.marry = marry;
	}

	public String getSfz() {
		return this.sfz;
	}

	public void setSfz(String sfz) {
		this.sfz = sfz;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBianhao() {
		return this.bianhao;
	}

	public void setBianhao(String bianhao) {
		this.bianhao = bianhao;
	}

	public String getIcon() {
		return this.icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public Date getLuruDate() {
		return this.luruDate;
	}

	public void setLuruDate(Date luruDate) {
		this.luruDate = luruDate;
	}

	public Date getLastmodifydate() {
		return this.lastmodifydate;
	}

	public void setLastmodifydate(Date lastmodifydate) {
		this.lastmodifydate = lastmodifydate;
	}

	public String getLuruAdminbianhao() {
		return this.luruAdminbianhao;
	}

	public void setLuruAdminbianhao(String luruAdminbianhao) {
		this.luruAdminbianhao = luruAdminbianhao;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}