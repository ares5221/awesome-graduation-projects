package com.briup.dao.bean;

/**
 * LyYp entity. @author MyEclipse Persistence Tools
 */

public class LyYp implements java.io.Serializable {

	// Fields

	private short id;
	private String name;
	private String gender;
	private short age;
	private String zw;
	private String zy;
	private String jy;
	private String yx;
	private String phone;
	private String email;
	private String jj;

	// Constructors

	/** default constructor */
	public LyYp() {
	}

	/** minimal constructor */
	public LyYp(String name) {
		this.name = name;
	}

	/** full constructor */
	public LyYp(String name, String gender, short age, String zw, String zy,
			String jy, String yx, String phone, String email, String jj) {
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.zw = zw;
		this.zy = zy;
		this.jy = jy;
		this.yx = yx;
		this.phone = phone;
		this.email = email;
		this.jj = jj;
	}

	// Property accessors

	public short getId() {
		return this.id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public short getAge() {
		return this.age;
	}

	public void setAge(short age) {
		this.age = age;
	}

	public String getZw() {
		return this.zw;
	}

	public void setZw(String zw) {
		this.zw = zw;
	}

	public String getZy() {
		return this.zy;
	}

	public void setZy(String zy) {
		this.zy = zy;
	}

	public String getJy() {
		return this.jy;
	}

	public void setJy(String jy) {
		this.jy = jy;
	}

	public String getYx() {
		return this.yx;
	}

	public void setYx(String yx) {
		this.yx = yx;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getJj() {
		return this.jj;
	}

	public void setJj(String jj) {
		this.jj = jj;
	}

}