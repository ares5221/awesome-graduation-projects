package com.briup.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.briup.common.util.HibernateSessionFactory;
import com.briup.dao.IAffairDao;
import com.briup.dao.bean.Jc;
import com.briup.dao.bean.Loadfile;
import com.briup.dao.bean.Recruit;
import com.briup.dao.bean.Salary;
import com.briup.dao.bean.Train;

public class AffairDaoImpl implements IAffairDao {

//	遍历所有的招聘信息      返回结果为List类型
	public List listZP() throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Recruit");
		return query.list();
	}
//	通过recruit来增加应聘信息
	public void addRecruit(Recruit recruit) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		session.save(recruit);
	}
//	通过id删除招聘信息
	public void deleteRecruit(Long id) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Recruit where id=?");
		query.setLong(0,id);
		session.delete(query.uniqueResult());
	}
//	遍历所有的应聘信息      返回结果为List类型
	public List listYp() throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Yp");
		return query.list();
	}
//	通过Train来增加培训信息
	public void addTrain(Train train) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		session.save(train);
	}
//	遍历所有的培训信息     返回结果为List类型
	public List listTrain() throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Train");
		return query.list();
	}
//	根据name 和 teacher 来查询所有的培训信息       返回结果为List类型
	public List queryTrain(String name, String teacher) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		StringBuffer sb=new StringBuffer();
		sb.append("from Train where 1=1");
		if(name.length()!=0)
			sb.append(" and tname='"+name+"'");
		if(teacher.length()!=0)
			sb.append(" and teacher='"+teacher+"'");
		Query query=session.createQuery(sb.toString());
		return query.list();
	}
//	根据Jc来增加或更新奖惩信息
	public void addJc(Jc jc) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		session.saveOrUpdate(jc);
	}
//	遍历所有的奖惩信息      返回结果为List类型
	public List listJc() throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Jc");
		return query.list();
	}
//	根据name 和 member 来查询奖惩信息    返回结果为List类型
	public List queryJc(String name, String member) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		StringBuffer sb=new StringBuffer();
		sb.append("from Jc where 1=1");
		if(name.length()!=0)
			sb.append(" and name='"+name+"'");
		if(member.length()!=0)
			sb.append(" and member='"+member+"'");
		Query query=session.createQuery(sb.toString());
		return query.list();
	}
//	通过id来删除奖惩信息
	public void deleteJc(Long id) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Jc where id=?");
		query.setLong(0,id);
		session.delete(query.uniqueResult());
	}
//	通过id来查找培训信息    返回结果为Train 类型
	public Train train(Long id) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Train where id=?");
		query.setLong(0,id);
		return (Train) query.uniqueResult();
	}
//	根据train来删除培训信息
	public void deleteTrain(Train train) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		session.delete(train);
	}
//	根据bianhao 和 month 来查询薪资     返回结果为Salary 类型
	public Salary querySalary(String bianhao, String month) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		String hql="from Salary where ebianhao='"+bianhao+"' and smonth='"+month+"'";
		Query query=session.createQuery(hql);
		return (Salary) query.uniqueResult();
	}
//	通过salary来增加薪资信息
	public void addSalary(Salary salary) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		session.save(salary);
	}
//	遍历所有薪资    返回结果为List 类型
	public List listSalary() throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		String hql="from Salary order by id desc";
		Query query=session.createQuery(hql);
		return query.list();
	}
//	根据bianhao 和 month 来查询薪资     返回结果为List 类型
	public List findSalary(String bianhao, String month) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		StringBuffer sb=new StringBuffer();
		sb.append("from Salary where 1=1");
		if(bianhao.length()!=0)
			sb.append(" and ebianhao='"+bianhao+"'");
		if(month.length()!=0)
			sb.append(" and smonth='"+month+"'");
		Query query=session.createQuery(sb.toString());
		return query.list();
	}
//	根据salary来删除薪资信息
	public void deleteSalary(Salary salary) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		session.delete(salary);
	}
//	根据id来查询薪资，返回结果为Salary类型
	public Salary salary(Long id) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Salary where id=?");
		query.setLong(0,id);
		return (Salary) query.uniqueResult();
	}
//	保存文件列表
	public void saveFile(Loadfile file) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		session.save(file);
	}
//	遍历文件列表， 返回结果为List类型
	public List listFile() throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Loadfile");
		return query.list();
	}
//	通过file来删除文件列表
	public void delFile(Loadfile file) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		session.delete(file);
	}
//	通过id来查询文件列表，返回结果为Loadfile类型
	public Loadfile findFile(Long id) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Loadfile where id="+id);
		return (Loadfile) query.uniqueResult();
	}
}
