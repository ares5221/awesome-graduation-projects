package com.briup.dao.bean;

import java.io.Serializable;
@SuppressWarnings("serial")
public class MonSalary implements Serializable {
	private String smonth;
	private Long salary;
	public String getMonth() {
		return smonth;
	}
	public void setMonth(String month) {
		this.smonth = month;
	}
	public Long getSalary() {
		return salary;
	}
	public void setSalary(Long salary) {
		this.salary = salary;
	}
	
}
