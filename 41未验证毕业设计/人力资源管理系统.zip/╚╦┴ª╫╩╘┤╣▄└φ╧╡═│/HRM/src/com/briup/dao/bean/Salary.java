package com.briup.dao.bean;

import java.io.Serializable;
import java.util.Date;
@SuppressWarnings("serial")
public class Salary implements Serializable {
	private long id;
	private String ebianhao;
	private String smonth;
	private long jsalary;
	private long zsalary;
	private long esalary;
	private long ssalary;
	private long qsalary;
	private long fsalary;
	private Date fbdate;
	
	public Salary(){
		
	}
	

	public String getEbianhao() {
		return ebianhao;
	}


	public void setEbianhao(String ebianhao) {
		this.ebianhao = ebianhao;
	}


	public long getEsalary() {
		return esalary;
	}
	public void setEsalary(long esalary) {
		this.esalary = esalary;
	}
	public Date getFbdate() {
		return fbdate;
	}
	public void setFbdate(Date fbdate) {
		this.fbdate = fbdate;
	}
	public long getFsalary() {
		return fsalary;
	}
	public void setFsalary(long fsalary) {
		this.fsalary = fsalary;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getJsalary() {
		return jsalary;
	}
	public void setJsalary(long jsalary) {
		this.jsalary = jsalary;
	}
	public long getQsalary() {
		return qsalary;
	}
	public void setQsalary(long qsalary) {
		this.qsalary = qsalary;
	}
	public String getSmonth() {
		return smonth;
	}
	public void setSmonth(String smonth) {
		this.smonth = smonth;
	}
	public long getSsalary() {
		return ssalary;
	}
	public void setSsalary(long ssalary) {
		this.ssalary = ssalary;
	}
	public long getZsalary() {
		return zsalary;
	}
	public void setZsalary(long zsalary) {
		this.zsalary = zsalary;
	}
	
	
}
