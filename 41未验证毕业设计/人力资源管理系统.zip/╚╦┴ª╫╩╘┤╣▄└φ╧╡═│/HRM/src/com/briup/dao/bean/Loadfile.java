package com.briup.dao.bean;

import java.io.Serializable;
@SuppressWarnings("serial")
public class Loadfile implements Serializable {
	private long id;
	private String loadfile;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getLoadfile() {
		return loadfile;
	}
	public void setLoadfile(String loadfile) {
		this.loadfile = loadfile;
	}
	
}
