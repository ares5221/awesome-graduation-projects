package com.briup.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.briup.common.util.HibernateSessionFactory;
import com.briup.dao.IMemberDao;
import com.briup.dao.bean.Department;
import com.briup.dao.bean.Employee;
import com.briup.dao.bean.Member;
import com.briup.dao.bean.Zw;

public class MemberDaoImpl implements IMemberDao{

	public void addEmployee(Employee employee) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		session.saveOrUpdate(employee);
	}

	public Employee findEmployee(String bianhao) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Employee where bianhao=?");
		query.setString(0,bianhao);
		return (Employee)query.uniqueResult();
	}

	public Department findDept(Long id) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Department where id=?");
		query.setLong(0,id);
		return (Department)query.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<Department> listDept() throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Department");
		return query.list();
	}

	public Zw findZw(String name) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Zw where name=?");
		query.setString(0,name);
		return (Zw)query.uniqueResult();
	}

	public void addMember(Member member) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		session.saveOrUpdate(member);
	}

	public Member findMember(String accountno) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Member where accountno=?");
		query.setString(0,accountno);
		return (Member) query.uniqueResult();
	}

	public List listEmployee() throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Employee");
		return query.list();
	}

	public List findEmployee(String accountno, String gender,Long deptid) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		StringBuffer sb=new StringBuffer();
		sb.append("from Employee where 1=1");
		if(accountno!=null&&accountno.length()!=0)
			sb.append(" and bianhao='"+accountno+"'");
		if(gender!=null)
			sb.append(" and gender='"+gender+"'");
		if(deptid!=0){
			sb.append(" and deptid="+deptid);
		}
		System.out.println(sb.toString());
		Query query=session.createQuery(sb.toString());
		return query.list();
	}

	public void delEmployee(Employee employee) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		session.delete(employee);
	}

	public Employee QueryEmployee(Long id) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Employee where id=?");
		query.setLong(0,id);
		return (Employee) query.uniqueResult();
	}

	public void delMember(Member member) throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		session.delete(member);
	}

	public List listMember() throws Exception {
		// TODO Auto-generated method stub
		Session session=HibernateSessionFactory.getSession();
		Query query=session.createQuery("from Member");
		return query.list();
	}
}
