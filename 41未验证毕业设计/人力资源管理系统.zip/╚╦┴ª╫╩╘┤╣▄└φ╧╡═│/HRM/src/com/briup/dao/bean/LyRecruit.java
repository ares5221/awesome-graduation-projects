package com.briup.dao.bean;

import java.util.Date;

/**
 * LyRecruit entity. @author MyEclipse Persistence Tools
 */

public class LyRecruit implements java.io.Serializable {

	// Fields

	private short id;
	private String content;
	private Date fbdate;

	// Constructors

	/** default constructor */
	public LyRecruit() {
	}

	/** minimal constructor */
	public LyRecruit(String content) {
		this.content = content;
	}

	/** full constructor */
	public LyRecruit(String content, Date fbdate) {
		this.content = content;
		this.fbdate = fbdate;
	}

	// Property accessors

	public short getId() {
		return this.id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getFbdate() {
		return this.fbdate;
	}

	public void setFbdate(Date fbdate) {
		this.fbdate = fbdate;
	}

}