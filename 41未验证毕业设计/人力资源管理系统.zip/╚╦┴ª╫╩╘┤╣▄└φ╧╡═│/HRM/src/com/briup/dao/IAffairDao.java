package com.briup.dao;

import java.util.List;

import com.briup.dao.bean.Jc;
import com.briup.dao.bean.Loadfile;
import com.briup.dao.bean.Recruit;
import com.briup.dao.bean.Salary;
import com.briup.dao.bean.Train;

public interface IAffairDao {
//	遍历所有的招聘信息      返回结果为List类型
	List listZP()throws Exception;
	
//	通过recruit来增加应聘信息	
	void addRecruit(Recruit recruit)throws Exception;
	
//	通过id删除招聘信息	
	void deleteRecruit(Long id)throws Exception;
	
//	遍历所有的应聘信息      返回结果为List类型	
	List listYp()throws Exception;
	
//	通过Train来增加培训信息	
	void addTrain(Train train)throws Exception;
	
//	遍历所有的培训信息     返回结果为List类型	
	List listTrain() throws Exception;
	
//	根据name 和 teacher 来查询所有的培训信息       返回结果为List类型	
	List queryTrain(String name,String teacher)throws Exception;
	
//	通过id来查找培训信息    返回结果为Train 类型	
	Train train(Long id)throws Exception;
	
//	根据Jc来增加或更新奖惩信息	
	void addJc(Jc jc)throws Exception;
	
//	遍历所有的奖惩信息      返回结果为List类型	
	List listJc() throws Exception;
	
//	根据name 和 member 来查询奖惩信息    返回结果为List类型	
	List queryJc(String name,String member)throws Exception;
	
//	通过id来删除奖惩信息
	void deleteJc(Long id)throws Exception;
	
//	根据train来删除培训信息	
	void deleteTrain(Train train)throws Exception;
	
//	根据bianhao 和 month 来查询薪资     返回结果为Salary 类型	
	Salary querySalary(String bianhao,String month)throws Exception;
	
//	通过salary来增加薪资信息	
	void addSalary(Salary salary)throws Exception;
	
//	遍历所有薪资    返回结果为List 类型	
	List listSalary()throws Exception;
	
//	根据bianhao 和 month 来查询薪资     返回结果为List 类型	
	List findSalary(String bianhao,String month)throws Exception;
	
//	根据salary来删除薪资信息	
	void deleteSalary(Salary salary)throws Exception;
	
//	根据id来查询薪资，返回结果为Salary类型	
	Salary salary(Long id)throws Exception;
	
//	保存文件列表	
	void saveFile(Loadfile file)throws Exception;
	
//	遍历文件列表， 返回结果为List类型	
	List listFile()throws Exception;
	
//	通过file来删除文件列表	
	void delFile(Loadfile file)throws Exception;
	
//	通过id来查询文件列表，返回结果为Loadfile类型	
	Loadfile findFile(Long id)throws Exception;
	
}
