package com.briup.dao;

import java.util.List;

import com.briup.dao.bean.Department;
import com.briup.dao.bean.Employee;
import com.briup.dao.bean.Member;
import com.briup.dao.bean.Zw;

public interface IMemberDao {
	
	//对于每一个职工分配一个
	void addMember(Member member)throws Exception;
	
	
	//列出所有用户信息，返回结果为List
	List listMember() throws Exception;
	
	//根据用户帐号删除用户
	void delMember(Member member)throws Exception;
	
	//根据用户帐号查找该用户
	Member findMember(String accountno)throws Exception;
	
	
	
	//添加或修改雇员信息
	void addEmployee(Employee employee)throws Exception;
	
	//删除员工档案
	void delEmployee(Employee employee)throws Exception;
	
	//根据id查找雇员
	Employee QueryEmployee(Long id)throws Exception;
	
	//根据员工编号查找雇员
	Employee findEmployee(String bianhao)throws Exception;

	//查找所有的雇员信息
	List listEmployee()throws Exception;
	
	//按条件查询雇员信息
	List findEmployee(String accountno,String gender,Long deptid)throws Exception;
	
	
	
	
	//根据部门id查找该部门
	Department findDept(Long id) throws Exception;
	
	//列出所有的部门
	List<Department> listDept()throws Exception;
	
	
	
	
	//根据职位的名字查找该职位信息
	Zw findZw(String name) throws Exception;
	
	
}
