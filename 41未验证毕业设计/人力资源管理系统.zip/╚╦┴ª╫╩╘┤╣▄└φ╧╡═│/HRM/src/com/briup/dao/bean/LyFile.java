package com.briup.dao.bean;

/**
 * LyFile entity. @author MyEclipse Persistence Tools
 */

public class LyFile implements java.io.Serializable {

	// Fields

	private short id;
	private String loadfile;

	// Constructors

	/** default constructor */
	public LyFile() {
	}

	/** full constructor */
	public LyFile(String loadfile) {
		this.loadfile = loadfile;
	}

	// Property accessors

	public short getId() {
		return this.id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public String getLoadfile() {
		return this.loadfile;
	}

	public void setLoadfile(String loadfile) {
		this.loadfile = loadfile;
	}

}