package com.briup.dao.bean;

import java.util.Date;

/**
 * LySalary entity. @author MyEclipse Persistence Tools
 */

public class LySalary implements java.io.Serializable {

	// Fields

	private short id;
	private String ebianhao;
	private String smonth;
	private Integer jsalary;
	private short zsalary;
	private short esalary;
	private Integer ssalary;
	private short qsalary;
	private short fsalary;
	private Date fbdate;

	// Constructors

	/** default constructor */
	public LySalary() {
	}

	/** full constructor */
	public LySalary(String ebianhao, String smonth, Integer jsalary,
			short zsalary, short esalary, Integer ssalary, short qsalary,
			short fsalary, Date fbdate) {
		this.ebianhao = ebianhao;
		this.smonth = smonth;
		this.jsalary = jsalary;
		this.zsalary = zsalary;
		this.esalary = esalary;
		this.ssalary = ssalary;
		this.qsalary = qsalary;
		this.fsalary = fsalary;
		this.fbdate = fbdate;
	}

	// Property accessors

	public short getId() {
		return this.id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public String getEbianhao() {
		return this.ebianhao;
	}

	public void setEbianhao(String ebianhao) {
		this.ebianhao = ebianhao;
	}

	public String getSmonth() {
		return this.smonth;
	}

	public void setSmonth(String smonth) {
		this.smonth = smonth;
	}

	public Integer getJsalary() {
		return this.jsalary;
	}

	public void setJsalary(Integer jsalary) {
		this.jsalary = jsalary;
	}

	public short getZsalary() {
		return this.zsalary;
	}

	public void setZsalary(short zsalary) {
		this.zsalary = zsalary;
	}

	public short getEsalary() {
		return this.esalary;
	}

	public void setEsalary(short esalary) {
		this.esalary = esalary;
	}

	public Integer getSsalary() {
		return this.ssalary;
	}

	public void setSsalary(Integer ssalary) {
		this.ssalary = ssalary;
	}

	public short getQsalary() {
		return this.qsalary;
	}

	public void setQsalary(short qsalary) {
		this.qsalary = qsalary;
	}

	public short getFsalary() {
		return this.fsalary;
	}

	public void setFsalary(short fsalary) {
		this.fsalary = fsalary;
	}

	public Date getFbdate() {
		return this.fbdate;
	}

	public void setFbdate(Date fbdate) {
		this.fbdate = fbdate;
	}

}