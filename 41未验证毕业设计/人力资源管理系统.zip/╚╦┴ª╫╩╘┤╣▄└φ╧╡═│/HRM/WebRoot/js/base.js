function checkModifyPwd(form){
	var password1=form.password1.value;
	var password2=form.password2.value;
	if(isEmpty(password1)){
		alert("请输入新密码！");
		return false;
	}
	if(isEmpty(password2)){
		alert("请再次输入新密码！");
		return false;
	}
	if (checkStrLength(password1) < 6) {
		alert("密码不能少于6位！");
		return false;
	}
	if (checkStrLength(password1) > 14) {
		alert("密码必须在6－14位之间");
		return false;
	}
	if (password1 != password2) {
		alert("两次输入的密码不一致！");
		return false;
	}
}
function checkSalaryForm(form){
	var bianhao=form.bianhao.value;
	var smonth=form.smonth.value;
	var jsalary=form.jsalary.value;
	if(isEmpty(bianhao)){
		alert("员工编号不能为空！");
		return false;
	}
	if(isEmpty(smonth)){
		alert("所属月份不能为空！");
		return false;
	}
	if((checkStrLength(smonth)!=6)||!isNumber(smonth)){
		alert("所属月份没有按指定格式输入！");
		return false;
	}
	if(isEmpty(jsalary)){
		alert("基本工资不能为空！");
		return false;
	}
}
function checkLoginForm(form) {
	var accountno = form.accountno.value;
	var password = form.password.value;
	if (isEmpty(accountno)) {
		alert("用户帐号不能为空！");
		return false;
	}
	if (isEmpty(password)) {
		alert("用户密码不能为空！");
		return false;
	}
}
function checkAddEmployeeForm(form){
	var name=form.name.value;
	var pinyin=form.pinyin.value;
	var birthspace=form.birthspace.value;
	var nation=form.nation.value;
	var birthtime=form.birthtime.value;
	var deptid=form.deptid.value;
	var zz=form.zz.value;
	var xl=form.xl.value;
	var sfz=form.sfz.value;
	var bianhao=form.bianhao.value;
	var email=form.email.value;
	if (isEmpty(name)){
		alert("职员姓名不能为空！");
		return false;
	}
	if(isEmpty(pinyin)){
		alert("姓名拼音不能为空！");
		return false;
	}
	if(isEmpty(birthspace)){
		alert("籍贯不能为空！");
		return false;
	}
	if(isEmpty(nation)){
		alert("民族不能为空！");
		return false;
	}
	if (isEmpty(birthtime)){
		alert("出生日期不能为空！");
		return false;
	}
	if(deptid==0){
		alert("所在部门不能为空！");
		return false;
	}
	if(!isEmpty(email)&&!isEmail(email)){
		alert("\u5bf9\u4e0d\u8d77\uff0c\u60a8\u8f93\u5165E\u2014mail\u65e0\u6548\uff01");
		return false;
	}
	if(zz==0){
		alert("政治面貌不能为空！");
		return false;
	}
	if(xl==0){
		alert("学历不能为空！");
		return false;
	}
	if (isEmpty(sfz)){
		alert("身份证号不能为空！");
		return false;
	}
	if (isEmpty(bianhao)){
		alert("职员编号不能为空！");
		return false;
	}
}
function checkTrainForm(form){
	var tname=form.tname.value;
	var tgoal=form.tgoal.value;
	var tmember=form.tmember.value;
	var kdate=form.kdate.value;
	var jdate=form.jdate.value;
	var tnumber=form.tnumber.value;
	var teacher=form.teacher.value;
	var jibie=form.jibie.value;
	var yx=form.yx.value;
	if(/^\s*$/.test(tname)){
		alert("培训名称不能为空！");
		return false;
	}
	if(/^\s*$/.test(tgoal)){
		alert("培训目的不能为空！");
		return false;
	}
	if(/^\s*$/.test(tmember)){
		alert("培训人员不能为空！");
		return false;
	}
	if(/^\s*$/.test(kdate)){
		alert("开始日期不能为空！");
		return false;
	}
	if(/^\s*$/.test(jdate)){
		alert("结束日期不能为空！");
		return false;	
	}
	if(/^\s*$/.test(tnumber)){
		alert("参加人数不能为空！");
		return false;
	}
	if(/^\s*$/.test(teacher)){
		alert("培训讲师不能为空！");
		return false;
	}
	if(/^\s*$/.test(jibie)){
		alert("培训级别不能为空！");
		return false;
	}
	if(/^\s*$/.test(yx)){
		alert("影响程度不能为空！");
		return false;
	}
}
function createText() {
	var temp = document.getElementById("register_re");
	if (isChecked("re")) {
		temp.style.display = "block";
	} else {
		temp.style.display = "none";
		var tempInput = document.getElementById("recommender");
		var tempInput2 = document.getElementById("recommender2");
		tempInput.value = "";
		tempInput2.value = "";
	}
}
function changeRecommander(tempInput) {
	var tempInputValue = tempInput.value;
	var tempInput2 = document.getElementById("recommender");
	tempInput2.value = tempInputValue;
}
function validateRegisterForm(form) {
	var username = form.username.value;
	var password = form.password.value;
	var passwordre = form.passwordre.value;
	if (isEmpty(username)) {
		alert("用户名不能为空！");
		return false;
	}
	if (isEmpty(password)) {
		alert("密码不能为空！");
		return false;
	}
	if (checkStrLength(password) < 6) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u5bc6\u7801\u957f\u5ea6\u4e0d\u80fd\u5c11\u4e8e6\u4f4d\uff01");
		return false;
	}
	if (checkStrLength(passwd) > 14) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u5bc6\u7801\u957f\u5ea6\u4e0d\u80fd\u8d85\u8fc714\u4f4d\uff01");
		return false;
	}
	if (password != passwordre) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u60a8\u4e24\u6b21\u8f93\u5165\u7684\u5bc6\u7801\u4e0d\u4e00\u81f4\uff01");
		return false;
	}
}
function validateModifyForm(form) {
	var oldPasswd = form.oldPasswd.value;
	var newPasswd = form.newPasswd.value;
	var newPasswdre = form.newPasswdre.value;
	var email = form.email.value;
	var passwdQuestion = form.passwdQuestion.value;
	var passwdAnswer = form.passwdAnswer.value;
	if (isEmpty(oldPasswd)) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u65e7\u5bc6\u7801\u4e0d\u53ef\u4e3a\u7a7a");
		return false;
	}
	if (isEmpty(newPasswd)) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u65b0\u5bc6\u7801\u4e0d\u53ef\u4e3a\u7a7a");
		return false;
	}
	if (isEmpty(passwdQuestion)) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u5bc6\u7801\u63d0\u793a\u95ee\u9898\u4e0d\u80fd\u4e3a\u7a7a\uff01");
		return false;
	}
	if (isEmpty(passwdAnswer)) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u5bc6\u7801\u63d0\u793a\u7b54\u6848\u4e0d\u80fd\u4e3a\u7a7a\uff01");
		return false;
	}
	if (checkStrLength(newPasswd) < 6) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u65b0\u5bc6\u7801\u7684\u957f\u5ea6\u4e0d\u53ef\u5c11\u4e8e6\u4e2a\u5b57\u7b26");
		return false;
	}
	if (checkStrLength(newPasswd) > 14) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u65b0\u5bc6\u7801\u7684\u957f\u5ea6\u4e0d\u53ef\u591a\u4e8e14\u4e2a\u5b57\u7b26");
		return false;
	}
	if (newPasswd != newPasswdre) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u60a8\u4e24\u6b21\u8f93\u5165\u7684\u5bc6\u7801\u4e0d\u4e00\u81f4");
		return false;
	}
	if (checkStrLength(passwdAnswer) < 6) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u5bc6\u7801\u63d0\u793a\u7b54\u6848\u4e0d\u80fd\u5c11\u4e8e6\u4f4d\uff01");
		return false;
	}
	if (!isEmail(email)) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u60a8\u8f93\u5165E\u2014mail\u65e0\u6548\uff01");
		return false;
	}
}
function checkGetPasswdForm(form) {
	var userName = form.userName.value;
	var passwdQuestion = form.passwdQuestion.value;
	var passwdAnswer = form.passwdAnswer.value;
	if (/^\s*$/.test(userName)) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u7528\u6237\u540d\u4e0d\u53ef\u4ee5\u4e3a\u7a7a\uff01");
		return false;
	}
	if (/^\s*$/.test(passwdQuestion)) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u5bc6\u7801\u63d0\u793a\u95ee\u9898\u4e0d\u53ef\u4ee5\u4e3a\u7a7a\uff01");
		return false;
	}
	if (/^\s*$/.test(passwdAnswer)) {
		alert("\u5bf9\u4e0d\u8d77\uff0c\u5bc6\u7801\u63d0\u793a\u7b54\u6848\u4e0d\u53ef\u4ee5\u4e3a\u7a7a\uff01");
		return false;
	}
}


