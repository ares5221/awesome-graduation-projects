var xmlHttp;

function createXMLHttpRequest(){
    if(window.XMLHttpRequest){ //Mozilla 浏览器
        xmlHttp = new XMLHttpRequest();
    }else if(window.ActiveXObject) { //IE浏览器
    	try{
        	xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
        }catch(e){
        	try {
            	xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
        	}catch(e){}
        }
    }
    if(xmlHttp == null){
    	alert("不能创建XMLHttpRequest对象");
    	return false;
    }
}
function sendAsynchronRequest(url,parameter,callback){
	createXMLHttpRequest();
	if(parameter == null){
		//步骤3、设置属性onreadystatechange(事件处理器)
		xmlHttp.onreadystatechange = callback;
		//步骤4、调用open()和send()
		xmlHttp.open("GET",url,true);
		//发出一个异步请求（后台发出）
		xmlHttp.send(null);
	}else{
		xmlHttp.onreadystatechange = callback;
		xmlHttp.open("POST",url,true);
		xmlHttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
		//parameter处于请求体中
		xmlHttp.send(parameter);
	}
}
//根据部门查找对应的职位
function select(url){
	//获得要查找的部门对应id
	var deptid = 
		document.getElementById("deptid").value;
	var parameter="deptid="+deptid;
	if(deptid!=0){
		sendAsynchronRequest(url,parameter,selectCallback);
	}
}
function selectCallback(){
		if(xmlHttp.readyState == 4){
		if(xmlHttp.status == 200){
			var xmlDoc = xmlHttp.responseXML;
			var zw = document.getElementById("zw");
			//zwList是个文本
			var zwList = xmlDoc.getElementsByTagName("zwList")[0];
			//获得zwList下面所有的子节点
			var nodes = zwList.childNodes;
			//清空下拉框中所有的内容
			clearSelect();
			for(var i = 0; i < nodes.length; i++){
				//创建元素节点<option>
				var option = document.createElement("option");
				//设置节点属性value
				option.setAttribute("value",nodes[i].firstChild.nodeValue);
				//创建文本节点,用于显示下拉框中职务的名字
				var textNode = document.createTextNode
						(nodes[i].firstChild.nodeValue);
				//往<option>下面添加文本子节点
				option.appendChild(textNode);
				//<city>下面添加子节点<option>
				zw.appendChild(option);
			}
		}else{
			alert("请求的页面有异常");
			return false;
		}
	}
}
//清空下拉框中的内容
function clearSelect(){
	var zw = document.getElementById("zw");
	while(zw.hasChildNodes()){
		zw.removeChild(zw.childNodes[0]);
	}
}
/*是否选中*/
function isChecked(name) {
	var temp = document.getElementsByName(name);
	for (i = 0; i < temp.length; i=i+1) {
		if (temp[i].checked) {
			return true;
		}
	}
}
//计算字符串的长度
function checkStrLength(value) {
	var StrTrueLength = value.replace(/[^\x00-\xff]/g, "~~").length;
	return StrTrueLength;
}
/*判断是否为数字*/
function isNumber(str) {
	var Letters = "1234567890";
	for (var i = 0; i < str.length; i = i + 1) {
		var CheckChar = str.charAt(i);
		if (Letters.indexOf(CheckChar) == -1) {
			return false;
		}
	}
	return true;
}
/*判断是否为Email*/
function isEmail(str) {
	var myReg = /^[-_A-Za-z0-9]+@([_A-Za-z0-9]+\.)+[A-Za-z0-9]{2,3}$/;
	if (myReg.test(str)) {
		return true;
	}
	return false;
}
/*判断是否为空*/
function isEmpty(value) {
	return /^\s*$/.test(value);
}

/*全选、取消全选*/
function checkedAll(allCheckboxName, checkboxName) {
	o = document.getElementsByName(allCheckboxName);
	if (o[0].checked == true) {
		selAllCheckbox(checkboxName);
	} else {
		unselAllCheckbox(checkboxName);
	}
}
/*全选*/
function selAllCheckbox(checkboxName) {
	o = document.getElementsByName(checkboxName);
	for (i = 0; i < o.length; i++) {
		o[i].checked = true;
	}
}
/*取消全选*/
function unselAllCheckbox(checkboxName) {
	o = document.getElementsByName(checkboxName);
	for (i = 0; i < o.length; i++) {
		o[i].checked = false;
	}
}
/*取消全选*/
function reAllCheckbox(checkboxName) {
	o = document.getElementsByName(checkboxName);
	for (i = 0; i < o.length; i++) {
		if (o[i].checked == false) {
			o[i].checked = true;
		} else {
			o[i].checked = false;
		}
	}
}
/*返回check选中数*/
function getCheckedCount(checkboxName) {
	o = document.getElementsByName(checkboxName);
	var c = 0;
	for (i = 0; i < o.length; i++) {
		if (o[i].checked == true) {
			c++;
		}
	}
	return c;
}

/*判断身份证是否正确*/
function JustifyIdCard( theField ) {
	var reg =/(^(\d{15}|\d{17}[\dx])$)/;
	if (reg.test(theField)){
		return true;
	}else{
		return false;
	}
}
/*判断用户名是否正确*/
function JustifyUserName( theField ) {	
	var reg =/^(\w+)|([\u0391-\uFFE5]+)$/;
	if (reg.test(theField)){
		return true;
	}else{
		return false;
	}
}

/*比较两个时间的大小*/
function CompareDate(d1,d2)
{
  return ((new Date(d1.replace(/-/g,"\/"))) > (new Date(d2.replace(/-/g,"\/"))));
}

//根据身份证生成生日
function addBirthday(){
		var str=document.getElementById('idCard').value;//身份证编码 
		var birthday=document.getElementById('birthday');
　　		var len=str.length;//身份证编码长度 
		if (len==18){ 
　　			birthday.value=str.substr(6,4)+'-'+str.substr(10,2)+'-'+str.substr(12,2); 	
　		} 
		if (len==15){ 
　　			birthday.value="19"+str.substr(6,2)+'-'+str.substr(8,2)+'-'+str.substr(10,2); 	
　		} 
	}