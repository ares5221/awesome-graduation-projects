--文件列表：
drop table ly_file;
create table ly_file(
	id number(4) primary key,
	loadfile varchar2(50) not null
);

--员工信息表：
drop table ly_member;
create table ly_member(
	id number(4) primary key,
	accountno varchar2(15),--用户帐号
	password varchar2(50),--用户密码
	type varchar2(1),--用户类型  1表示公司职员  0 表示管理员
	status varchar2(1)--是否注销，默认为0
);


--部门信息表
drop table ly_department;
create table ly_department(
	id number(4) primary key,
	name varchar(15)
);

--职务信息表：
drop table ly_zw;
create table ly_zw(
	id number(4) primary key,
	name varchar(20) not null,
	dept_id number(4) references ly_department(id)
);


--招聘信息表：
drop table ly_recruit;
create table ly_recruit(
	id number(4) primary key,
	content varchar2(200) not null,
	fbdate date
);

--应聘信息表：
drop table ly_yp;
create table ly_yp(
	id number(4) primary key,
	name varchar2(15) not null,
	gender varchar2(1),
	age number(4),
	zw varchar2(25),
	zy varchar2(25),
	jy varchar2(15),
	yx varchar2(30),
	phone varchar2(20),
	email varchar2(20),
	jj varchar2(200)
);

--培训信息表：
drop table ly_train;
create table ly_train(
	id number(4) primary key,
	tname varchar2(30),
	tgoal varchar2(50),
	tjc varchar2(50),
	tmember varchar2(50),
	kdate varchar2(20),
	jdate varchar2(20),
	tnumber number(4),
	teacher varchar2(20),
	jibie varchar2(10),
	yx varchar2(5),
	fbdate date
);

--奖惩信息表：
drop table ly_jc;
create table ly_jc(
	id number(4) primary key,
	name varchar2(30) not null,
	reason varchar2(50),
	member varchar2(50),
	descr varchar2(200),
	fbdate date,
	fbMember varchar2(15)
);

--薪资信息表：
drop table ly_salary;
create table ly_salary(
	id number(4) primary key,
	ebianhao varchar2(15),
	smonth varchar(8),
	jsalary number(6),
	zsalary number(4),
	esalary number(4),
	ssalary number(5),
	qsalary number(3),
	fsalary number(3),
	fbdate date
);


--员工信息表：
drop table ly_employee;
create table ly_employee(
id number(4) primary key,  
name varchar2(20) not null,
pinyin varchar2(20),
gender varchar2(1) not null,
birthspace varchar2(50),
nation varchar2(20),
birthtime varchar2(30),
title varchar2(25),
deptid number(4) references ly_department(id),
zwid number(4) references ly_zw(id),
cellphone varchar2(20),
wphone varchar2(20),
fphone varchar2(20),
email varchar2(20),
zz varchar2(2),
health varchar2(25),
profession varchar2(20),
xl varchar2(15),
marry varchar2(1),
sfz varchar2(18),
address varchar2(50),
bianhao varchar2(15),
icon varchar2(200),
luru_date date,
lastmodifydate date,
luru_adminbianhao varchar2(15),
status varchar(1)  --默认为0，表示在职
);



insert into ly_department values(1,'市场部');
insert into ly_department values(2,'教学管理部');
insert into ly_department values(3,'教研部');
insert into ly_department values(4,'研发部');
insert into ly_department values(5,'Mis部');
insert into ly_department values(6,'就业部');

insert into ly_zw values(1,'s1',1);
insert into ly_zw values(2,'s2',1);
insert into ly_zw values(3,'s3',1);
insert into ly_zw values(4,'s4',1);
insert into ly_zw values(5,'jx1',2);
insert into ly_zw values(6,'jx2',2);
insert into ly_zw values(7,'jx3',2);
insert into ly_zw values(8,'jy1',3);
insert into ly_zw values(9,'jy2',3);
insert into ly_zw values(10,'jy3',3);
insert into ly_zw values(11,'yf1',4);
insert into ly_zw values(12,'yf2',4);
insert into ly_zw values(13,'yf3',4);
insert into ly_zw values(14,'m1',5);
insert into ly_zw values(15,'m2',5);
insert into ly_zw values(16,'m3',5);
insert into ly_zw values(17,'j1',6);
insert into ly_zw values(18,'j2',6);
insert into ly_zw values(19,'j3',6);


commit;