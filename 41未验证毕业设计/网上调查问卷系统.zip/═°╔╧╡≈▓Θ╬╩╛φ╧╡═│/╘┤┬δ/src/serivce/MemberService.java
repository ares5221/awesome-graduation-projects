package serivce;

import dao.MemberDao;
import dao.PaperDaoImpl;
import dao.ProblemDaoImpl;

public class MemberService {
	public boolean register(String username,String password,String email) {
		MemberDao mb = new MemberDao();
		String result = mb.memberexsit(username);
		if(result.equals("true")) {
			mb.save(username, password, email);
			return true; 
		} else {
			return false;
		}
	}
	
	public boolean findmanager(String username,String password) {
		MemberDao mb = new MemberDao();
		String result = mb.findmanager(username, password);
		if(result.equals("true")) {
			return true;
		}else{
			return false;
		}
	}
	
	public void perupdate(int paperid,int proid,String title,String acontent,
			String bcontent,String ccontent,String dcontent) {
			MemberDao pd = new MemberDao();
			pd.upate(paperid, proid, title, acontent, bcontent, ccontent, dcontent);
	}
	
	public void delete(int paperid){
		MemberDao paper = new MemberDao();
		ProblemDaoImpl pd = new ProblemDaoImpl();
		pd.deletemorepro(paperid);
		paper.delete(paperid);
	}
	
	public void deletepercount(String papername) {
		MemberDao md = new MemberDao();
		md.deletepercount(papername);
	}
	
	public boolean findbypaperid(int paperid) {
		MemberDao md = new MemberDao();		
		String result = md.findbypaperid(paperid);
		if(result.equals("true")) {
			return true;
		}else{
			return false;
		}
	}
	
	public void insertperpaper(int id,String filename) {
		MemberDao md = new MemberDao();	
		md.insertperpaper(id, filename);
	}
	
	public void insertperpro(int paperid,int proid,String protitle,
			String acontent,String bcontent,String ccontent,String dcontent){
		MemberDao md = new MemberDao();
		md.insertperpro(paperid, proid, protitle, acontent,
				bcontent, ccontent, dcontent);
	}
	
	public void deleteonepro(int paperid ,int problemid) {
		MemberDao md = new MemberDao();
		md.deleteOnepro(paperid, problemid);
	}
	
	public int findproid(int paperid) {
		MemberDao md = new MemberDao();
		return md.findproid(paperid);
	}
	
	public void updatestatus(String username,String papername) {
		MemberDao md = new MemberDao();
		md.updatestatus(username, papername);
	}
}
