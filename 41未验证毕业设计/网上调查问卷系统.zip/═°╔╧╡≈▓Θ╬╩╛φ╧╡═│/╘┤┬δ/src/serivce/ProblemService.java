package serivce;

import dao.ProblemDaoImpl;

public class ProblemService {
	public void perupdate(int paperid,int proid,String title,String acontent,
					String bcontent,String ccontent,String dcontent) {
		ProblemDaoImpl pd = new ProblemDaoImpl();
		pd.upate(paperid, proid, title, acontent, bcontent, ccontent, dcontent);
	}
	
	public void deleteonepro(int paperid ,int problemid) {
		ProblemDaoImpl pd = new ProblemDaoImpl();
		pd.delete(paperid, problemid);
	}
	
	public int findbypaperid(int paperid) {
		ProblemDaoImpl pd = new ProblemDaoImpl();
		return pd.findbypaperid(paperid);
	}
	
	public void insertpro(int paperid,int pro,String title,String a,String b,
								String c,String d) {
		ProblemDaoImpl pd = new ProblemDaoImpl();
		pd.insertpro(paperid, pro, title, a, b, c, d);
	}
}
