package serivce;



import java.util.ArrayList;

import bean.*;

import dao.MemberDao;
import dao.PaperDao;
import dao.PaperDaoImpl;
import dao.ProblemDaoImpl;

public class PaperService {
	
	public void insertcount(String papername,int acount,int bcount,
			int ccount,int dcount) {
		PaperDao paper = new PaperDaoImpl();
		paper.insertcount(papername, acount, bcount, ccount, dcount);
		}
	
	public boolean findmember(String username,String password) {
		MemberDao mb = new MemberDao();
		String result = mb.findmember(username, password);
		if(result.equals("true")) {
			return true;
		}else{
			return false;
		}
	}
	
	public void insertperpaper(String username,int id,String filename) {
		PaperDaoImpl paper = new PaperDaoImpl();
		paper.insertperpaper(username, id, filename);
	}
	
	public void insertperpro(int paperid,int proid,String protitle,
			String acontent,String bcontent,String ccontent,String dcontent){
		PaperDaoImpl paper = new PaperDaoImpl();
		paper.insertperpro(paperid, proid, protitle, acontent,
				bcontent, ccontent, dcontent);
	}
	
	public boolean findbypaperid(int paperid) {
		PaperDaoImpl paper = new PaperDaoImpl();		
		String result = paper.findbypaperid(paperid);
		if(result.equals("true")) {
			return true;
		}else{
			return false;
		}
	}
	
	public void delete(int paperid){
		PaperDaoImpl paper = new PaperDaoImpl();
		ProblemDaoImpl pd = new ProblemDaoImpl();
		pd.deletemorepro(paperid);
		paper.delete(paperid);
	}
	
	public void perinsertcount(String papername,int acount,int bcount,int ccount,int dcount) {
		MemberDao md = new MemberDao();
		int list[] = new int[4];
		int a=0;
		int b=0;
		int c=0;
		int d=0;
		if(md.findbypapername(papername)) {
			md.insertpercount(papername, acount+0, bcount+0, ccount+0, dcount+0);
		}else{
			list = md.findcountbypapername(papername);
			a = list[0] + acount;
			b = list[1] + bcount;
			c = list[2] + ccount;
			d = list[3] + dcount;
			md.updatecount(papername, a, b, c, d);
			
		}
	}
	
	public void deletepercount(String papername) {
		MemberDao md = new MemberDao();
		md.deletepercount(papername);
	}
	
	public PerPaper findperpaper(int paperid) {	
		PaperDao pd = new PaperDaoImpl();
		return pd.Singlename(paperid);		
	}
	
	public void relinsert(String username,int paperid,String papername,int status) {
		PaperDaoImpl pd = new PaperDaoImpl();
		pd.relinsert(username, paperid, papername, status);
	}
}
