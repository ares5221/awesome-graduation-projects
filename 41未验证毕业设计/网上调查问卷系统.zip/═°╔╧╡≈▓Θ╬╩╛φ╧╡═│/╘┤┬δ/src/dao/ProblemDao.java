package dao;

import java.util.Map;

import bean.Problem;

public interface ProblemDao {
	
	public Map promap(int paperid);
	public Problem singlepro(int proid);
	public void insertPro(Problem pro);
	public void deletePro(int proid);
	public void update(int proid,Problem pro);
	
}
