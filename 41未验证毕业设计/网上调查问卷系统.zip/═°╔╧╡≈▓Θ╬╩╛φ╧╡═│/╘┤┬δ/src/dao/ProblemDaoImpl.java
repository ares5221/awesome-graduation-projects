package dao;

import java.sql.*;

import common.ConnectionFactory;

public class ProblemDaoImpl {
	public void upate(int paperid,int proid,String title,String acontent,
						String bcontent,String ccontent,String dcontent) {
	
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "update perquestionpro set title=?,a=?,b=?,c=?,d=? where paper_id=? and problem_id=?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, title);
			stmt.setString(2, acontent);
			stmt.setString(3, bcontent);
			stmt.setString(4, ccontent);
			stmt.setString(5, dcontent);
			stmt.setInt(6, paperid);
			stmt.setInt(7, proid);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void delete(int paperid,int problemid) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "delete from perquestionpro where paper_id=? and problem_id=?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, paperid);
			stmt.setInt(2, problemid);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public int findbypaperid(int paperid) {
		int id =0;
		Connection conn = ConnectionFactory.getConnection();
		Statement stmt = null;
		ResultSet rs  = null;
		String sql = "select * from perquestionpro where paper_id ="+paperid;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				id = rs.getInt("problem_id");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return id;
	}
	
	public void insertpro(int paperid,int proid,String title,String acontent,
							String bcontent,String ccontent,String dcontent){
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "insert into perquestionpro values(?,?,?,?,?,?,?)";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, paperid);
			stmt.setInt(2, proid);
			stmt.setString(3, title);
			stmt.setString(4, acontent);
			stmt.setString(5, bcontent);
			stmt.setString(6, ccontent);
			stmt.setString(7, dcontent);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void deletemorepro(int paperid) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "delete from perquestionpro where paper_id=? ";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, paperid);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
