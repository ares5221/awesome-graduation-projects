package dao;

import java.util.*;

import bean.*;

public interface PaperDao {
	
	public List papername() ;
	public PerPaper Singlename(int id);
	public int paperid(String name);
	public void insertcount(String papername,int acount,int bcount,int ccount,int dcount);
}
