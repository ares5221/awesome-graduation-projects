package dao;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

import bean.Paper;
import bean.PerPaper;

import common.ConnectionFactory;

public class PaperDaoImpl implements PaperDao{
	public static LinkedList<Paper> list = new LinkedList<Paper>();
	public PerPaper Singlename(int id) {
		PerPaper pa = null;
		Connection conn = ConnectionFactory.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select * from perquestionpaper where id="+id;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				pa = new PerPaper();
				pa.setUsername(rs.getString("username"));
				pa.setPapername(rs.getString("filename"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			ConnectionFactory.close(conn, stmt, rs);
		}
		return pa;
	}

	public int paperid(String name) {
		// TODO Auto-generated method stub
		return 0;
	}

	public List papername() {
		// TODO Auto-generated method stub
		return null;
	}

	public void insertcount(String papername, int acount, int bcount,
			int ccount, int dcount) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "update test_count set acount="+acount+
						",bcount="+bcount+",ccount="+ccount+",dcount="+dcount+ 
						"where papername = 'university'";	
		try {
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectionFactory.close(conn, stmt, rs);
		}
		
	}
	
	
	
	public void insertperpaper(String username,int id,String papername) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "insert into perquestionpaper values(?,?,?)";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, username);
			stmt.setInt(2, id);
			stmt.setString(3, papername);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
	public void insertperpro(int paperid,int proid,String proname,
			String acontent,String bcontent,String ccontent,String dcontent) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "insert into perquestionpro values(?,?,?,?,?,?,?)";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, paperid);
			stmt.setInt(2, proid);
			stmt.setString(3, proname);
			stmt.setString(4, acontent);
			stmt.setString(5, bcontent);
			stmt.setString(6, ccontent);
			stmt.setString(7, dcontent);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public String  findbypaperid(int paperid) {
		Connection conn = ConnectionFactory.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select id from perquestionpaper where id ="+paperid;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next()) {
				return "false";
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "true";
	}
	
	public void delete(int paperid) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "delete from perquestionpaper where id=? ";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, paperid);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void relinsert(String username,int paperid,String papername,int status) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "insert into release values(?,?,?,?)";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, username);
			stmt.setInt(2, paperid);
			stmt.setString(3, papername);
			stmt.setInt(4, status);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	

	
//	public List find() {
//		Paper paper = null;
//		Connection conn = ConnectionFactory.getConnection();
//		Statement stmt = null;
//		ResultSet rs = null;
//		String sql = "select * from test_paper_tbl";	
//		try {
//			stmt = conn.createStatement();
//			rs = stmt.executeQuery(sql);
//			while(rs.next()) {
//				paper = new Paper();
//				paper.setId(rs.getInt("id"));
//				paper.setPname(rs.getString("filename"));
//				list.add(paper);
//			}
//			
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}finally{
//			ConnectionFactory.close(conn, stmt, rs);
//		}
//		return list;
//	}
//	
//	public static void main(String args[]){
//		PaperDaoImpl pa = new PaperDaoImpl();
//		System.out.println(pa.find().size());
//		while(list.size()-1 > 0){
//			System.out.println(list.getFirst().getId());
//		}
		
//	}

}
