package dao;

import java.sql.*;
import java.util.*;

import common.ConnectionFactory;

public class MemberDao {
	private String passdata ;
	
	
    
	public void save(String username,String password,String email) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "insert into user_table values(?,?,?)";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, username);
			stmt.setString(2, email);
			stmt.setString(3, password);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public String findmember(String username,String password) {	
		Connection conn = ConnectionFactory.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select * from user_table where username='"+username+"'";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next()) {
				passdata = rs.getString("password");
				if(password.equals(passdata)) {
					return "true";
				} else {
					return "false";
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			ConnectionFactory.close(conn, stmt, rs);
		}
		return "false";	
	}
	
	
	public String memberexsit(String username) {	
		Connection conn = ConnectionFactory.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select * from user_table where username='"+username+"'";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next()) {	
					return "false";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			ConnectionFactory.close(conn, stmt, rs);
		}
		return "true";	
	}
	
	public int[] findcountbypapername(String papername) {
		int a[] = new int[4];
		Connection conn = ConnectionFactory.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select * from per_count where papername ='"+papername+"'";	
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				a[0] = (rs.getInt("acount"));
				a[1] = (rs.getInt("bcount"));
				a[2] = (rs.getInt("ccount"));
				a[3] = (rs.getInt("dcount"));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectionFactory.close(conn, stmt, rs);
		}
		return a;
		
	}
	
	public void updatecount(String papername,int acount,int bcount,int ccount,int dcount) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql ="update per_count set acount=?,bcount=?,ccount=?,dcount=? where papername=?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, acount);
			stmt.setInt(2, bcount);
			stmt.setInt(3, ccount);
			stmt.setInt(4, dcount);
			stmt.setString(5, papername);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			ConnectionFactory.close(conn, stmt, rs);
		}
	}
	
	
	
	public void insertpercount(String papername, int acount, int bcount,
			int ccount, int dcount) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "insert into per_count values(?,?,?,?,?)";	
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, papername);
			stmt.setInt(2, acount);
			stmt.setInt(3, bcount);
			stmt.setInt(4, ccount);
			stmt.setInt(5, dcount);
			stmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectionFactory.close(conn, stmt, rs);
		}
		
	}
	
	public void deletepercount(String papername) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "delete from per_count where papername=?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, papername);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			ConnectionFactory.close(conn, stmt, rs);
		}
		
	}
	
	public boolean findbypapername(String papername) {
		Connection conn = ConnectionFactory.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select * from per_count where papername='"+papername+"'";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next()){
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ConnectionFactory.close(conn, stmt, rs);
		}
		return true;
	}
	
	public String findmanager(String username,String password) {	
		Connection conn = ConnectionFactory.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select * from manager_table where username='"+username+"'";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next()) {
				passdata = rs.getString("password");
				if(password.equals(passdata)) {
					return "true";
				} else {
					return "false";
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			ConnectionFactory.close(conn, stmt, rs);
		}
		return "false";	
	}
	
	public void upate(int paperid,int proid,String title,String acontent,
			String bcontent,String ccontent,String dcontent) {

			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement stmt = null;
			ResultSet rs = null;
			String sql = "update test_problem set title=?,a=?,b=?,c=?,d=? where paperc_id=? and problemc_id=?";
			try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, title);
			stmt.setString(2, acontent);
			stmt.setString(3, bcontent);
			stmt.setString(4, ccontent);
			stmt.setString(5, dcontent);
			stmt.setInt(6, paperid);
			stmt.setInt(7, proid);
			stmt.execute();
			} catch (Exception e) {
				e.printStackTrace();
			}finally {
				try {
					ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
}
	
	public void delete(int paperid) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "delete from test_paper_tbl where id=? ";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, paperid);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public String  findbypaperid(int paperid) {
		Connection conn = ConnectionFactory.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select id from test_paper_tbl where id ="+paperid;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next()) {
				return "false";
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "true";
	}
	
	public void insertperpaper(int id,String papername) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "insert into test_paper_tbl values(?,?)";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, id);
			stmt.setString(2, papername);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
	public void insertperpro(int paperid,int proid,String proname,
			String acontent,String bcontent,String ccontent,String dcontent) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "insert into test_problem values(?,?,?,?,?,?,?)";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, paperid);
			stmt.setInt(2, proid);
			stmt.setString(3, acontent);
			stmt.setString(4, bcontent);
			stmt.setString(5, ccontent);
			stmt.setString(6, dcontent);
			stmt.setString(7, proname);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void deleteOnepro(int paperid,int problemid) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "delete from test_problem where paperc_id=? and problemc_id=?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, paperid);
			stmt.setInt(2, problemid);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public int findproid(int paperid) {
		int id =0;
		Connection conn = ConnectionFactory.getConnection();
		Statement stmt = null;
		ResultSet rs  = null;
		String sql = "select * from test_problem where paperc_id ="+paperid;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				id = rs.getInt("problemc_id");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return id;
	}
	
	public void updatestatus(String username,String papername) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs  = null;
		String sql="update release set status=? where username=? and papername=?";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, 1);
			stmt.setString(2, username);
			stmt.setString(3, papername);
			stmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public int findstatus (int  paperid) {
		int status=0;
		Connection conn = ConnectionFactory.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select status from release where paperid="+paperid;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				status = rs.getInt("status");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				ConnectionFactory.close(conn, stmt, rs);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return status;
		
	}
	
	public boolean findpaperid(int paperid) {
		Connection conn = ConnectionFactory.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select paperid from release where paperid = "+paperid;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next()) {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			ConnectionFactory.close(conn, stmt, rs);
		}
		
		return true;
	}
//	public static void main(String args[]){
//		MemberDao md = new MemberDao();
//		System.out.println(md.findmember("wy", 11));
//		//md.findmember("wy", 111);
//	}
}
