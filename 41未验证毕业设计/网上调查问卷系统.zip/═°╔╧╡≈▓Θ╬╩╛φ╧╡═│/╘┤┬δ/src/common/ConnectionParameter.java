package common;

public interface ConnectionParameter {
	public static final String	URL = 
		"jdbc:oracle:thin:@127.0.0.1:1521:XE";
	public static final String DRIVER = 
		"oracle.jdbc.driver.OracleDriver";
	public static final String USER_NAME = "wy";
	public static final String PASSWORD = "156248793";
}
