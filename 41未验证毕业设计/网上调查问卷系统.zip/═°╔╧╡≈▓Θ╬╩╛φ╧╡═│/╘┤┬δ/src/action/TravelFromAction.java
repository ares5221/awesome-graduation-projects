package action;
import serivce.PaperService;

import com.opensymphony.xwork2.ActionSupport;

public class TravelFromAction extends ActionSupport {
	private int acount;
	private int bcount;
	private int ccount;
	private int dcount;
	private int paperid;
	private String string;
	private String papername;
	
	
	public String getPapername() {
		return papername;
	}
	public void setPapername(String papername) {
		this.papername = papername;
	}
	public int getPaperid() {
		return paperid;
	}
	public void setPaperid(int paperid) {
		this.paperid = paperid;
	}
	public String getString() {
		return string;
	}
	public void setString(String string) {
		this.string = string;
	}
	
	public String travelform() {
		System.out.println(string);
		String str[] = new String[]{};
		str = string.split(":");
		String st[] = new String[]{};
		System.out.println(str.length);
		st = str[1].split("\\|");
		String fn[] = new String[]{};
		for(int i =0;i<st.length;i++) {
			fn =st[i].split("#");
			if(fn[1].equals("1_1.00")){
				acount++;
				continue;
			}
			if(fn[1].equals("2_2.00")){
				bcount++;
				continue;
			}
			if(fn[1].equals("3_3.00")){
				ccount++;
				continue;
			}
			if(fn[1].equals("4_4.00")){
				dcount++;
				continue;
			}
		}

		PaperService ps = new PaperService();	
		ps.perinsertcount(papername, acount, bcount, ccount, dcount);
		return SUCCESS;
	}
	
}
