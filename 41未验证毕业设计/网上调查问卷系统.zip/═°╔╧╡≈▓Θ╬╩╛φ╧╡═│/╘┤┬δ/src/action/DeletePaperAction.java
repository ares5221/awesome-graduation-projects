package action;

import serivce.PaperService;

import com.opensymphony.xwork2.ActionSupport;

public class DeletePaperAction extends ActionSupport{
	private int paperid;
	private String papername;
	

	public String getPapername() {
		return papername;
	}

	public void setPapername(String papername) {
		this.papername = papername;
	}

	public int getPaperid() {
		return paperid;
	}

	public void setPaperid(int paperid) {
		this.paperid = paperid;
	}
	
	public String deletepaper() {
		PaperService ps = new PaperService();
		ps.delete(paperid);
		ps.deletepercount(papername);
		
		return SUCCESS;
	}
}
