package action;

import java.util.LinkedList;

import serivce.ProblemService;

import com.opensymphony.xwork2.ActionSupport;

public class CreateProAction extends ActionSupport {
	private int paperid;
	private String inputpapertitle;
	private String acontent;
	private String bcontent;
	private String ccontent;
	private String dcontent;
	
	public int getPaperid() {
		return paperid;
	}
	public void setPaperid(int paperid) {
		this.paperid = paperid;
	}
	public String getInputpapertitle() {
		return inputpapertitle;
	}
	public void setInputpapertitle(String inputpapertitle) {
		this.inputpapertitle = inputpapertitle;
	}
	public String getAcontent() {
		return acontent;
	}
	public void setAcontent(String acontent) {
		this.acontent = acontent;
	}
	public String getBcontent() {
		return bcontent;
	}
	public void setBcontent(String bcontent) {
		this.bcontent = bcontent;
	}
	public String getCcontent() {
		return ccontent;
	}
	public void setCcontent(String ccontent) {
		this.ccontent = ccontent;
	}
	public String getDcontent() {
		return dcontent;
	}
	public void setDcontent(String dcontent) {
		this.dcontent = dcontent;
	}
	
	public String createpro() {

		ProblemService ps = new ProblemService();
		int proid = ps.findbypaperid(paperid);
		int problemid = ++proid;
		ps.insertpro(paperid, problemid, inputpapertitle, acontent, bcontent, ccontent, dcontent);
		return SUCCESS;
	}
	
}
