package action;

import serivce.ProblemService;

import com.opensymphony.xwork2.ActionSupport;

public class DeleteOneProAction extends ActionSupport {
	
	private int problemid;
	private int paperid;
	
	public int getProblemid() {
		return problemid;
	}
	public void setProblemid(int problemid) {
		this.problemid = problemid;
	}
	public int getPaperid() {
		return paperid;
	}
	public void setPaperid(int paperid) {
		this.paperid = paperid;
	}
	
	public String deletepro() {
		ProblemService ps = new ProblemService();
		ps.deleteonepro(paperid, problemid);
		return SUCCESS;
	}
	
}
