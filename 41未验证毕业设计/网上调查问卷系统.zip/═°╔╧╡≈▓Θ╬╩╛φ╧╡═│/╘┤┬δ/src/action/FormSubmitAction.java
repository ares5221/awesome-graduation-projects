package action;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import serivce.PaperService;

import com.opensymphony.xwork2.ActionSupport;

public class FormSubmitAction extends ActionSupport{
	
	
	private int acount;
	private int bcount;
	private int ccount;
	private int dcount;
	private String ctl00$MainContent$F1536197;
	private String ctl00$MainContent$F1536198;
	private String ctl00$MainContent$F1536199;
	private String ctl00$MainContent$F1536200;
	private String ctl00$MainContent$F1536201;
	private String ctl00$MainContent$F1536202;
	private String ctl00$MainContent$F1536203;
	private String ctl00$MainContent$F1536204;
	private String ctl00$MainContent$F1536205;
	private String ctl00$MainContent$F1536206;
	
	public String getCtl00$MainContent$F1536197() {
		return ctl00$MainContent$F1536197;
	}
	public void setCtl00$MainContent$F1536197(String ctl00$MainContent$F1536197) {
		this.ctl00$MainContent$F1536197 = ctl00$MainContent$F1536197;
	}
	public String getCtl00$MainContent$F1536198() {
		return ctl00$MainContent$F1536198;
	}
	public void setCtl00$MainContent$F1536198(String ctl00$MainContent$F1536198) {
		this.ctl00$MainContent$F1536198 = ctl00$MainContent$F1536198;
	}
	public String getCtl00$MainContent$F1536199() {
		return ctl00$MainContent$F1536199;
	}
	public void setCtl00$MainContent$F1536199(String ctl00$MainContent$F1536199) {
		this.ctl00$MainContent$F1536199 = ctl00$MainContent$F1536199;
	}
	public String getCtl00$MainContent$F1536200() {
		return ctl00$MainContent$F1536200;
	}
	public void setCtl00$MainContent$F1536200(String ctl00$MainContent$F1536200) {
		this.ctl00$MainContent$F1536200 = ctl00$MainContent$F1536200;
	}
	public String getCtl00$MainContent$F1536201() {
		return ctl00$MainContent$F1536201;
	}
	public void setCtl00$MainContent$F1536201(String ctl00$MainContent$F1536201) {
		this.ctl00$MainContent$F1536201 = ctl00$MainContent$F1536201;
	}
	public String getCtl00$MainContent$F1536202() {
		return ctl00$MainContent$F1536202;
	}
	public void setCtl00$MainContent$F1536202(String ctl00$MainContent$F1536202) {
		this.ctl00$MainContent$F1536202 = ctl00$MainContent$F1536202;
	}
	public String getCtl00$MainContent$F1536203() {
		return ctl00$MainContent$F1536203;
	}
	public void setCtl00$MainContent$F1536203(String ctl00$MainContent$F1536203) {
		this.ctl00$MainContent$F1536203 = ctl00$MainContent$F1536203;
	}
	public String getCtl00$MainContent$F1536204() {
		return ctl00$MainContent$F1536204;
	}
	public void setCtl00$MainContent$F1536204(String ctl00$MainContent$F1536204) {
		this.ctl00$MainContent$F1536204 = ctl00$MainContent$F1536204;
	}
	public String getCtl00$MainContent$F1536205() {
		return ctl00$MainContent$F1536205;
	}
	public void setCtl00$MainContent$F1536205(String ctl00$MainContent$F1536205) {
		this.ctl00$MainContent$F1536205 = ctl00$MainContent$F1536205;
	}
	public String getCtl00$MainContent$F1536206() {
		return ctl00$MainContent$F1536206;
	}
	public void setCtl00$MainContent$F1536206(String ctl00$MainContent$F1536206) {
		this.ctl00$MainContent$F1536206 = ctl00$MainContent$F1536206;
	}
	
	public String execute() {
		List resultlist = new LinkedList();
		resultlist.add(ctl00$MainContent$F1536197);
		resultlist.add(ctl00$MainContent$F1536198);
		resultlist.add(ctl00$MainContent$F1536199);
		resultlist.add(ctl00$MainContent$F1536200);
		resultlist.add(ctl00$MainContent$F1536201);
		resultlist.add(ctl00$MainContent$F1536202);
		resultlist.add(ctl00$MainContent$F1536203);
		resultlist.add(ctl00$MainContent$F1536204);
		resultlist.add(ctl00$MainContent$F1536205);
		resultlist.add(ctl00$MainContent$F1536206);
		ListIterator iterator = resultlist.listIterator();
		while(iterator.hasNext()) {
			
			String it = (String) iterator.next();
			System.out.println(it);
			if(it.equals("1_1.00")) {
				acount++;
				continue;
			}
			if(it.equals("2_2.00")) {
				bcount++;
				continue;
			}
			if(it.equals("3_3.00")) {
				ccount++;
				continue;
			}
			if(it.equals("4_4.00")) {
				dcount++;
				continue;
			}
		}
		
		PaperService papers = new PaperService();
		papers.insertcount("university",acount,bcount,ccount,dcount);
		return SUCCESS;
	}
	
}
