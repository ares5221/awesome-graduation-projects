package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import serivce.PaperService;

import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport{
	
	private String user;
	private String pass;	
	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String logincheck() {
		PaperService ps = new PaperService();
		System.out.println(user);
		System.out.println(pass);
		boolean result = ps.findmember(user, pass);
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		if(result) {
			session.setAttribute("username", user);
			return SUCCESS;
		}else{
			return ERROR;
		}
	}
	
}
