package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.MemberDao;

import bean.PerPaper;

import serivce.PaperService;

public class Release extends HttpServlet {


	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/xml");
		
		PrintWriter out = response.getWriter();
		int pid= Integer.parseInt(request.getParameter("pid"));
		System.out.println("pid"+pid);
		PerPaper per = new PerPaper();
		PaperService ps = new PaperService();
		MemberDao md = new MemberDao();
		per = ps.findperpaper(pid);
		String username = per.getUsername();
		String papername = per.getPapername();
		int status = 0;
		//System.out.println(md.findstatus(pid));
		StringBuilder result = new StringBuilder();
		result.append("<?xml version='1.0' encoding='utf-8'?>");
		result.append("<root>");	
		if(md.findstatus(pid) == 0 && md.findpaperid(pid)) {
			ps.relinsert(username, pid, papername, status);					
			result.append("<ok>");
			result.append("ok��");
			result.append("</ok>");					
		} 
		
		if(md.findstatus(pid) == 1) {						
			result.append("<no>");
			result.append("no��");
			result.append("</no>");						
		}	
		result.append("</root>");
		out.println(result);
		out.close();
		
	

		
	
		
		
	
	}



}
