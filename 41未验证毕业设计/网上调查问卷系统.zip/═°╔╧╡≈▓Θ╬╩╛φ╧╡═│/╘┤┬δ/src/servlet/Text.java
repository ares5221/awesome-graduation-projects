package servlet;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import common.ConnectionFactory;

import bean.ManagerQS;

public class Text {
	public LinkedList wy() {		
		int count =0;
		int paperid=0;
			Statement stmt=null;
		ResultSet rs=null;
		ManagerQS mqs = null;
		ManagerQS mqs1 = null;
		//String username = (String)session.getAttribute("managername");
		//String username = request.getParameter("username");
			Connection conn = ConnectionFactory.getConnection();
			LinkedList<ManagerQS> list = new LinkedList<ManagerQS>();
			LinkedList<ManagerQS> list1 = new LinkedList<ManagerQS>();
			String sql = "select * from perquestionpaper  ";
			String sql1 ="select * from release";
			
				try{
				 stmt= conn.createStatement();
				 rs = stmt.executeQuery(sql);
				while(rs.next()) {
					mqs = new ManagerQS();
					mqs.setUsername(rs.getString("username")) ;
					mqs.setPapername(rs.getString("filename"));
					list.add(mqs);			
				}
				
				stmt= conn.createStatement();
				 rs = stmt.executeQuery(sql1);
				 while(rs.next()) {
				 	mqs1 = new ManagerQS();
				 	mqs1.setPapername(rs.getString("papername"));
				 	mqs1.setStatus(rs.getInt("status"));
				 	list1.add(mqs1);
				 }
				 
				 for(int i =0;i<list.size();i++) {
				 	for(int j=0;j<list1.size();j++){
				 		if(list1.get(j).getPapername().equals(list.get(i).getPapername())) {
				 			list.get(i).setStatus(list1.get(j).getStatus()) ;
				 		}
				 	}
				 }
				
			}catch(Exception e) {
				e.printStackTrace();
			}finally{
				try{
				ConnectionFactory.close(conn,stmt,rs);
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			return list;
	
	}
	
	public static void main(String args[]) {
		Text t = new Text();
		LinkedList a = new LinkedList();
		a = t.wy();
		System.out.println("a----"+a.size());
		ListIterator<ManagerQS> list = a.listIterator();
		
		while(list.hasNext()) {
	//		System.out.println(list.next().getPapername());
//			System.out.println(list.next().getUsername());
			System.out.println(list.next().getStatus());
			
		}
	}

	
}
		

