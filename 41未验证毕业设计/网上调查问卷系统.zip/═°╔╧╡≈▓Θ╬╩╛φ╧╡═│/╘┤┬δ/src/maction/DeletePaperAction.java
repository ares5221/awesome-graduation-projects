package maction;

import com.opensymphony.xwork2.ActionSupport;

import serivce.MemberService;
import serivce.PaperService;

public class DeletePaperAction extends ActionSupport{
	private int paperid;
	private String papername;
	

	public String getPapername() {
		return papername;
	}

	public void setPapername(String papername) {
		this.papername = papername;
	}

	public int getPaperid() {
		return paperid;
	}

	public void setPaperid(int paperid) {
		this.paperid = paperid;
	}
	
	public String deletepaper() {
		MemberService ps = new MemberService();
		ps.delete(paperid);
		ps.deletepercount(papername);
		
		return SUCCESS;
	}
}
