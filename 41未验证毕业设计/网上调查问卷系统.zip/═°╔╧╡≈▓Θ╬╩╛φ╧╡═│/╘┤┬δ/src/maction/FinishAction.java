package maction;

import com.opensymphony.xwork2.ActionSupport;

import serivce.MemberService;
import serivce.PaperService;

public class FinishAction extends ActionSupport{
	private String username;
	private String paperid;
	private String inputpapername;
	private String inputproid;
	private String inputprotitle;
	private String acontent;
	private String bcontent;
	private String ccontent;
	private String dcontent;
	
	public String getPaperid() {
		return paperid;
	}
	public void setPaperid(String paperid) {
		this.paperid = paperid;
	}
	public String getInputpapername() {
		return inputpapername;
	}
	public void setInputpapername(String inputpapername) {
		this.inputpapername = inputpapername;
	}
	public String getInputproid() {
		return inputproid;
	}
	public void setInputproid(String inputproid) {
		this.inputproid = inputproid;
	}
	public String getInputprotitle() {
		return inputprotitle;
	}
	public void setInputprotitle(String inputprotitle) {
		this.inputprotitle = inputprotitle;
	}
	public String getAcontent() {
		return acontent;
	}
	public void setAcontent(String acontent) {
		this.acontent = acontent;
	}
	public String getBcontent() {
		return bcontent;
	}
	public void setBcontent(String bcontent) {
		this.bcontent = bcontent;
	}
	public String getCcontent() {
		return ccontent;
	}
	public void setCcontent(String ccontent) {
		this.ccontent = ccontent;
	}
	public String getDcontent() {
		return dcontent;
	}
	public void setDcontent(String dcontent) {
		this.dcontent = dcontent;
	}
	
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String finish() {
		MemberService ps = new MemberService();
		if(ps.findbypaperid(Integer.parseInt(paperid))) {
			ps.insertperpaper(Integer.parseInt(paperid), inputpapername);
			ps.insertperpro(Integer.parseInt(paperid), Integer.parseInt(inputproid),
				inputprotitle, acontent, bcontent, ccontent, dcontent);
		}else{
			ps.insertperpro(Integer.parseInt(paperid), Integer.parseInt(inputproid),
					inputprotitle, acontent, bcontent, ccontent, dcontent);
		}
		
		return SUCCESS;
	}
}
