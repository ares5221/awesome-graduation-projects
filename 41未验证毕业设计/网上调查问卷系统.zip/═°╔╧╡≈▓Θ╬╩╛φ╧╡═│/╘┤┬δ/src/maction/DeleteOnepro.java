package maction;

import serivce.MemberService;


import com.opensymphony.xwork2.ActionSupport;

public class DeleteOnepro extends ActionSupport {
	private int problemid;
	private int paperid;
	
	public int getProblemid() {
		return problemid;
	}
	public void setProblemid(int problemid) {
		this.problemid = problemid;
	}
	public int getPaperid() {
		return paperid;
	}
	public void setPaperid(int paperid) {
		this.paperid = paperid;
	}
	
	public String deletepro() {
		MemberService ms = new MemberService();
		ms.deleteonepro(paperid, problemid);
		return SUCCESS;
	}
}	
