package maction;

import serivce.MemberService;

import com.opensymphony.xwork2.ActionSupport;

public class UpdateStatusAction extends ActionSupport{
	private String username;
	private String papername;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPapername() {
		return papername;
	}
	public void setPapername(String papername) {
		this.papername = papername;
	}
	
	public String updatestatus() {
		MemberService ms = new MemberService();
		ms.updatestatus(username, papername);
		return SUCCESS;
	}
	
}
