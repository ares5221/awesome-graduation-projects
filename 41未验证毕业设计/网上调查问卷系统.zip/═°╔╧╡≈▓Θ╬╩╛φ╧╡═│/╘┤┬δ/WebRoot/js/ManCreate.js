function checkform1() {
	if (document.getElementById('inputproid').value == '') {
		alert('题目序号不能为空');
		return false;
	}
	
	var value=document.getElementById('inputproid').value;
	
	
	if(!forcheck(value)) {
		alert('题目序号不为整数');
		return false;
	}
	
	if (document.getElementById('inputprotitle').value == '') {
		alert('题目标题不能为空');
		return false;
	}
	
	if (document.getElementById('acontent').value == '') {
		alert('A选项内容不能为空');
		return false;
	}
	
	if (document.getElementById('bcontent').value == '') {
		alert('B选项内容不能为空');
		return false;
	}
	
	if (document.getElementById('ccontent').value == '') {
		alert('C选项内容不能为空');
		return false;
	}
	
	if (document.getElementById('dcontent').value == '') {
		alert('D选项内容不能为空');
		return false;
	}
	
	
	return true;
	
}

function forcheck(ss){  
	 var   type="^[0-9]*[1-9][0-9]*$";  
	        var   re   =   new   RegExp(type);  
	       if(ss.match(re)==null)  
	        {  
	         
	        return false;  
	        } 
	       return true;
	} 
function insert() {
	if(checkform1()){
	perquescre.action = "manager/insertdata.action";
	perquescre.submit();
	}
}

function finish() {
	if(checkform1()) {
	perquescre.action="manager/finish.action";
	perquescre.submit();
	}
}