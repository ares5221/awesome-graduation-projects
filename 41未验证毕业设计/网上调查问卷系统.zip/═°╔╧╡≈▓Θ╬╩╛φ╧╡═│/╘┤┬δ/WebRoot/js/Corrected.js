/*<form name="login" id="login" method="POST" action="URL" onsubmit="return checkform();">
用户名：<input type="text" id="username" name="username" />
密  码:<input type="password" id="password" name="password" />
重新输入密码:<input type="password" id="passworda" name="password" />
E-mail:<input type="text" id="email" name="email" />
<input type="submit" value="登陆"/>
<form/>*/
//<script type="text/javascript">

var list = new Array();

function checkform() {
	if (document.getElementById('username').value == '') {
		alert('用户名不能为空！');
		return false;
	}

	if (document.getElementById('password').value == '') {
		alert('密码不能为空！');
		return false;
	}
	if (document.getElementById('password').value.length <= 6) {
		alert("密码不能小于六位，请重新输入！");
		return false;
	}
	if (document.getElementById('passecond').value != document
			.getElementById('password').value) {
		alert("两次输入密码不一致，请检查");
		return false;
	}
	if (document.getElementById('email').value == '') {
		alert('邮箱不能为空！');
		return false;
	}
	var reg = /^([a-zA-Z0-9]+[_|\-|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\-|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/gi;
	if (!reg.test(document.getElementById('email').value)) {
		alert('邮箱格式不正确！');
		return false;
	}
	

}

function checkform1() {
	if (document.getElementById('inputproid').value == '') {
		alert('题目序号不能为空！');
		return false;
	}
	
	var value= document.getElementById('inputproid').value ;
	if(!forcheck(value)) {
		alert('题目序号不为整数');
		return false;
	}
	
	if (document.getElementById('inputprotitle').value == '') {
		alert('题目内容不能为空！');
		return false;
	}
	
	if (document.getElementById('acontent').value == '') {
		alert('A选项内容不能为空！');
		return false;
	}
	
	if (document.getElementById('bcontent').value == '') {
		alert('B选项内容不能为空！');
		return false;
	}
	
	if (document.getElementById('ccontent').value == '') {
		alert('C选项内容不能为空！');
		return false;
	}
	
	if (document.getElementById('dcontent').value == '') {
		alert('D选项内容不能为空！');
		return false;
	}
	
	
	return true;
	
}

function forcheck(ss){  
	 var   type="^[0-9]*[1-9][0-9]*$";  
	        var   re   =   new   RegExp(type);  
	       if(ss.match(re)==null)  
	        {  
	         
	        return false;  
	        } 
	       return true;
	} 

function insert() {
	if(checkform1()){
	perquescre.action = "web/insertdata.action";
	perquescre.submit();
	}
}

function finish() {
	if(checkform1()) {
	perquescre.action="web/finish.action";
	perquescre.submit();
	}
}

function takeresult() {
	var result = null;
	var string = null;
	var length;
	var i=0;
	var n =0;
	var paperid = document.getElementById("paperid").value;
	
	while(true) {
		++i;
		var chkObjs = document.getElementsByName("optioncontent"+i);
		length = chkObjs.length;
		if(length == 0){
			break;
		}else{
			for(var j=0;j < chkObjs.length;j++){
				if(chkObjs[j].checked) {
					var value = chkObjs[j].value;
					list[i-1] = value;
					length--;
				}
			}
		}
	}
	

	for(var m =0;m<list.length;m++){
		n++; 
	   string = string + n+"#"+list[m]+"|";
	}
	//alert(paperid+':'+string);
	result = paperid +":"+string;
	document.getElementById("string").value = result;
//	return (paperid +":"+string) ;
	
	
}




// </script>
