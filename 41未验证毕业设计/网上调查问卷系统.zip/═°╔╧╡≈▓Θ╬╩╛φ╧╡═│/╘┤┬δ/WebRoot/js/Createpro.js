function checkform() {
	if (document.getElementById('inputpapertitle').value == '') {
		alert('题目内容不能为空！');
		return false;
	}
	
	if (document.getElementById('acontent').value == '') {
		alert('A选项内容不能为空！');
		return false;
	}
	
	if (document.getElementById('bcontent').value == '') {
		alert('B选项内容不能为空！');
		return false;
	}
	
	if (document.getElementById('ccontent').value == '') {
		alert('C选项内容不能为空！');
		return false;
	}
	
	if (document.getElementById('dcontent').value == '') {
		alert('D选项内容不能为空！');
		return false;
	}
}

function submit() {
	managerlogin.action="manager/login.action";
	managerlogin.submit();
	
}

function Release(){
	
	var parameter ="pid="+document.getElementById("pid").value;
	
	//发送异步请求
	sendAsynchronRequest("Release",parameter,isReleaseCallBack);
	
}

function isReleaseCallBack(){
	
	if(xmlHttp.readyState==4){
		if(xmlHttp.status==200){
			
			var xml = xmlHttp.responseXML;
			var ok = xml.getElementsByTagName("ok")[0];
			var no = xml.getElementsByTagName("no")[0];
			
			if(ok!=null){	
				alert("发布审核中...");
			} 
			if(no != null) {
				alert("问卷已发布");
			}
			
		}
	}
	
}