# Defaults for netfleet initscript
# sourced by /etc/init.d/netfleet
# installed at /etc/default/netfleet by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
