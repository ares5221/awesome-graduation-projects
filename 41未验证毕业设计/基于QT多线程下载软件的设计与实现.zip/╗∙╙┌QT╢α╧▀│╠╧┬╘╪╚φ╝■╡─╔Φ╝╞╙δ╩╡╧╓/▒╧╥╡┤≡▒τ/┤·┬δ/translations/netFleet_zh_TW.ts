<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>About</name>
    <message>
        <location filename="../ui/about.ui" line="32"/>
        <location filename="../ui/about.ui" line="98"/>
        <source>About</source>
        <translation type="unfinished">關于</translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="117"/>
        <source>(c): 2009  NetFleet lsn752</source>
        <translation type="unfinished">(c) 2009 網絡艦隊 lsn752</translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="152"/>
        <source>Author</source>
        <translation type="unfinished">作者</translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="68"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;table border=&quot;0&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px;&quot; cellspacing=&quot;0&quot; cellpadding=&quot;0&quot;&gt;
&lt;tr&gt;
&lt;td rowspan=&quot;3&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt; &lt;/span&gt;&lt;img src=&quot;:/images/icon.png&quot; /&gt;      &lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:24pt;&quot;&gt;NetFleet&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Copyright: 2009&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Version: 0.2.0   Open Source Edition&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="104"/>
        <source>NetFleet is a cross-platform multi-threaded download utility.</source>
        <translation type="unfinished">網絡艦隊是一個跨平台的多線程下載軟件。</translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="127"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://netfleet.sourceforge.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://netfleet.sourceforge.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="158"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Please report bugs to &lt;a href=&quot;http://netfleet.sourceforge.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://netfleet.sourceforge.net&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;請把錯誤報告提交到 &lt;a href=&quot;http://netfleet.sourceforge.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://netfleet.sourceforge.net&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="172"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;lsn752:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;    &lt;a href=&quot;mailto:lsn752@gmail.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;lsn752@gmail.com&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;    Developer&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="199"/>
        <source>Translator</source>
        <translation type="unfinished">翻譯</translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="205"/>
        <source>German:anonymous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="212"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;English:lsn&amp;lt;&lt;a href=&quot;mailto:lsn752@gmail.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;lsn752@gmail.com&lt;/span&gt;&lt;/a&gt;&amp;gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="223"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Simplified Chinese:lsn&amp;lt;&lt;a href=&quot;mailto:lsn752@gmail.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;lsn752@gmail.com&lt;/span&gt;&lt;/a&gt;&amp;gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/about.ui" line="234"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Traditional Chinese:lsn&amp;lt;&lt;a href=&quot;mailto:lsn752@gmail.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;lsn752@gmail.com&lt;/span&gt;&lt;/a&gt;&amp;gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <location filename="../src/downloadthread.cpp" line="73"/>
        <location filename="../src/downloadthread.cpp" line="89"/>
        <source>File download Finished.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditProxyDialog</name>
    <message>
        <location filename="../src/editproxydialog.cpp" line="9"/>
        <source>Modify Proxy</source>
        <translation type="unfinished">修改代理服務器</translation>
    </message>
    <message>
        <location filename="../src/editproxydialog.cpp" line="30"/>
        <location filename="../src/editproxydialog.cpp" line="35"/>
        <source>critical</source>
        <translation type="unfinished">錯誤</translation>
    </message>
    <message>
        <location filename="../src/editproxydialog.cpp" line="30"/>
        <source>Title should not be empty.</source>
        <translation type="unfinished">代理服務器名稱不能為空。</translation>
    </message>
    <message>
        <location filename="../src/editproxydialog.cpp" line="35"/>
        <source>Host should not be empty.</source>
        <translation type="unfinished">代理服務器不能為空。</translation>
    </message>
</context>
<context>
    <name>FtpDownload</name>
    <message>
        <location filename="../src/ftpdownload.cpp" line="43"/>
        <source>File name is empty.</source>
        <translation type="unfinished">文件名為空。</translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="53"/>
        <source>Unable to save the file %1: %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="91"/>
        <source>There is no connection to the host.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="116"/>
        <source>A host name lookup is in progress.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="120"/>
        <source>Connecting %1:%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="130"/>
        <source>Host is connected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="131"/>
        <source>The client is sending its request to the server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="141"/>
        <source>Host is logged in.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="145"/>
        <source>Host is Closing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="168"/>
        <source>File download Finished.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="193"/>
        <location filename="../src/ftpdownload.cpp" line="220"/>
        <source>File download finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="183"/>
        <location filename="../src/ftpdownload.cpp" line="209"/>
        <source>File download stopped.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="202"/>
        <source>Download failed: %1.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="236"/>
        <source>connect %1:%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="241"/>
        <source>User login %1:%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="243"/>
        <source>User login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="250"/>
        <source>TYPE I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="255"/>
        <source>SIZE %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="261"/>
        <source>REST %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="267"/>
        <source>RETR %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="277"/>
        <source>Unable to connect to the FTP server at %1. Please check that the host name is correct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="278"/>
        <location filename="../src/ftpdownload.cpp" line="293"/>
        <location filename="../src/ftpdownload.cpp" line="308"/>
        <location filename="../src/ftpdownload.cpp" line="335"/>
        <source>Retry after %1 seconds.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="292"/>
        <source>Login failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="307"/>
        <source>download failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="334"/>
        <source>File size incorrect.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ftpdownload.cpp" line="344"/>
        <source>Connected timeout.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HttpDownload</name>
    <message>
        <location filename="../src/httpdownload.cpp" line="46"/>
        <source>File name is empty.</source>
        <translation type="unfinished">文件名為空。</translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="56"/>
        <source>Unable to save the file %1: %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="111"/>
        <source>There is no connection to the host.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="145"/>
        <source>A host name lookup is in progress.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="148"/>
        <source>Connecting %1:%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="155"/>
        <source>The client is sending its request to the server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="165"/>
        <source>The client is reading the server&apos;s response.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="168"/>
        <source>Host is connected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="171"/>
        <source>Host is Closing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="189"/>
        <location filename="../src/httpdownload.cpp" line="230"/>
        <source>File download finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="201"/>
        <source>File download stopped.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="210"/>
        <source>Download failed: %1.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="217"/>
        <source>File download failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="221"/>
        <location filename="../src/httpdownload.cpp" line="287"/>
        <location filename="../src/httpdownload.cpp" line="309"/>
        <source>Retry after %1 seconds.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="266"/>
        <source>Files larger than 4GB.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="286"/>
        <source>File size incorrect.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="300"/>
        <source>Could not get contentLength.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="308"/>
        <source>Download failed:%1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="316"/>
        <source>Authentication required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="347"/>
        <source>One or more SSL errors has occurred:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/httpdownload.cpp" line="354"/>
        <source>Connected timeout.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.cpp" line="26"/>
        <location filename="../src/mainwindow.cpp" line="274"/>
        <location filename="../src/mainwindow.cpp" line="284"/>
        <source>English</source>
        <translatorcomment>Translate Language</translatorcomment>
        <translation type="unfinished">繁體中文</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="84"/>
        <source>&amp;Quit</source>
        <translation type="unfinished">(&amp;Q)退出</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="85"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="86"/>
        <source>Quit</source>
        <translation type="unfinished">退出</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="89"/>
        <source>&amp;New task</source>
        <translation type="unfinished">(&amp;N)新任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="90"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="91"/>
        <source>New task</source>
        <translation type="unfinished">新任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="94"/>
        <source>&amp;Run task</source>
        <translation type="unfinished">(&amp;R)運行任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="96"/>
        <source>Run task</source>
        <translation type="unfinished">運行任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="103"/>
        <source>&amp;Stop task</source>
        <translation type="unfinished">(&amp;S)停止任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="104"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="105"/>
        <source>Stop task</source>
        <translation type="unfinished">停止任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="112"/>
        <source>&amp;Delete task</source>
        <translation type="unfinished">(&amp;D)刪除任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="113"/>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="114"/>
        <source>Delete task</source>
        <translation type="unfinished">刪除任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="117"/>
        <source>D&amp;ownload task again</source>
        <translation type="unfinished">(&amp;O)重新下載任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="118"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="127"/>
        <source>D&amp;rop window</source>
        <translation type="unfinished">(&amp;R)拖動窗口</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="133"/>
        <source>Speed &amp;widget</source>
        <translation type="unfinished">(&amp;W)速度控件</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="134"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="135"/>
        <source>Show speed widget</source>
        <translation type="unfinished">顯示速度控件</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="139"/>
        <source>&amp;Task tool bar</source>
        <translation type="unfinished">(&amp;T)工具條</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="140"/>
        <source>Ctrl+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="141"/>
        <source>Show task tool bar</source>
        <translation type="unfinished">顯示工具條</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="156"/>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="119"/>
        <source>Download task again</source>
        <translation type="unfinished">重新下載</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="122"/>
        <source>&amp;Modify task properties</source>
        <translation type="unfinished">(&amp;M)修改任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="123"/>
        <source>Ctrl+M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="124"/>
        <source>Modify task properties</source>
        <translation type="unfinished">修改任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="129"/>
        <source>Show drop window</source>
        <translation type="unfinished">顯示拖放窗口</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="145"/>
        <source>&amp;Preferences</source>
        <translation type="unfinished">(&amp;P)參數</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="146"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="147"/>
        <source>System Configuration</source>
        <translation type="unfinished">系統設置</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="155"/>
        <source>&amp;About</source>
        <translation type="unfinished">(&amp;A)關于</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="157"/>
        <source>Show the application&apos;s About box</source>
        <translation type="unfinished">顯示關于</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="160"/>
        <source>About &amp;Qt</source>
        <translation type="unfinished">(&amp;Q)關于 Qt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="161"/>
        <source>Show the Qt library&apos;s About box</source>
        <translation type="unfinished">顯示Qt版本信息</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="164"/>
        <source>&amp;Restore</source>
        <translation type="unfinished">(&amp;R)恢複</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="167"/>
        <source>&amp;Hide</source>
        <translation type="unfinished">(&amp;H)隱藏</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="170"/>
        <source>&amp;Copy</source>
        <translation type="unfinished">(&amp;C)複制</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="182"/>
        <source>Test</source>
        <translation type="unfinished">測試</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="257"/>
        <source>&amp;Language</source>
        <translation type="unfinished">(&amp;L)語言</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>Elapsed time</source>
        <translation type="unfinished">已用時間</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>Comment</source>
        <translation type="unfinished">注釋</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1335"/>
        <source>Modify task</source>
        <translation type="unfinished">修改任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2384"/>
        <source>Take effect after restart software.</source>
        <translation type="unfinished">軟件重啓後生效。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="70"/>
        <location filename="../src/mainwindow.cpp" line="209"/>
        <source>NetFleet</source>
        <translation type="unfinished">網絡艦隊</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="95"/>
        <location filename="../src/mainwindow.cpp" line="128"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="99"/>
        <location filename="../src/mainwindow.cpp" line="100"/>
        <source>Run all task</source>
        <translation type="unfinished">運行所有任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="108"/>
        <location filename="../src/mainwindow.cpp" line="109"/>
        <source>Stop all task</source>
        <translation type="unfinished">停止所有任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="150"/>
        <source>&amp;Monitor clipboard</source>
        <translation type="unfinished">(&amp;M)監視剪貼板</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="151"/>
        <source>Monitor clipboard</source>
        <translation type="unfinished">監視剪貼板</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="216"/>
        <source>&amp;File</source>
        <translation type="unfinished">(&amp;F)文件</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="219"/>
        <source>&amp;Task</source>
        <translation type="unfinished">(&amp;T)任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="231"/>
        <source>&amp;View</source>
        <translation type="unfinished">(&amp;V)查看</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="238"/>
        <source>&amp;Option</source>
        <translation type="unfinished">(&amp;O)選項</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="242"/>
        <source>&amp;Help</source>
        <translation type="unfinished">(&amp;H)幫助</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="286"/>
        <source>&amp;%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="298"/>
        <source>Task</source>
        <translation type="unfinished">任務</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="329"/>
        <source>Speed dock</source>
        <translation type="unfinished">速度</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>State</source>
        <translation type="unfinished">狀態</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>File name</source>
        <translation type="unfinished">文件名</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>Size</source>
        <translation type="unfinished">體積</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>Compeleted</source>
        <translation type="unfinished">已下載</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>Progress</source>
        <translation type="unfinished">進度</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>Speed</source>
        <translation type="unfinished">速度</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>Time left</source>
        <translation type="unfinished">剩余時間</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>Retry</source>
        <translation type="unfinished">重試</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>Url</source>
        <translation type="unfinished">網址</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="393"/>
        <source>Time</source>
        <translation type="unfinished">時間</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="393"/>
        <location filename="../src/mainwindow.cpp" line="775"/>
        <location filename="../src/mainwindow.cpp" line="2384"/>
        <source>Infomation</source>
        <translation type="unfinished">信息</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="626"/>
        <source>Question</source>
        <translation type="unfinished">問題</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="626"/>
        <source>There are tasks are running.Close Window Will stop all running task.Quit?</source>
        <translation type="unfinished">任務正在下載運行中，關閉程序將會停止所有下載任務。要繼續退出嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="776"/>
        <source>There already exists a file called %1 in the current directory. Overwrite?</source>
        <translation type="unfinished">文件%1已存在，覆蓋嗎？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1331"/>
        <source>Information</source>
        <translation type="unfinished">信息</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1331"/>
        <source>Please stop task.</source>
        <translation type="unfinished">請先停止任務。</translation>
    </message>
</context>
<context>
    <name>ModifyTaskDialog</name>
    <message>
        <location filename="../src/modifytaskdialog.cpp" line="20"/>
        <location filename="../src/modifytaskdialog.cpp" line="97"/>
        <location filename="../src/modifytaskdialog.cpp" line="163"/>
        <source>Direct connection</source>
        <translation type="unfinished">直接連接</translation>
    </message>
    <message>
        <location filename="../src/modifytaskdialog.cpp" line="203"/>
        <location filename="../src/modifytaskdialog.cpp" line="218"/>
        <source>critical</source>
        <translation type="unfinished">錯誤</translation>
    </message>
    <message>
        <location filename="../src/modifytaskdialog.cpp" line="203"/>
        <source>Invalid input.</source>
        <translation type="unfinished">輸入錯誤。</translation>
    </message>
    <message>
        <location filename="../src/modifytaskdialog.cpp" line="218"/>
        <source>Invalid URL: %1</source>
        <translation type="unfinished">網址錯誤：%1</translation>
    </message>
</context>
<context>
    <name>NewProxyDialog</name>
    <message>
        <location filename="../src/newproxydialog.cpp" line="32"/>
        <location filename="../src/newproxydialog.cpp" line="37"/>
        <source>critical</source>
        <translation type="unfinished">錯誤</translation>
    </message>
    <message>
        <location filename="../src/newproxydialog.cpp" line="32"/>
        <source>Title should not be empty.</source>
        <translation type="unfinished">代理服務器名稱不能為空。</translation>
    </message>
    <message>
        <location filename="../src/newproxydialog.cpp" line="37"/>
        <source>Host should not be empty.</source>
        <translation type="unfinished">代理服務器不能為空。</translation>
    </message>
</context>
<context>
    <name>NewTaskDialog</name>
    <message>
        <location filename="../src/newtaskdialog.cpp" line="30"/>
        <location filename="../src/newtaskdialog.cpp" line="93"/>
        <source>Direct connection</source>
        <translation type="unfinished">直接連接</translation>
    </message>
    <message>
        <location filename="../src/newtaskdialog.cpp" line="133"/>
        <location filename="../src/newtaskdialog.cpp" line="146"/>
        <location filename="../src/newtaskdialog.cpp" line="166"/>
        <source>critical</source>
        <translation type="unfinished">錯誤</translation>
    </message>
    <message>
        <location filename="../src/newtaskdialog.cpp" line="133"/>
        <source>Invalid input.</source>
        <translation type="unfinished">輸入錯誤。</translation>
    </message>
    <message>
        <location filename="../src/newtaskdialog.cpp" line="146"/>
        <source>URL: %1 already exists.</source>
        <translation type="unfinished">網址:%1 已在下載任務中。 </translation>
    </message>
    <message>
        <location filename="../src/newtaskdialog.cpp" line="166"/>
        <source>Invalid URL: %1</source>
        <translation type="unfinished">網址錯誤：%1</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../src/preferencesdialog.cpp" line="194"/>
        <source>critical</source>
        <translation type="unfinished">錯誤</translation>
    </message>
    <message>
        <location filename="../src/preferencesdialog.cpp" line="194"/>
        <source>Default save path should not be empty.</source>
        <translation type="unfinished">默認保存路徑不能為空</translation>
    </message>
</context>
<context>
    <name>Tools</name>
    <message>
        <location filename="../src/tools.cpp" line="13"/>
        <source>%1B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/tools.cpp" line="14"/>
        <source>%1KB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/tools.cpp" line="15"/>
        <source>%1MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/tools.cpp" line="16"/>
        <source>%1GB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/tools.cpp" line="25"/>
        <source>0h:0m:0s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/tools.cpp" line="34"/>
        <location filename="../src/tools.cpp" line="46"/>
        <source>%1h:%2m:%3s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>deleteTask</name>
    <message>
        <location filename="../ui/delete.ui" line="14"/>
        <source>Delete task</source>
        <translation type="unfinished">刪除任務</translation>
    </message>
    <message>
        <location filename="../ui/delete.ui" line="20"/>
        <source>Delete selected task:</source>
        <translation type="unfinished">刪除選擇的任務</translation>
    </message>
    <message>
        <location filename="../ui/delete.ui" line="27"/>
        <source>Delete uncompleted file</source>
        <translation type="unfinished">刪除未下載完成的文件</translation>
    </message>
    <message>
        <location filename="../ui/delete.ui" line="37"/>
        <source>Delete downloaded file</source>
        <translation type="unfinished">刪除已下載的文件</translation>
    </message>
</context>
<context>
    <name>newTask</name>
    <message>
        <location filename="../ui/newtask.ui" line="20"/>
        <source>New Task</source>
        <translation type="unfinished">新任務</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="30"/>
        <source>General</source>
        <translation type="unfinished">普通</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="42"/>
        <source>File</source>
        <translation type="unfinished">文件</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="50"/>
        <source>Url:</source>
        <translation type="unfinished">網址：</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="60"/>
        <source>Save to:</source>
        <translation type="unfinished">保存路徑：</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="128"/>
        <source>Rename:</source>
        <translation type="unfinished">重命名：</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="138"/>
        <source>Referrer:</source>
        <translation type="unfinished">來源于：</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="152"/>
        <source>Split file</source>
        <translation type="unfinished">將文件分割成</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="172"/>
        <source>part simultaneous</source>
        <translation type="unfinished">條線程下載</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="207"/>
        <source>Authorization</source>
        <translation type="unfinished">登錄</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="215"/>
        <source>User:</source>
        <translation type="unfinished">用戶名：</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="232"/>
        <source>Password:</source>
        <translation type="unfinished">密碼：</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="251"/>
        <source>Start</source>
        <translation type="unfinished">開始</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="259"/>
        <source>Manual</source>
        <translation type="unfinished">手動</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="266"/>
        <source>Immediately</source>
        <translation type="unfinished">立即</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="296"/>
        <source>Comment</source>
        <translation type="unfinished">注釋</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="311"/>
        <location filename="../ui/newtask.ui" line="360"/>
        <source>Proxy</source>
        <translation type="unfinished">代理服務器</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="317"/>
        <source>No Proxy</source>
        <translation type="unfinished">直接連接</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="327"/>
        <source>Single Proxy</source>
        <translation type="unfinished">單一代理服務器</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="341"/>
        <source>Mutiple Proxy</source>
        <translation type="unfinished">多代理服務器（每個線程可以使用不同的代理服務器）</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="406"/>
        <source>More urls</source>
        <translation type="unfinished">更多下載網址</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="355"/>
        <location filename="../ui/newtask.ui" line="419"/>
        <source>Thread</source>
        <translation type="unfinished">線程</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="424"/>
        <source>Url</source>
        <translatorcomment>網址</translatorcomment>
        <translation type="unfinished">網址</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="386"/>
        <location filename="../ui/newtask.ui" line="447"/>
        <source>Add</source>
        <translation type="unfinished">添加</translation>
    </message>
    <message>
        <location filename="../ui/newtask.ui" line="396"/>
        <location filename="../ui/newtask.ui" line="454"/>
        <source>Delete</source>
        <translation type="unfinished">刪除</translation>
    </message>
</context>
<context>
    <name>newproxy</name>
    <message>
        <location filename="../ui/newproxy.ui" line="14"/>
        <source>New proxy</source>
        <translation type="unfinished">新代理服務器</translation>
    </message>
    <message>
        <location filename="../ui/newproxy.ui" line="22"/>
        <source>Title:</source>
        <translation type="unfinished">名字：</translation>
    </message>
    <message>
        <location filename="../ui/newproxy.ui" line="29"/>
        <source>Host:</source>
        <translation type="unfinished">服務器：</translation>
    </message>
    <message>
        <location filename="../ui/newproxy.ui" line="36"/>
        <source>Port:</source>
        <translation type="unfinished">端口：</translation>
    </message>
    <message>
        <location filename="../ui/newproxy.ui" line="91"/>
        <source>Type</source>
        <translation type="unfinished">類型</translation>
    </message>
    <message>
        <location filename="../ui/newproxy.ui" line="99"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/newproxy.ui" line="109"/>
        <source>SOCKS 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/newproxy.ui" line="116"/>
        <source>SOCKS 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/newproxy.ui" line="132"/>
        <source>Authorization</source>
        <translation type="unfinished">登錄</translation>
    </message>
    <message>
        <location filename="../ui/newproxy.ui" line="140"/>
        <source>User:</source>
        <translation type="unfinished">用戶名：</translation>
    </message>
    <message>
        <location filename="../ui/newproxy.ui" line="147"/>
        <source>Password:</source>
        <translation type="unfinished">密碼：</translation>
    </message>
</context>
<context>
    <name>preferences</name>
    <message>
        <location filename="../ui/preferences.ui" line="14"/>
        <source>preferences</source>
        <translation type="unfinished">配置</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="29"/>
        <source>General</source>
        <translation type="unfinished">普通</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="35"/>
        <source>Task</source>
        <translation type="unfinished">任務</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="43"/>
        <source>Default split threads(1-100):</source>
        <translation type="unfinished">默認分割線程數(1-100)：</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="90"/>
        <location filename="../ui/preferences.ui" line="531"/>
        <source>KB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="112"/>
        <source>Max running tasks:(1-99)</source>
        <translation type="unfinished">最大同時運行任務數(1-99)：</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="146"/>
        <source>Minimum split size(10-9999999):</source>
        <translation type="unfinished">最小分割體積(1-9999999)：</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="158"/>
        <source>Save path</source>
        <translation type="unfinished">保存路徑</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="166"/>
        <source>Default save path:</source>
        <translation type="unfinished">默認保存路徑：</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="251"/>
        <source>Use the last path location:</source>
        <translation type="unfinished">使用最後下載的路徑：</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="258"/>
        <source>Use the default save path:</source>
        <translation type="unfinished">使用默認路徑：</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="270"/>
        <source>Connection</source>
        <translation type="unfinished">連接</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="284"/>
        <source>Connect timeout(1-300):</source>
        <translation type="unfinished">連接超時(1-300)：</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="310"/>
        <source>Max retry number(0-9999):</source>
        <translation type="unfinished">最大重試次數(0-9999)：</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="327"/>
        <source>Retry Delay(0-3600):</source>
        <translation type="unfinished">重試間隔(0-3600)：</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="357"/>
        <source>seconds</source>
        <translation type="unfinished">秒</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="364"/>
        <source>Always Retry</source>
        <translation type="unfinished">總是重試</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="393"/>
        <source>Graph</source>
        <translation type="unfinished">圖形</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="399"/>
        <source>Speed graph</source>
        <translation type="unfinished">速度圖形</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="407"/>
        <source>Max speed(10-99999):</source>
        <translation type="unfinished">最大速度(10-99999)：</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="414"/>
        <source>Widget Height(10-300):</source>
        <translation type="unfinished">控件高度(10-300)：</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="421"/>
        <source>KB/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="454"/>
        <location filename="../ui/preferences.ui" line="491"/>
        <source>Pixel</source>
        <translation type="unfinished">像素</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="461"/>
        <source>Pixel width(1-99):</source>
        <translation type="unfinished">顯示點寬度</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="503"/>
        <source>Blocks graph</source>
        <translation type="unfinished">任務方塊圖形</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="511"/>
        <source>Block size(10-999999):</source>
        <translation type="unfinished">每塊表示大小</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="570"/>
        <source>Monitor</source>
        <translation type="unfinished">監視</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="576"/>
        <source>Clipboard</source>
        <translation type="unfinished">剪貼板</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="582"/>
        <source>Monitor these file types</source>
        <translation type="unfinished">監視以下文件類型</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="609"/>
        <source>Proxy</source>
        <translation type="unfinished">代理服務器</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="625"/>
        <source>Title</source>
        <translation type="unfinished">名稱</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="630"/>
        <source>Host</source>
        <translation type="unfinished">服務器</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="635"/>
        <source>Port</source>
        <translation type="unfinished">端口</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="640"/>
        <source>Type</source>
        <translation type="unfinished">類型</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="645"/>
        <source>User</source>
        <translation type="unfinished">用戶</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="650"/>
        <source>Password</source>
        <translation type="unfinished">密碼</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="673"/>
        <source>Add</source>
        <translation type="unfinished">添加</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="680"/>
        <source>Edit</source>
        <translation type="unfinished">編輯</translation>
    </message>
    <message>
        <location filename="../ui/preferences.ui" line="687"/>
        <source>Delete</source>
        <translation type="unfinished">刪除</translation>
    </message>
</context>
</TS>
