#include "deletetaskdialog.h"

DeleteTaskDialog::DeleteTaskDialog(QWidget *parent, Qt::WFlags f) : QDialog(parent, f)
{
    setupUi(this);
}
