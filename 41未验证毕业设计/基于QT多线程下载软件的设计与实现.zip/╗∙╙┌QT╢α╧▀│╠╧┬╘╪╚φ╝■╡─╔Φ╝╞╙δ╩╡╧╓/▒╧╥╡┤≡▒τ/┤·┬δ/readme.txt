1. Extract the source zip. 

2.'cd' to the directory containing the package's source code and type 'qmake' to generate the Makefile for your system. 

3. Type 'make' on Linux or 'mingw32-make` on Windows to compile the package. 

4. The executable file netfleet(netfleet.exe under Windows) is built on bin/ directory.