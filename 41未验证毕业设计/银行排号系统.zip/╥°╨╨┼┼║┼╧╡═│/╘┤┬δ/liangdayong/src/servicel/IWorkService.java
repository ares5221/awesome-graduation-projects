package servicel;

public interface IWorkService {

}
