#include "mywidget.h"
#include "ui_mywidget.h"


void game_hide(myWidget &source)
{
    source.chess_board->hide();
    source.ui->lcdNumber_1->hide();
    source.ui->lcdNumber_2->hide();
    source.ui->frame_blood_a->hide();
    source.ui->frame_blood_b->hide();
    source.ui->label_pic_a->hide();
    source.ui->label_pic_b->hide();
    source.ui->label_time_a->hide();
    source.ui->label_time_b->hide();
    source.ui->frame_chessboard->hide();
    source.ui->textEdit_help->show();
    //source.ui->label_beginbutton->show();
}

void game_show(myWidget &source)
{
    //source.ui->label_beginbutton->hide();
    source.ui->textEdit_help->hide();
    source.ui->frame_chessboard->show();
    source.ui->lcdNumber_1->show();
    source.ui->lcdNumber_2->show();
    source.ui->frame_blood_a->show();
    source.ui->frame_blood_b->show();
    source.ui->label_pic_a->show();
    source.ui->label_pic_b->show();
    source.ui->label_time_a->show();
    source.ui->label_time_b->show();
    source.chess_board->show();
}


void time_anew(myWidget &source)//����ʱ����ɫ������������Чʱ��
{
    QPalette palette_1;
    QBrush brush_1(QColor(0, 0, 0, 230));
    brush_1.setStyle(Qt::SolidPattern);
    palette_1.setBrush(QPalette::Active, QPalette::WindowText, brush_1);
    QPalette palette_2;
    QBrush brush_2(QColor(125, 125, 125, 100));
    brush_2.setStyle(Qt::SolidPattern);
    palette_2.setBrush(QPalette::Active, QPalette::WindowText, brush_2);
    if(source.who_control == 1)
    {
        source.ui->label_time_a->setPalette(palette_1);
        source.ui->label_time_b->setPalette(palette_2);
    }
    else
    {
        source.ui->label_time_a->setPalette(palette_2);
        source.ui->label_time_b->setPalette(palette_1);
    }
    source.ui->label_pic_a->setText(QString(""));
    source.ui->label_pic_b->setText(QString(""));
    source.hold_time = 30;//��Чʱ�仹ԭΪ30��
    source.whole_second = true;//ʱ������Ϊ����
}



void back_step(myWidget &source)
{
    if(source.chess_board->step_info_link)//����в�����¼
    {
        char myself = (source.chess_board->step_info_link->num +1) %2;//�Լ��Ĵ���
        int k_number = 0;//���Ե�����������
        GRIDINFO *temp_grid = source.chess_board->grid_info_link;
        KILLINFO *temp_killed = source.chess_board->step_info_link->killed_xylink;

        while(temp_killed)//����Է��Ե����Լ������ӣ������Ե������ӻ�ԭ
        {
            while(temp_grid)
            {
                if(temp_grid->x == temp_killed->x && temp_grid->y == temp_killed->y)
                {
                    k_number++;
                    temp_grid->who = myself;
                    break;
                }
                temp_grid = temp_grid->next;
            }
            temp_grid = source.chess_board->grid_info_link;
            temp_killed = temp_killed->next;
        }

        if(k_number)
        {
            unsigned char temp_a,temp_b;//ˮƽ����a����ֱ����b��
            int temp_c,temp_d,temp_e,temp_f;//�ߴ�c���߾�d�����e�����f
            source.chess_board->getchessboard(temp_a,temp_b,temp_c,temp_d,temp_e,temp_f);
            unsigned char max_xy = temp_a>temp_b?temp_a:temp_b;
            if(source.who_control == 1)
            {
                source.blood_a = source.blood_a/(1 - k_number / float(source.surplus_grid + 4*(max_xy -3)));
                //qDebug()<<source.blood_a;
            }
            else
            {
                source.blood_b = source.blood_b/(1 - k_number / float(source.surplus_grid + 4*(max_xy -3)));
                //qDebug()<<source.blood_b;
            }

            while(temp_grid)
            {
                if(temp_grid->x == source.chess_board->step_info_link->x && temp_grid->y == source.chess_board->step_info_link->y)
                {
                    temp_grid->who = -1;//����һ��ռ���λ�û�ԭΪ��
                    source.surplus_grid++;//ʣ�����������1
                    source.ui->lcdNumber_1->display(source.surplus_grid/10);
                    source.ui->lcdNumber_2->display(source.surplus_grid%10);
                    break;
                }
                temp_grid = temp_grid->next;
            }
        }

        if(source.chess_board->step_info_link->killed_xylink)//����������Ҫ��ԭ�������˴����Բ�ɾ��
        {
            while(source.chess_board->step_info_link->killed_xylink)
            {
                temp_killed = source.chess_board->step_info_link->killed_xylink->next;
                delete source.chess_board->step_info_link->killed_xylink;
                source.chess_board->step_info_link->killed_xylink = temp_killed;
            }
        }

        if(source.chess_board->step_info_link->back)
        {
            source.chess_board->step_info_link = source.chess_board->step_info_link->back;
            delete source.chess_board->step_info_link->next;
            source.chess_board->step_info_link->next =NULL;
        }
        else
        {
            delete source.chess_board->step_info_link;
            source.chess_board->step_info_link = NULL;
        }

        time_anew(source);
        source.who_control = (source.who_control +1)%2;//�ѿ���Ȩ���Է�
    }
}

void creat_stepinfo(myWidget &source , GRIDINFO *nonce_gridinfo ,KILLINFO *k_info)
{
    STEPINFO *new_stepinfo = new STEPINFO;
    if(nonce_gridinfo)
    {
        new_stepinfo->x = nonce_gridinfo->x;
        new_stepinfo->y = nonce_gridinfo->y;
    }
    new_stepinfo->killed_xylink = k_info;
    if(k_info)
    {
        source.isplaychess = true;
    }
    else
    {
        source.isplaychess = false;
    }
    new_stepinfo->back = source.chess_board->step_info_link;
    new_stepinfo->next = NULL;
    if(new_stepinfo->back == NULL)
    {
        new_stepinfo->num = 1;//����Ϊa�Ĳ�����ż��Ϊb�Ĳ���
    }
    else
    {
        new_stepinfo->num = source.chess_board->step_info_link->num + 1;
        source.chess_board->step_info_link->next = new_stepinfo;
    }
    source.chess_board->step_info_link = new_stepinfo;//��������ָ�򱾴β���
    source.who_control = (source.who_control +1)%2;//ת�ÿ���Ȩ
    time_anew(source);//����ʱ��

}

int kill_chess(myWidget &source, GRIDINFO *nonce_gridinfo , bool iskill)
{
    int k_number = 0;//�Ե��Ķ�����������
    KILLINFO *k_info = NULL;
    char myself = source.who_control;//�Լ��Ĵ���
    char adversary = (source.who_control + 1)%2;//���ֵĴ���
    GRIDINFO *near_gridinfo = source.chess_board->grid_info_link;//���ŵĶ�������
    unsigned char temp_a,temp_b;//ˮƽ����a����ֱ����b��
    int temp_c,temp_d,temp_e,temp_f;//�ߴ�c���߾�d�����e�����f
    source.chess_board->getchessboard(temp_a,temp_b,temp_c,temp_d,temp_e,temp_f);
    unsigned char max_xy;
    max_xy = temp_a>temp_b?temp_a:temp_b;
    int difference_x,difference_y;//���������ֵ
    while(near_gridinfo)
    {
        difference_x = near_gridinfo->x - nonce_gridinfo->x;
        difference_y = near_gridinfo->y - nonce_gridinfo->y;
        if(near_gridinfo->who==adversary && abs(difference_x)<=1 && abs(difference_y)<=1)//�ø����ڵ�8��������һ��������
        {
            GRIDINFO *collinear_gridinfo = source.chess_board->grid_info_link;//ͬ�����Լ�������
            RELATIVEINFO chess={0,0,max_xy+1};//��ʱ�����Ծ���������Լ�������Ϣ
            int k;//���ӵ���Ծ���
            while(collinear_gridinfo)
            {
                for(k=2;k<=max_xy;k++)//k=0Ϊ��ǰ��k=1Ϊ���ŵĶ������ӣ�����k��2��ʼ
                {
                    if(collinear_gridinfo->x - nonce_gridinfo->x == k*difference_x  && collinear_gridinfo->y - nonce_gridinfo->y == k*difference_y )//ͬ���������
                    {
                        if(collinear_gridinfo->who == myself && k < chess.space)
                        {
                            chess.x = collinear_gridinfo->x;
                            chess.y = collinear_gridinfo->y;
                            chess.space = k;
                        }
                    }
                }
                collinear_gridinfo = collinear_gridinfo->next;
            }
            if(chess.space != max_xy+1)//���chess.space��ֵ�����ˣ�˵��һ���ҵ���ͬ������뵱ǰλ��������Լ�����
            {
                GRIDINFO *none_gridinfo = source.chess_board->grid_info_link;//�����Լ�����֮��Ŀո�
                while(none_gridinfo)//��ʼ���������Լ�����֮��Ŀո�
                {
                    for(k=2;k<=max_xy;k++)//k=0Ϊ��ǰ��k=1Ϊ���ŵĶ������ӣ�����k��2��ʼ
                    {
                        if(none_gridinfo->x - nonce_gridinfo->x == k*difference_x  && none_gridinfo->y - nonce_gridinfo->y == k*difference_y )//ͬ���������
                        {
                            if(none_gridinfo->who == -1 && k < chess.space)//�ո�������
                            {
                                chess.space = max_xy+1;
                                break;
                            }
                        }
                    }
                    none_gridinfo = none_gridinfo->next;
                }
                if(chess.space != max_xy+1)//˵��֮��û�пո񣬿��Կ�ʼ����������
                {
                    GRIDINFO *goner_gridinfo = source.chess_board->grid_info_link;//�����Ե�������
                    while(goner_gridinfo)//��ʼ�Ե�ͬ����ĶԷ�����
                    {
                        for(k=1;k<chess.space;k++)//k=0Ϊ��ǰ������k��1��ʼ
                        {
                            if(goner_gridinfo->x - nonce_gridinfo->x == k*difference_x  && goner_gridinfo->y - nonce_gridinfo->y == k*difference_y )//ͬ���������
                            {
                                if(goner_gridinfo->who == adversary)
                                {
                                    k_number += 1;
                                    if(iskill)
                                    {
                                        goner_gridinfo->who = myself;
                                        KILLINFO *pf,*new_k_info = new KILLINFO;
                                        new_k_info->x = goner_gridinfo->x;
                                        new_k_info->y = goner_gridinfo->y;
                                        new_k_info->next = NULL;
                                        if(k_info == NULL)
                                        {
                                            k_info = pf = new_k_info;
                                        }
                                        else
                                        {
                                            while(pf->next)
                                            {
                                                pf = pf->next;
                                            }
                                            pf->next = new_k_info;
                                        }
                                    }
                                }
                            }
                        }
                        goner_gridinfo = goner_gridinfo->next;
                    }
                }
            }
        }
        near_gridinfo = near_gridinfo->next;
    }

    if(iskill && k_number)
    {
        nonce_gridinfo->who = source.who_control;//��������Ϊ�Լ���

        if(source.ai_stat != myself && source.ai_stat != 2)
        {
            source.cue_info[0] = 0;
        }

        source.surplus_grid--;//ʣ�����������1
        source.ui->lcdNumber_1->display(source.surplus_grid/10);
        source.ui->lcdNumber_2->display(source.surplus_grid%10);
        /*
             int a = 0 , b = 0;//˫����������
             GRIDINFO *temp_gridinfo = this->chess_board->grid_info_link;//���̸���Ϣ
             while(temp_gridinfo)
             {
                 if(temp_gridinfo->who == 1)
                 {
                     a += 1;
                 }
                 else if(temp_gridinfo->who == 0)
                 {
                     b += 1;
                 }
                 temp_gridinfo = temp_gridinfo->next;
             }*/

        if(source.who_control == 0)
        {
            source.blood_a = source.blood_a*(1 - k_number / float(source.surplus_grid + 4*(max_xy -3)));
            //qDebug()<<source.blood_a;
        }
        else
        {
            source.blood_b = source.blood_b*(1 - k_number / float(source.surplus_grid + 4*(max_xy -3)));
            //qDebug()<<source.blood_b;
        }


        creat_stepinfo(source, nonce_gridinfo , k_info);//����ò�����Ϣ��ת�ÿ���Ȩ
        source.update();
    }
    return k_number;
}


int ai_cue(myWidget &source , bool isai)
{
    int k_number;
    unsigned char temp_a,temp_b;//ˮƽ����a����ֱ����b��
    int temp_c,temp_d,temp_e,temp_f;//�ߴ�c���߾�d�����e�����f
    source.chess_board->getchessboard(temp_a,temp_b,temp_c,temp_d,temp_e,temp_f);
    GRIDINFO *temp_gridinfo = source.chess_board->grid_info_link;
    source.cue_info[0] = 0;
    while(temp_gridinfo)
    {
        if(temp_gridinfo->who == -1)
        {
            k_number = kill_chess(source , temp_gridinfo ,false);
            if(k_number > source.cue_info[0])
            {
                source.cue_info[0] = k_number;
                source.cue_info[1] = temp_gridinfo->x;
                source.cue_info[2] = temp_gridinfo->y;
                if(source.ai_grade == 1)//ai�ȼ���1Ϊ������2Ϊ�м���3Ϊ�߼�
                {
                    if(qrand()%3 != 0)
                    {
                        break;
                    }
                }
                else if(source.ai_grade == 2)
                {
                    if(qrand()%5 == 0)
                    {
                        break;
                    }
                }
                else if(source.ai_grade == 3)
                {
                    if(source.ai_grade == 3 && (temp_gridinfo->x == 0 || temp_gridinfo->x == temp_a -1) && (temp_gridinfo->y == 0 || temp_gridinfo->y == temp_b -1))
                    {
                        break;
                    }
                    if(source.ai_stat == 2 && qrand()%10 == 0)//�������Ǹ߼�aiʱ��Ϊ����ÿ�ֽ����һ����Ӧ�������
                    {
                        break;
                    }
                }

            }
        }
        temp_gridinfo = temp_gridinfo->next;
    }
    if(isai && source.cue_info[0] > 0)//�����aiģʽ
    {
        temp_gridinfo = source.chess_board->grid_info_link;
        while(temp_gridinfo->x != source.cue_info[1] || temp_gridinfo->y != source.cue_info[2])//�ƶ�����ָ�뵽���ԳԵ�������ӵ�λ��
        {
            temp_gridinfo = temp_gridinfo->next;
        }
        kill_chess(source , temp_gridinfo ,true);
    }
    //qDebug()<<"kill"<<source.cue_info[0]<<" , x = "<<source.cue_info[1]<<" , y = "<<source.cue_info[2];
    return source.cue_info[0];
}

void game_reset(myWidget &source)
{
    KILLINFO *temp_killed;
    while(source.chess_board->step_info_link)
    {
        if(source.chess_board->step_info_link->killed_xylink)
        {
            while(source.chess_board->step_info_link->killed_xylink)
            {
                temp_killed = source.chess_board->step_info_link->killed_xylink->next;
                delete source.chess_board->step_info_link->killed_xylink;
                source.chess_board->step_info_link->killed_xylink = temp_killed;
            }
        }
        if(source.chess_board->step_info_link->back)
        {
            source.chess_board->step_info_link = source.chess_board->step_info_link->back;
            delete source.chess_board->step_info_link->next;
            source.chess_board->step_info_link->next =NULL;
        }
        else
        {
            delete source.chess_board->step_info_link;
            source.chess_board->step_info_link = NULL;
        }
    }


    GRIDINFO *del_gridinfo = source.chess_board->grid_info_link;
    while(del_gridinfo)
    {
        if((del_gridinfo->x == 3 && del_gridinfo->y == 3)||(del_gridinfo->x == 4 && del_gridinfo->y == 4))
        {
            del_gridinfo->who = 1;
        }
        else if((del_gridinfo->x == 3 && del_gridinfo->y == 4)||(del_gridinfo->x == 4 && del_gridinfo->y == 3))
        {
            del_gridinfo->who = 0;
        }
        else
        {
            del_gridinfo->who = -1;
        }
        del_gridinfo = del_gridinfo->next;
    }

    time_anew(source);//���õ���ʱʱ��
    source.who_control = 1;//����Ȩ�����a
    source.blood_a = 1;
    source.blood_b = 1;
    source.player_a_atime = 0;//���a�ܺķ�ʱ��
    source.player_b_atime = 0;//���b�ܺķ�ʱ��
    source.ui->label_time_a->setText(QApplication::translate("myWidget", "00:00:00", 0, QApplication::UnicodeUTF8));
    source.ui->label_time_b->setText(QApplication::translate("myWidget", "00:00:00", 0, QApplication::UnicodeUTF8));
    source.surplus_grid = 60;//ʣ���������
    source.ui->lcdNumber_1->display(source.surplus_grid/10);
    source.ui->lcdNumber_2->display(source.surplus_grid%10);

    game_hide(source);
}


myWidget::myWidget(QWidget *parent) :QWidget(parent),ui(new Ui::myWidget)
{
    ui->setupUi(this);

    ai_stat = 3;//�����Զ�����ai״̬��0Ϊ���b��aiģʽ��1Ϊ���a��aiģʽ��2Ϊ������ʾ�Զ����壬3Ϊ�ر�ai
    ai_grade = 3;//ai�ȼ���1Ϊ������2Ϊ�м���3Ϊ�߼�
    mygame_stat = 0;//��Ϸ״̬��0Ϊ��ʼ״̬��1Ϊ��ͣ��2Ϊ��ʼ
    mybutton_1_stat = 0;//��ť״̬��0Ϊ��ʼ״̬��1Ϊ�����ͣ�����棬2Ϊ����
    mybutton_2_stat = 0;
    mybutton_3_stat = 0;
    mybutton_4_stat = 0;
    mybutton_5_stat = 0;
    mybutton_0_stat = 0;
    mybutton_l1_stat = 0;//left��߽�����ť״̬��0Ϊ��ʼ״̬��1Ϊ�����ͣ�����棬2Ϊ����
    mybutton_l2_stat = 0;
    mybutton_l3_stat = 0;
    mybutton_r1_stat = 0;//right�ұ�AI�ȼ���ť״̬��0Ϊ��ʼ״̬��1Ϊ�����ͣ�����棬2Ϊ����
    mybutton_r2_stat = 0;
    mybutton_r3_stat = 0;

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));//�������������
    style_number = qrand()%3;

    game_style[0][0] = backgrand_0;
    game_style[0][1] = chess_0_a;
    game_style[0][2] = chess_0_b;
    game_style[0][3] = pic_0_a;
    game_style[0][4] = pic_0_b;
    game_style[0][5] = pic_0_a_alarm;
    game_style[0][6] = pic_0_b_alarm;
    game_style[1][0] = backgrand_1;
    game_style[1][1] = chess_1_a;
    game_style[1][2] = chess_1_b;
    game_style[1][3] = pic_1_a;
    game_style[1][4] = pic_1_b;
    game_style[1][5] = pic_1_a_alarm;
    game_style[1][6] = pic_1_b_alarm;
    game_style[2][0] = backgrand_2;
    game_style[2][1] = chess_2_a;
    game_style[2][2] = chess_2_b;
    game_style[2][3] = pic_2_a;
    game_style[2][4] = pic_2_b;
    game_style[2][5] = pic_2_a_alarm;
    game_style[2][6] = pic_2_b_alarm;

    chess_board = new chessboard(this);//��������
    chess_board->setchessboard(8,8,1,5);//��������
    ui->gridLayout->addWidget(chess_board, 0, 0, 1, 1);//����������ʾλ��

    this->whole_second = true;
    hold_time = 30;//ʣ����Чʱ��
    who_control = 1;//����Ȩ
    blood_a = 1;
    blood_b = 1;
    player_a_atime = 0;//���a�ܺķ�ʱ��
    player_b_atime = 0;//���b�ܺķ�ʱ��
    surplus_grid = 60;//ʣ���������
    this->ui->lcdNumber_1->display(this->surplus_grid/10);
    this->ui->lcdNumber_2->display(this->surplus_grid%10);

    QPalette palette_1;
    QBrush brush_1(QColor(0, 0, 0, 230));
    brush_1.setStyle(Qt::SolidPattern);
    palette_1.setBrush(QPalette::Active, QPalette::WindowText, brush_1);
    this->ui->label_time_a->setPalette(palette_1);
    QPalette palette_2;
    QBrush brush_2(QColor(125, 125, 125, 100));
    brush_2.setStyle(Qt::SolidPattern);
    palette_2.setBrush(QPalette::Active, QPalette::WindowText, brush_2);
    this->ui->label_time_b->setPalette(palette_2);

    game_hide(*this);
    this->setMouseTracking(true);

    timer = new QTimer(this);//��ʱ��
    timer->start(500);//�ź�ʱ��Ϊ500���룬��0.5��
    connect(timer,SIGNAL(timeout()),this,SLOT(time_slot()));



}

myWidget::~myWidget()
{
    delete chess_board;
    delete ui;
}



void myWidget::time_slot()
{
    if(this->whole_second && this->mygame_stat == 2)//ʱ�������룬��Ϸ�Ѿ���ʼ
    {
        this->whole_second = false;
        this->hold_time--;

        if(this->hold_time < 0)
        {
            if(ai_stat == 3)//���ai�ǹرյģ���ô���Լ�����Ϊ�����Զ�����
            {
                ai_stat = who_control;
            }
            else if(ai_stat == (who_control + 1)%2)//����Է���ai����ô�ͱ�Ϊai��ai����
            {
                ai_stat = 2;
            }
        }
        else if(this->hold_time == 29 || this->hold_time == 20 || this->hold_time == 10)//��ʼ��������Ƿ��������
        {
            if(ai_cue(*this,false) == 0)//�޵ط���������
            {
                int button;
                int a = 0 , b = 0;//˫����������
                GRIDINFO *temp_gridinfo = this->chess_board->grid_info_link;//���̸���Ϣ
                while(temp_gridinfo)
                {
                    if(temp_gridinfo->who == 1)
                    {
                        a += 1;
                    }
                    else if(temp_gridinfo->who == 0)
                    {
                        b += 1;
                    }
                    temp_gridinfo = temp_gridinfo->next;
                }
                if(!this->isplaychess || this->surplus_grid == 0 || a == 0 || b ==0)//�����һ�ξ�û�����ӻ��Ѿ������ˣ�������һ��û�������ˣ���ôӦ���ж���Ӯ��
                {
                    button = QMessageBox::question(this,"Game over",QString("Result ") + QString::number(a) + QString(":") + QString::number(b) + QString("\n\nGame again ?"), QMessageBox::Yes | QMessageBox::No);
                    switch(button)
                    {
                        case QMessageBox::Yes:
                        mygame_stat = 0;//��Ϸ״̬��0Ϊ��ʼ״̬��1Ϊ��ͣ��2Ϊ��ʼ
                        game_reset(*this);//����Ϸ������գ���������
                            break;
                        case QMessageBox::No:
                            break;
                    }

                }
                else
                {
                    if(ai_stat == 2 || ai_stat == this->who_control)
                    {
                        creat_stepinfo(*this, NULL , NULL);//����ò�����Ϣ
                        if(ai_stat != 2)//˵�����ֲ���ai����ô������һ����ʾ��Ϣ
                        {
                            QMessageBox::information(this,"Information","Other player concession step");
                        }
                    }
                    else
                    {
                        button = QMessageBox::question(this,"None Way","Step Concession ?", QMessageBox::Yes | QMessageBox::No);
                        switch(button)
                        {
                            case QMessageBox::Yes:
                                creat_stepinfo(*this, NULL , NULL);//����ò�����Ϣ
                                break;
                            case QMessageBox::No:
                                break;
                        }
                    }
                }
            }
            if(this->ai_stat != this->who_control && this->ai_stat != 2)
            {
                this->cue_info[0] = 0;
            }
        }

        int hour,minute,second;
        int hour_1,hour_2,minute_1,minute_2,second_1,second_2;
        int player_atime;
        if(this->who_control == 1)
        {
            this->player_a_atime++;
            player_atime = this->player_a_atime;
        }
        else
        {
            this->player_b_atime++;
            player_atime = this->player_b_atime;
        }
        hour = player_atime /3600;
        minute = player_atime %3600 /60;
        second = player_atime %60;
        hour_1 = hour/10;
        hour_2 = hour%10;
        minute_1 = minute/10;
        minute_2 = minute%10;
        second_1 = second/10;
        second_2 = second%10;
        if(this->who_control == 1)
        {
            this->ui->label_time_a->setText(QString("%1%2:%3%4:%5%6").arg(hour_1).arg(hour_2).arg(minute_1).arg(minute_2).arg(second_1).arg(second_2));
            if(ai_stat == 2 || ai_stat == this->who_control)
            {
                this->ui->label_pic_a->setText(QString("AI"));
            }
            else if(this->hold_time < 30 && this->hold_time >= 0)
            {
                this->ui->label_pic_a->setText(QString("%1").arg(this->hold_time));
            }
        }
        else
        {
            this->ui->label_time_b->setText(QString("%1%2:%3%4:%5%6").arg(hour_1).arg(hour_2).arg(minute_1).arg(minute_2).arg(second_1).arg(second_2));
            if(ai_stat == 2 || ai_stat == this->who_control)
            {
                this->ui->label_pic_b->setText(QString("AI"));
            }
            else if(this->hold_time < 30 && this->hold_time >= 0)
            {
                this->ui->label_pic_b->setText(QString("%1").arg(this->hold_time));
            }
        }

        if( this->hold_time < 28 && (ai_stat == 2 || ai_stat == this->who_control))//ai״̬��0Ϊ���b��aiģʽ��1Ϊ���a��aiģʽ��2Ϊ������ʾ�Զ����壬3Ϊ�ر�ai
        {
            ai_cue(*this , true);
        }

    }
    else
    {
        this->whole_second = true;

        if(this->who_control == 1)
        {
            this->ui->label_pic_a->setText(QString(""));
        }
        else
        {
            this->ui->label_pic_b->setText(QString(""));
        }


    }
}


void myWidget::resizeEvent(QResizeEvent *e)
{
    this->mybutton_width = (this->ui->label_br->x() - this->ui->label_bl->x() - this->ui->label_bl->width())/5;
    this->mybutton_height = this->ui->label_bl->height();
    this->mybutton_1_startx = this->ui->label_bl->x() + this->ui->label_bl->width();
    this->mybutton_1_starty = this->ui->label_bl->y();
    this->mybutton_2_startx = this->mybutton_1_startx + this->mybutton_width;
    this->mybutton_2_starty = this->mybutton_1_starty;
    this->mybutton_3_startx = this->mybutton_2_startx + this->mybutton_width;
    this->mybutton_3_starty = this->mybutton_2_starty;
    this->mybutton_4_startx = this->mybutton_3_startx + this->mybutton_width;
    this->mybutton_4_starty = this->mybutton_3_starty;
    this->mybutton_5_startx = this->mybutton_4_startx + this->mybutton_width;
    this->mybutton_5_starty = this->mybutton_4_starty;
}


void myWidget::paintEvent(QPaintEvent *e)
{
    this->chess_board_startx = this->ui->frame_chessboard->x();//��Ϊframe_chessboard���ܱ����أ�������resizeEvent�п����޷������ȷ����ֵ
    this->chess_board_starty = this->ui->frame_chessboard->y();
    this->chess_board_endx = this->ui->frame_chessboard->x() + this->ui->frame_chessboard->width();
    this->chess_board_endy = this->ui->frame_chessboard->y() + this->ui->frame_chessboard->height();
/*
    QImage background(800,600, QImage::Format_RGB32);
    background.fill(qRgb(255, 255, 255));
    background.load(QString(":/other/resource/img/001.jpg"));
    QPainter painter(this);
    //painter.drawImage(QPoint(0, 0), background);
    painter.drawImage(0,0, background,0,0,this->width(),this->height());
*/
    QPainter painter(this);
    painter.drawPixmap(0,0,this->width(),this->height(),QPixmap(game_style[style_number][0]));//������

    if(mygame_stat == 2)//�����Ϸ�Ѿ���ʼ
    {

        GRIDINFO *temp_gridinfo = this->chess_board->grid_info_link;//���̸���Ϣ
        int a = 0 , b = 0;//˫����������
        while(temp_gridinfo)
        {
            if(temp_gridinfo->who == 1)
            {
                a += 1;
            }
            else if(temp_gridinfo->who == 0)
            {
                b += 1;
            }
            temp_gridinfo = temp_gridinfo->next;
        }

        if(a + 9 < b)
        {
            painter.drawPixmap(this->ui->label_pic_a->x(),this->ui->label_pic_a->y(),this->ui->label_pic_a->width(),this->ui->label_pic_a->height(),QPixmap(game_style[style_number][5]));//���ڶ���10�����ӵ����
        }
        else
        {
            painter.drawPixmap(this->ui->label_pic_a->x(),this->ui->label_pic_a->y(),this->ui->label_pic_a->width(),this->ui->label_pic_a->height(),QPixmap(game_style[style_number][3]));//ͷ��A�����������
        }
        if(b + 9 < a)
        {
            painter.drawPixmap(this->ui->label_pic_b->x(),this->ui->label_pic_b->y(),this->ui->label_pic_b->width(),this->ui->label_pic_b->height(),QPixmap(game_style[style_number][6]));
        }
        else
        {
            painter.drawPixmap(this->ui->label_pic_b->x(),this->ui->label_pic_b->y(),this->ui->label_pic_b->width(),this->ui->label_pic_b->height(),QPixmap(game_style[style_number][4]));//ͷ��B�����������
        }

        painter.setPen(QPen(QColor(50,250,50,80), 3, Qt::SolidLine, Qt::RoundCap,Qt::RoundJoin));
        painter.drawRect(this->ui->frame_blood_a->x(),this->ui->frame_blood_a->y(), this->ui->frame_blood_a->width() ,50);
        painter.drawRect(this->ui->frame_blood_b->x(),this->ui->frame_blood_b->y(), this->ui->frame_blood_b->width() ,50);
        painter.setPen(QPen(QColor(50,250,50,70), 2, Qt::SolidLine, Qt::RoundCap,Qt::RoundJoin));
        if(blood_a < 0.2)
        {
            painter.setBrush(Qt::red);
        }
        else if(blood_a < 0.5)
        {
            painter.setBrush(QColor(255,100,0,220));
        }
        else
        {
            painter.setBrush(QColor(50,250,50,175));
        }
        painter.drawRect(this->ui->frame_blood_a->x(),this->ui->frame_blood_a->y(), int(this->ui->frame_blood_a->width()*blood_a) ,this->ui->frame_blood_a->height()-1);
        if(blood_b < 0.2)
        {
            painter.setBrush(Qt::red);
        }
        else if(blood_b < 0.5)
        {
            painter.setBrush(QColor(255,100,0,220));
        }
        else
        {
            painter.setBrush(QColor(50,250,50,175));
        }
        painter.drawRect(this->ui->frame_blood_b->x() + this->ui->frame_blood_b->width() - int(this->ui->frame_blood_b->width()*blood_b),this->ui->frame_blood_b->y(), int(this->ui->frame_blood_b->width()*blood_b)  ,this->ui->frame_blood_b->height()-1);



        if(cue_info[0] != 0)//�������ʾ��Ϣ���������ʾͼ�꣬���ڴ�ʱ�����󻯻���С����ť���������ʾͼ��������ԭλ��BUG������������ɽ��ù���ת�Ƶ������ӵĺ����У�����ȥ�����ǣ�ûʱ������
        {
            unsigned char temp_a,temp_b;
            int temp_c,temp_d,temp_e,temp_f;//ˮƽ����a����ֱ����b���ߴ�c���߾�d�����e�����f
            this->chess_board->getchessboard(temp_a,temp_b,temp_c,temp_d,temp_e,temp_f);
            painter.drawPixmap(chess_board_startx + temp_d + temp_f*cue_info[1],chess_board_starty + temp_d + temp_e*cue_info[2],temp_f,temp_e,QPixmap(":/other/resource/img/xx.png"));
        }

        if(mybutton_1_stat == 0)//0Ϊ��ʼ״̬��1Ϊ�����ͣ�����棬2Ϊ����
        {
            painter.drawPixmap(this->mybutton_1_startx+3,this->mybutton_1_starty+3,this->mybutton_width-6,this->mybutton_height-6,QPixmap(":/other/resource/img/pause.png"));//��ʼ����
        }
        else if(mybutton_1_stat == 1)
        {
            painter.drawPixmap(this->mybutton_1_startx,this->mybutton_1_starty,this->mybutton_width,this->mybutton_height,QPixmap(":/other/resource/img/pause.png"));//��ʼ����
        }
        else if(mybutton_1_stat == 2)
        {
            painter.drawPixmap(this->mybutton_1_startx+5,this->mybutton_1_starty+5,this->mybutton_width-10,this->mybutton_height-10,QPixmap(":/other/resource/img/pause.png"));//��ʼ����
        }

        if(mybutton_2_stat == 0)
        {
            painter.drawPixmap(this->mybutton_2_startx+3,this->mybutton_2_starty+3,this->mybutton_width-6,this->mybutton_height-6,QPixmap(":/other/resource/img/cue.png"));//��ʾ����
        }
        else if(mybutton_2_stat == 1)
        {
            painter.drawPixmap(this->mybutton_2_startx,this->mybutton_2_starty,this->mybutton_width,this->mybutton_height,QPixmap(":/other/resource/img/cue.png"));//
        }
        else if(mybutton_2_stat == 2)
        {
            painter.drawPixmap(this->mybutton_2_startx+5,this->mybutton_2_starty+5,this->mybutton_width-10,this->mybutton_height-10,QPixmap(":/other/resource/img/cue.png"));//
        }

        if(mybutton_3_stat == 0)
        {
            painter.drawPixmap(this->mybutton_3_startx+3,this->mybutton_3_starty+3,this->mybutton_width-6,this->mybutton_height-6,QPixmap(":/other/resource/img/substitution.png"));//
        }
        else if(mybutton_3_stat == 1)
        {
            painter.drawPixmap(this->mybutton_3_startx,this->mybutton_3_starty,this->mybutton_width,this->mybutton_height,QPixmap(":/other/resource/img/substitution.png"));
        }
        else if(mybutton_3_stat == 2)
        {
            painter.drawPixmap(this->mybutton_3_startx+5,this->mybutton_3_starty+5,this->mybutton_width-10,this->mybutton_height-10,QPixmap(":/other/resource/img/substitution.png"));//
        }

        if(mybutton_4_stat == 0)
        {
            painter.drawPixmap(this->mybutton_4_startx+3,this->mybutton_4_starty+3,this->mybutton_width-6,this->mybutton_height-6,QPixmap(":/other/resource/img/back.png"));//
        }
        else if(mybutton_4_stat == 1)
        {
            painter.drawPixmap(this->mybutton_4_startx,this->mybutton_4_starty,this->mybutton_width,this->mybutton_height,QPixmap(":/other/resource/img/back.png"));//
        }
        else if(mybutton_4_stat == 2)
        {
            painter.drawPixmap(this->mybutton_4_startx+5,this->mybutton_4_starty+5,this->mybutton_width-10,this->mybutton_height-10,QPixmap(":/other/resource/img/back.png"));//
        }

        if(mybutton_5_stat == 0)
        {
            painter.drawPixmap(this->mybutton_5_startx+3,this->mybutton_5_starty+3,this->mybutton_width-6,this->mybutton_height-6,QPixmap(":/other/resource/img/craven.png"));//���䰴ť
        }
        else if(mybutton_5_stat == 1)
        {
            painter.drawPixmap(this->mybutton_5_startx,this->mybutton_5_starty,this->mybutton_width,this->mybutton_height,QPixmap(":/other/resource/img/craven.png"));
        }
        else if(mybutton_5_stat == 2)
        {
            painter.drawPixmap(this->mybutton_5_startx+5,this->mybutton_5_starty+5,this->mybutton_width-10,this->mybutton_height-10,QPixmap(":/other/resource/img/craven.png"));//
        }
    }
    else
    {
        if(ai_grade == 1)//�������Եȼ���ͼ��
        {
            painter.drawPixmap(this->width()*5/12,this->height()/14,this->width()/6,this->height()/6,QPixmap(":/other/resource/img/c1.png"));
        }
        else if(ai_grade == 2)
        {
            painter.drawPixmap(this->width()*5/12,this->height()/14,this->width()/6,this->height()/6,QPixmap(":/other/resource/img/c2.png"));
        }
        else if(ai_grade == 3)
        {
            painter.drawPixmap(this->width()*5/12,this->height()/14,this->width()/6,this->height()/6,QPixmap(":/other/resource/img/c3.png"));
        }

        if(mybutton_0_stat == 0)//��ʼ��ť��0Ϊ��ʼ״̬��1Ϊ�����ͣ�����棬2Ϊ����
        {
            painter.drawPixmap(this->width()/4,this->height()/4,this->width()/2,this->height()/2,QPixmap(":/other/resource/img/begin1.png"));
        }
        else if(mybutton_0_stat == 1)
        {
            painter.drawPixmap(this->width()/4,this->height()/4,this->width()/2,this->height()/2,QPixmap(":/other/resource/img/begin2.png"));
        }
        else if(mybutton_0_stat == 2)
        {
            painter.drawPixmap(this->width()/4 + 20,this->height()/4 + 20,this->width()/2 - 40,this->height()/2 - 40,QPixmap(":/other/resource/img/begin2.png"));

        }

        if(mybutton_l1_stat == 0)//������ť��0Ϊ��ʼ״̬��1Ϊ�����ͣ�����棬2Ϊ����
        {
            painter.drawPixmap(this->width()/16 +3,this->height()*4/16 +3,this->width()/8 -6,this->height()/8 -6,QPixmap(":/other/resource/img/b1.png"));
        }
        else if(mybutton_l1_stat == 1)
        {
            painter.drawPixmap(this->width()/16,this->height()*4/16,this->width()/8,this->height()/8,QPixmap(":/other/resource/img/b1.png"));
        }
        else if(mybutton_l1_stat == 2)
        {
            painter.drawPixmap(this->width()/16 +8,this->height()*4/16 +8,this->width()/8 -16,this->height()/8 -16,QPixmap(":/other/resource/img/b1.png"));
        }

        if(mybutton_l2_stat == 0)
        {
            painter.drawPixmap(this->width()/16 +3,this->height()*7/16 +3,this->width()/8 -6,this->height()/8 -6,QPixmap(":/other/resource/img/b2.png"));
        }
        else if(mybutton_l2_stat == 1)
        {
            painter.drawPixmap(this->width()/16,this->height()*7/16,this->width()/8,this->height()/8,QPixmap(":/other/resource/img/b2.png"));
        }
        else if(mybutton_l2_stat == 2)
        {
            painter.drawPixmap(this->width()/16 +8,this->height()*7/16 +8,this->width()/8 -16,this->height()/8 -16,QPixmap(":/other/resource/img/b2.png"));
        }

        if(mybutton_l3_stat == 0)//0Ϊ��ʼ״̬��1Ϊ�����ͣ�����棬2Ϊ����
        {
            painter.drawPixmap(this->width()/16 +3,this->height()*10/16 +3,this->width()/8 -6,this->height()/8 -6,QPixmap(":/other/resource/img/b3.png"));
        }
        else if(mybutton_l3_stat == 1)
        {
            painter.drawPixmap(this->width()/16,this->height()*10/16,this->width()/8,this->height()/8,QPixmap(":/other/resource/img/b3.png"));
        }
        else if(mybutton_l3_stat == 2)
        {
            painter.drawPixmap(this->width()/16 +8,this->height()*10/16 +8,this->width()/8 -16,this->height()/8 -16,QPixmap(":/other/resource/img/b3.png"));
        }

        if(mybutton_r1_stat == 0)//0Ϊ��ʼ״̬��1Ϊ�����ͣ�����棬2Ϊ����
        {
            painter.drawPixmap(this->width()*13/16 +3,this->height()*4/16 +3,this->width()/8 -6,this->height()/8 -6,QPixmap(":/other/resource/img/b4.png"));
        }
        else if(mybutton_r1_stat == 1)
        {
            painter.drawPixmap(this->width()*13/16,this->height()*4/16,this->width()/8,this->height()/8,QPixmap(":/other/resource/img/b4.png"));
        }
        else if(mybutton_r1_stat == 2)
        {
            painter.drawPixmap(this->width()*13/16 +8,this->height()*4/16 +8,this->width()/8 -16,this->height()/8 -16,QPixmap(":/other/resource/img/b4.png"));
        }

        if(mybutton_r2_stat == 0)//0Ϊ��ʼ״̬��1Ϊ�����ͣ�����棬2Ϊ����
        {
            painter.drawPixmap(this->width()*13/16 +3,this->height()*7/16 +3,this->width()/8 -6,this->height()/8 -6,QPixmap(":/other/resource/img/b5.png"));
        }
        else if(mybutton_r2_stat == 1)
        {
            painter.drawPixmap(this->width()*13/16,this->height()*7/16,this->width()/8,this->height()/8,QPixmap(":/other/resource/img/b5.png"));
        }
        else if(mybutton_r2_stat == 2)
        {
            painter.drawPixmap(this->width()*13/16 +8,this->height()*7/16 +8,this->width()/8 -16,this->height()/8 -16,QPixmap(":/other/resource/img/b5.png"));
        }

        if(mybutton_r3_stat == 0)//0Ϊ��ʼ״̬��1Ϊ�����ͣ�����棬2Ϊ����
        {
            painter.drawPixmap(this->width()*13/16 +3,this->height()*10/16 +3,this->width()/8 -6,this->height()/8 -6,QPixmap(":/other/resource/img/b6.png"));
        }
        else if(mybutton_r3_stat == 1)
        {
            painter.drawPixmap(this->width()*13/16,this->height()*10/16,this->width()/8,this->height()/8,QPixmap(":/other/resource/img/b6.png"));
        }
        else if(mybutton_r3_stat == 2)
        {
            painter.drawPixmap(this->width()*13/16 +8,this->height()*10/16 +8,this->width()/8 -16,this->height()/8 -16,QPixmap(":/other/resource/img/b6.png"));
        }


    }
}


void myWidget::mouseMoveEvent(QMouseEvent *e)
{
    //qDebug()<<"mouse move"<<e->x()<<e->y();

    if(this->mygame_stat != 2)
    {
        if(e->x() > this->width()/4 && e->x() < this->width()/4 *3 && e->y() > this->height()/4 && e->y() < this->height()/4 * 3)
        {
            if(mybutton_0_stat == 0)
            {
                this->buttonsound->play(":/other/resource/img/sound.wav");//����������ʱ��ʱ����
                mybutton_0_stat = 1;
                //qDebug()<<"mybutton_0";
                update();
            }
        }
        else
        {
            if(mybutton_0_stat == 1)
            {
                //this->buttonsound->stop();
                mybutton_0_stat = 0;
                update();
            }
        }

/*
        if(e->x() > this->width()/16 && e->x() < this->width()/16 *3 && e->y() > this->height()/16 *4 && e->y() < this->height()/16 * 6)
        {
            if(mybutton_l1_stat == 0)
            {
                mybutton_l1_stat = 1;
                update();
            }
        }
        else
        {
            if(mybutton_l1_stat == 1)
            {
                mybutton_l1_stat = 0;
                update();
            }
        }

        if(e->x() > this->width()/16 && e->x() < this->width()/16 *3 && e->y() > this->height()/16 *7 && e->y() < this->height()/16 * 9)
        {
            if(mybutton_l2_stat == 0)
            {
                mybutton_l2_stat = 1;
                update();
            }
        }
        else
        {
            if(mybutton_l2_stat == 1)
            {
                mybutton_l2_stat = 0;
                update();
            }
        }

        if(e->x() > this->width()/16 && e->x() < this->width()/16 *3 && e->y() > this->height()/16 *10 && e->y() < this->height()/16 * 12)
        {
            if(mybutton_l3_stat == 0)
            {
                mybutton_l3_stat = 1;
                update();
            }
        }
        else
        {
            if(mybutton_l3_stat == 1)
            {
                mybutton_l3_stat = 0;
                update();
            }
        }

        if(e->x() > this->width()*13/16 && e->x() < this->width()*15/16 && e->y() > this->height()/16 *4 && e->y() < this->height()/16 * 6)
        {
            if(mybutton_r1_stat == 0)
            {
                mybutton_r1_stat = 1;
                update();
            }
        }
        else
        {
            if(mybutton_r1_stat == 1)
            {
                mybutton_r1_stat = 0;
                update();
            }
        }

        if(e->x() > this->width()*13/16 && e->x() < this->width()*15/16 && e->y() > this->height()/16 *7 && e->y() < this->height()/16 * 9)
        {
            if(mybutton_r2_stat == 0)
            {
                mybutton_r2_stat = 1;
                update();
            }
        }
        else
        {
            if(mybutton_r2_stat == 1)
            {
                mybutton_r2_stat = 0;
                update();
            }
        }

        if(e->x() > this->width()*13/16 && e->x() < this->width()*15/16 && e->y() > this->height()/16 *10 && e->y() < this->height()/16 * 12)
        {
            if(mybutton_r3_stat == 0)
            {
                mybutton_r3_stat = 1;
                update();
            }
        }
        else
        {
            if(mybutton_r3_stat == 1)
            {
                mybutton_r3_stat = 0;
                update();
            }
        }
*/


    }
    else
    {
        if(e->x() > this->mybutton_1_startx && e->x() < this->mybutton_1_startx + this->mybutton_width && e->y() > this->mybutton_1_starty && e->y() < this->mybutton_1_starty + this->mybutton_height)
        {
            if(mybutton_1_stat == 0)
            {
                mybutton_1_stat = 1;
                //qDebug()<<"mybutton_1";
                update();
            }
        }
        else
        {
            mybutton_1_stat = 0;
        }

        if(e->x() > this->mybutton_2_startx && e->x() < this->mybutton_2_startx + this->mybutton_width && e->y() > this->mybutton_2_starty && e->y() < this->mybutton_2_starty + this->mybutton_height)
        {
            if(mybutton_2_stat == 0)
            {
                mybutton_2_stat = 1;
                //qDebug()<<"mybutton_2";
                update();
            }
        }
        else
        {
            mybutton_2_stat = 0;
        }

        if(e->x() > this->mybutton_3_startx && e->x() < this->mybutton_3_startx + this->mybutton_width && e->y() > this->mybutton_3_starty && e->y() < this->mybutton_3_starty + this->mybutton_height)
        {
            if(mybutton_3_stat == 0)
            {
                mybutton_3_stat = 1;
                //qDebug()<<"mybutton_3";
                update();
            }
        }
        else
        {
            mybutton_3_stat = 0;
        }

        if(e->x() > this->mybutton_4_startx && e->x() < this->mybutton_4_startx + this->mybutton_width && e->y() > this->mybutton_4_starty && e->y() < this->mybutton_4_starty + this->mybutton_height)
        {
            if(mybutton_4_stat == 0)
            {
                mybutton_4_stat = 1;
                //qDebug()<<"mybutton_4";
                update();
            }
        }
        else
        {
            mybutton_4_stat = 0;
        }

        if(e->x() > this->mybutton_5_startx && e->x() < this->mybutton_5_startx + this->mybutton_width && e->y() > this->mybutton_5_starty && e->y() < this->mybutton_5_starty + this->mybutton_height)
        {
            if(mybutton_5_stat == 0)
            {
                mybutton_5_stat = 1;
                //qDebug()<<"mybutton_5";
                update();
            }
        }
        else
        {
            mybutton_5_stat = 0;
        }
    }
}

void myWidget::mousePressEvent(QMouseEvent *e)
{
    if(this->mygame_stat != 2)
    {
        if(e->x() > this->width()/4 && e->x() < this->width()/4 *3 && e->y() > this->height()/4 && e->y() < this->height()/4 * 3)//��������������
        {
            mybutton_0_stat = 2;
            //qDebug()<<"mybutton_0";
        }

        if(e->x() > this->width()/16 && e->x() < this->width()/16 *3 && e->y() > this->height()/16 *4 && e->y() < this->height()/16 * 6)
        {
            mybutton_l1_stat = 2;
            mybutton_l2_stat = 0;
            mybutton_l3_stat = 0;
            style_number = (style_number +1)%3;
        }

        if(e->x() > this->width()/16 && e->x() < this->width()/16 *3 && e->y() > this->height()/16 *7 && e->y() < this->height()/16 * 9)
        {
            mybutton_l1_stat = 0;
            mybutton_l2_stat = 2;
            mybutton_l3_stat = 0;
            style_number = (style_number +1)%3;
        }

        if(e->x() > this->width()/16 && e->x() < this->width()/16 *3 && e->y() > this->height()/16 *10 && e->y() < this->height()/16 * 12)
        {
            mybutton_l1_stat = 0;
            mybutton_l2_stat = 0;
            mybutton_l3_stat = 2;
            style_number = (style_number +1)%3;
        }

        if(e->x() > this->width()*13/16 && e->x() < this->width()*15/16 && e->y() > this->height()/16 *4 && e->y() < this->height()/16 * 6)
        {
            mybutton_r1_stat = 2;
            mybutton_r2_stat = 0;
            mybutton_r3_stat = 0;
            ai_grade = 1;
        }

        if(e->x() > this->width()*13/16 && e->x() < this->width()*15/16 && e->y() > this->height()/16 *7 && e->y() < this->height()/16 * 9)
        {
            mybutton_r1_stat = 0;
            mybutton_r2_stat = 2;
            mybutton_r3_stat = 0;
            ai_grade = 2;
        }

        if(e->x() > this->width()*13/16 && e->x() < this->width()*15/16 && e->y() > this->height()/16 *10 && e->y() < this->height()/16 * 12)
        {
            mybutton_r1_stat = 0;
            mybutton_r2_stat = 0;
            mybutton_r3_stat = 2;
            ai_grade = 3;
        }


    }
    else
    {
        if(e->x() > this->mybutton_1_startx && e->x() < this->mybutton_1_startx + this->mybutton_width && e->y() > this->mybutton_1_starty && e->y() < this->mybutton_1_starty + this->mybutton_height)
        {
            mybutton_1_stat = 2;
            //qDebug()<<"Press_label_pause";

        }
        else if(e->x() > this->mybutton_2_startx && e->x() < this->mybutton_2_startx + this->mybutton_width && e->y() > this->mybutton_2_starty && e->y() < this->mybutton_2_starty + this->mybutton_height)
        {
            mybutton_2_stat = 2;
            //qDebug()<<"Press_label_cue";

        }
        else if(e->x() > this->mybutton_3_startx && e->x() < this->mybutton_3_startx + this->mybutton_width && e->y() > this->mybutton_3_starty && e->y() < this->mybutton_3_starty + this->mybutton_height)
        {
            mybutton_3_stat = 2;
            //qDebug()<<"Press_label_computer";

        }
        else if(e->x() > this->mybutton_4_startx && e->x() < this->mybutton_4_startx + this->mybutton_width && e->y() > this->mybutton_4_starty && e->y() < this->mybutton_4_starty + this->mybutton_height)
        {
            mybutton_4_stat = 2;
            //qDebug()<<"Press_label_penance";

        }
        else if(e->x() > this->mybutton_5_startx && e->x() < this->mybutton_5_startx + this->mybutton_width && e->y() > this->mybutton_5_starty && e->y() < this->mybutton_5_starty + this->mybutton_height)
        {
            mybutton_5_stat = 2;
            //qDebug()<<"Press_label_mybutton_5";

        }

    }
    update();
}

void myWidget::mouseReleaseEvent(QMouseEvent *e)
{
    if(mygame_stat == 2)//��Ϸ״̬��0Ϊ��ʼ״̬��1Ϊ��ͣ��2Ϊ��ʼ
    {
        if(e->x() > chess_board_startx && e->y() > chess_board_starty && e->x() < chess_board_endx && e->y() < chess_board_endy)//��������������
        {

            //int myself = this->who_control;//�Լ��Ĵ���
            //int adversary = (this->who_control + 1)%2;//���ֵĴ���
            GRIDINFO *nonce_gridinfo = this->chess_board->grid_info_link;//ѡ�����̸���Ϣ
            unsigned char i,j;//i���Ӵ�ֱ���,j����ˮƽ���
            unsigned char temp_a,temp_b;//ˮƽ����a����ֱ����b��
            int temp_c,temp_d,temp_e,temp_f;//�ߴ�c���߾�d�����e�����f
            this->chess_board->getchessboard(temp_a,temp_b,temp_c,temp_d,temp_e,temp_f);
            //int max_xy;
            //max_xy = temp_a>temp_b?temp_a:temp_b;
            for(i=0;i<temp_a;i++)
            {
                if(e->x() > (chess_board_startx + temp_d + temp_f*i) && e->x() < (chess_board_startx + temp_d + temp_f*(i+1)))
                {
                    for(j=0;j<temp_b;j++)
                    {
                        if(e->y() > (chess_board_starty + temp_d + temp_e*j) && e->y() < (chess_board_starty + temp_d + temp_e*(j+1)))
                        {
                            while(nonce_gridinfo->x != i || nonce_gridinfo->y != j)//�ƶ�����ָ�뵽�ø�
                            {
                                nonce_gridinfo = nonce_gridinfo->next;
                            }
                            if(nonce_gridinfo->who == -1)//����ø��ǿո�,Ϊ����
                            {
                                kill_chess(*this , nonce_gridinfo , true);//����Ƿ�������ӣ��ԶԷ����ӣ�����ò�����Ϣ���ѿ���Ȩ���Է�
                            }
                            else
                            {

                            }
                            //qDebug()<<"gridinfo"<<nonce_gridinfo->x<<nonce_gridinfo->y;
                            break;
                        }
                    }
                    break;
                }
            }
            //qDebug()<<"in chessboard"<<j<<i;
        }
        else if(e->x() > this->mybutton_1_startx && e->x() < this->mybutton_1_startx + this->mybutton_width && e->y() > this->mybutton_1_starty && e->y() < this->mybutton_1_starty + this->mybutton_height)
        {
            mybutton_1_stat = 1;
            mygame_stat = 1;
            game_hide(*this);
            //qDebug()<<"Press_label_pause";
            update();
        }
        else if(e->x() > this->mybutton_2_startx && e->x() < this->mybutton_2_startx + this->mybutton_width && e->y() > this->mybutton_2_starty && e->y() < this->mybutton_2_starty + this->mybutton_height)
        {
            mybutton_2_stat = 1;
            ai_cue(*this , false);
            //qDebug()<<"Press_label_cue";
            update();
        }
        else if(e->x() > this->mybutton_3_startx && e->x() < this->mybutton_3_startx + this->mybutton_width && e->y() > this->mybutton_3_starty && e->y() < this->mybutton_3_starty + this->mybutton_height)
        {
            mybutton_3_stat = 1;
            if(ai_stat == 3)//���ai�ǹرյģ���ô���Լ�����Ϊ�����Զ�����
            {
                ai_stat = who_control;
            }
            else if(ai_stat == 2)//���ai��˫�˾��Զ����壬��ô���Լ���Ϊ�ֶ����壬�Է�����Ϊ�����Զ�����
            {
                ai_stat = (who_control + 1)%2;
            }
            else if(ai_stat == (who_control + 1)%2)
            {
                ai_stat = 2;
            }
            else
            {
                ai_stat = 3;
            }

            //qDebug()<<"Press_label_ai"<<ai_stat;
            update();
        }
        else if(e->x() > this->mybutton_4_startx && e->x() < this->mybutton_4_startx + this->mybutton_width && e->y() > this->mybutton_4_starty && e->y() < this->mybutton_4_starty + this->mybutton_height)
        {
            mybutton_4_stat = 1;
            back_step(*this);//����һ��������Ҫ�ٻ���һ���������Լ�ӵ�п���Ȩ
            back_step(*this);
            //qDebug()<<"Press_label_penance";
            update();
        }
        else if(e->x() > this->mybutton_5_startx && e->x() < this->mybutton_5_startx + this->mybutton_width && e->y() > this->mybutton_5_starty && e->y() < this->mybutton_5_starty + this->mybutton_height)
        {
            mybutton_5_stat = 1;
            QMessageBox::information(this,"You win","Other player give up");
            this->mygame_stat = 0;//��Ϸ״̬��0Ϊ��ʼ״̬��1Ϊ��ͣ��2Ϊ��ʼ
            game_reset(*this);
            //qDebug()<<"Press_label_mybutton_5";
            update();
        }
    }
    else
    {
        if(e->x() > this->width()/4 && e->x() < this->width()/4 *3 && e->y() > this->height()/4 && e->y() < this->height()/4 * 3)//��������������
        {
            game_show(*this);
            mygame_stat = 2;
        }
        mybutton_0_stat = 0;
        update();
    }

}


