#include "chessboard.h"
//#include <QDebug>

unsigned char style_number = 0;//��������
const char *game_style[3][7];//[*][0]Ϊ����ͼƬ��[*][1]Ϊa�����ӣ�[*][2]Ϊb�����ӣ�[*][3]Ϊa��ͷ��[*][4]Ϊb��ͷ��[*][5]Ϊa��ȷ�����ͷ��[*][6]Ϊb��ȷ�����ͷ��

const char *backgrand_0 = ":/other/resource/img/1.jpg";
const char *chess_0_a = ":/other/resource/img/bc.png";
const char *chess_0_b = ":/other/resource/img/wc.png";
const char *pic_0_a = ":/other/resource/img/m1.png";
const char *pic_0_b = ":/other/resource/img/m2.png";
const char *pic_0_a_alarm = ":/other/resource/img/m3.png";
const char *pic_0_b_alarm = ":/other/resource/img/m3.png";

const char *backgrand_1 = ":/other/resource/img/2.jpg";
const char *chess_1_a = ":/other/resource/img/q1.png";
const char *chess_1_b = ":/other/resource/img/q2.png";
const char *pic_1_a = ":/other/resource/img/q1.png";
const char *pic_1_b = ":/other/resource/img/q2.png";
const char *pic_1_a_alarm = ":/other/resource/img/q1.png";
const char *pic_1_b_alarm = ":/other/resource/img/q2.png";

const char *backgrand_2 = ":/other/resource/img/3.jpg";
const char *chess_2_a = ":/other/resource/img/xa.png";
const char *chess_2_b = ":/other/resource/img/xb.png";
const char *pic_2_a = ":/other/resource/img/x1.png";
const char *pic_2_b = ":/other/resource/img/x2.png";
const char *pic_2_a_alarm = ":/other/resource/img/x3.png";
const char *pic_2_b_alarm = ":/other/resource/img/x4.png";

chessboard::chessboard(QWidget *parent) :QWidget(parent)
{
    //setAttribute(Qt::WA_StaticContents);
    horizontal_grid=10;//ˮƽ����
    vertical_grid=10;//��ֱ����
    penwidth = 1;//���ߵĴ�ϸ
    margin = 3;//�߿���룬Ҳ��ˮƽ�ߺʹ�ֱ�ߵ���ʼ����
    step_info_link = NULL;
}

chessboard::~chessboard()
{
}

void chessboard::setchessboard(unsigned char x,unsigned char y,int penwidth,int margin)
{
    GRIDINFO *pf;
    unsigned char i,j;

    this->horizontal_grid = x;
    this->vertical_grid = y;
    this->penwidth = penwidth;//�����ߵĴ�ϸ
    this->margin = margin;//�߿���룬��ˮƽ�ߺʹ�ֱ�ߵ���ʼ����

    for(i=0;i<x;i++)//��������������ÿһ�����Ϣ
    {
        for(j=0;j<y;j++)
        {

            GRIDINFO *p;
            p = new GRIDINFO;
            p->x = j;
            p->y = i;
            p->who = -1;

            if((p->x == (x-1)/2 && p->y == (y-1)/2)||(p->x == (x-1)/2 +1 && p->y == (y-1)/2 +1))
            {
                p->who = 1;
            }
            else if((p->x == (x-1)/2 && p->y == (y-1)/2 +1)||(p->x == (x-1)/2 +1 && p->y == (y-1)/2))
            {
                p->who = 0;
            }
            //p->begin_x = margin + i*spacing_column;
            //p->begin_y = margin + j*spacing_line;
            p->next = NULL;
            if(i==0&&j==0)
            {
                grid_info_link = pf = p;
            }
            else
            {
                pf->next = p;
                pf = p;
            }
        }
    }
}

void chessboard::getchessboard(unsigned char &x,unsigned char &y,int &penwidth,int &margin,int &spacing_line,int &spacing_column)
{
    x = this->horizontal_grid;
    y = this->vertical_grid;
    penwidth = this->penwidth;
    margin = this->margin;
    spacing_line = this->spacing_line;//ˮƽ�߼�࣬��ÿ����ĸ߶�
    spacing_column = this->spacing_column;//��ֱ�߼�࣬��ÿ����Ŀ���
}

void chessboard::paintEvent(QPaintEvent *e)
{
    unsigned char i;
    GRIDINFO *temp_gridinfo = grid_info_link;
    int width = this->width() - margin*2;//���̿�
    int height = this->height() - margin*2;//���̸�
    int line_more = width%vertical_grid;//ˮƽ�߶��೤��
    int column_more = height%horizontal_grid;//��ֱ�߶��೤��
    int line_over = margin + width - line_more;//ˮƽ���յ�����
    int column_over = margin + height - column_more;//��ֱ���յ�����

    QPainter  paint(this);
    QBrush brush(QColor(4,109,251,150));
    QPen pen(brush,this->penwidth + (this->width() + this->height())/800);
    paint.setPen(pen);

    spacing_line = height/horizontal_grid;//ˮƽ�߼�࣬��ÿ����ĸ߶�
    spacing_column = width/vertical_grid;//��ֱ�߼�࣬��ÿ����Ŀ���
    for(i=0;i<=horizontal_grid;i++)//��ˮƽ��
    {
        paint.drawLine(margin , margin + i*spacing_line , line_over , margin + i*spacing_line);
    }
    for(i=0;i<=vertical_grid;i++)//����ֱ��
    {
        paint.drawLine(margin + i*spacing_column , margin , margin + i*spacing_column, column_over);
    }

    while(temp_gridinfo)//����������
    {
        if(temp_gridinfo->who == 1)
        {
            paint.drawPixmap(margin + spacing_column*temp_gridinfo->x ,margin + spacing_line*temp_gridinfo->y , spacing_column, spacing_line,QPixmap(game_style[style_number][1]));//
        }
        else if(temp_gridinfo->who == 0)
        {
            paint.drawPixmap(margin + spacing_column*temp_gridinfo->x ,margin + spacing_line*temp_gridinfo->y , spacing_column, spacing_line,QPixmap(game_style[style_number][2]));
        }
        temp_gridinfo = temp_gridinfo->next;
    }

/*
    while(grid_info_link)
    {
        qDebug()<<"x ="<<grid_info_link->x<<" , y = "<<grid_info_link->y;
        grid_info_link = grid_info_link->next;
    }
*/

}


