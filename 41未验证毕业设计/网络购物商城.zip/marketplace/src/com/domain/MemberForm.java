package com.domain;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import javax.servlet.http.HttpServletRequest;

//��Ա����bean
public class MemberForm
    extends ActionForm {
  private Integer age = Integer.valueOf("-1"); //����
  private String email = ""; //�����ʼ�
  private Integer id = Integer.valueOf("-1"); //���ݿ���ˮ��
  private String username = ""; //��Ա����
  private String password1 = ""; //��Ա����
  private String profession = ""; //��Աְҵ
  private String question = ""; //�һ����������
  private String reallyName = ""; //��ʵ����
  private String result = ""; //�һ�����Ĵ�
  public MemberForm() {}
  public Integer getAge() {
    return age;
  }

  public void setAge(Integer age) {
    this.age = age;
  }

  public void setResult(String result) {
    this.result = result;
  }

  public void setReallyName(String reallyName) {
    this.reallyName = reallyName;
  }

  public void setQuestion(String question) {
    this.question = question;
  }

  public void setProfession(String profession) {
    this.profession = profession;
  }

  public void setPassword(String password) {
    this.password1 = password;
  }

  public void setName(String name) {
    this.username = name;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getEmail() {
    return email;
  }

  public Integer getId() {
    return id;
  }

  public String getName() {
    return username;
  }

  public String getPassword() {
    return password1;
  }

  public String getProfession() {
    return profession;
  }

  public String getQuestion() {
    return question;
  }

  public String getReallyName() {
    return reallyName;
  }

  public String getResult() {
    return result;
  }

  public ActionErrors validate(ActionMapping actionMapping,
                               HttpServletRequest httpServletRequest) {
    /** @todo: finish this method, this is just the skeleton.*/
    return null;
  }

  public void reset(ActionMapping actionMapping,
                    HttpServletRequest servletRequest) {
  }
}
