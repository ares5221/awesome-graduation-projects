package com.dao;

import java.sql.*;
import java.util.*;

import com.tool.JDBConnection;
import com.tool.FinalConstants;
import com.domain.GoodsForm;

//����Ʒ���Ĳ���
public class GoodsDao {
  private Connection connection = null; //�������ӵĶ���
  private PreparedStatement ps = null; //����Ԥ׼���Ķ���
  private JDBConnection jdbc = null; //�������ݿ����Ӷ���
  public GoodsDao() {
    jdbc = new JDBConnection();
    connection = jdbc.connection; //���ù��췽��ȡ�����ݿ�����
  }

//������Ʒ��ID�޸Ĺ�����Ʒ������
  public void updateGoodsNumber(int number, Integer id) {
    try {
      ps = connection.prepareStatement(FinalConstants.goods_updateNumber);
      ps.setInt(1, number);
      ps.setInt(2, id.intValue());
      ps.executeUpdate();
      ps.close();
    }
    catch (SQLException ex) {
    }

  }

//�����ؼۼ۸�ķ���
  public void managerPrice(GoodsForm form) {
    try {
      ps = connection.prepareStatement(FinalConstants.goods_updatePirce);
      ps.setFloat(1, form.getFreePrice().floatValue());
      ps.setInt(2, form.getMark().intValue());
      ps.setInt(3, form.getId().intValue());
      ps.executeUpdate();
      ps.close();
    }
    catch (SQLException ex) {
    }
  }

  //����Ʒ���Ƿ��ؼ�Ϊ������ѯ��Ϣ
  public List selectMark(Integer mark) {
    List list = new ArrayList();
    GoodsForm goods = null;
    try {
      ps = connection.prepareStatement(FinalConstants.goods_selectMark);
      ps.setInt(1, mark.intValue());
      ResultSet rs = ps.executeQuery();
      while (rs.next()) {
        goods = new GoodsForm();
        goods.setId(Integer.valueOf(rs.getString(1)));
        goods.setBig(Integer.valueOf(rs.getString(2)));
        goods.setSmall(Integer.valueOf(rs.getString(3)));
        goods.setName(rs.getString(4));
        goods.setFrom(rs.getString(5));
        goods.setIntroduce(rs.getString(6));
        goods.setCreaTime(rs.getString(7));
        goods.setNowPrice(Float.valueOf(rs.getString(8)));
        goods.setFreePrice(Float.valueOf(rs.getString(9)));
        goods.setNumber(Integer.valueOf(rs.getString(10)));
        goods.setPriture(rs.getString(11));
        goods.setMark(Integer.valueOf(rs.getString(12)));
        list.add(goods);
      }
    }
    catch (SQLException ex) {
    }
    return list;
  }

//���Ӳ���
  public void insertGoods(GoodsForm form) {
    try {
      ps = connection.prepareStatement(FinalConstants.goods_insert);
      ps.setInt(1, form.getBig().intValue());
      ps.setInt(2, form.getSmall().intValue());
      ps.setString(3, form.getName());
      ps.setString(4, form.getFrom());
      ps.setString(5, form.getIntroduce());
      ps.setFloat(6, form.getNowPrice().floatValue());
      ps.setFloat(7, form.getFreePrice().floatValue());
      ps.setInt(8, 0);
      ps.setString(9, form.getPicture());
      ps.setInt(10, 0);
      ps.executeUpdate();
      ps.close();
    }
    catch (SQLException ex) {
    }
  }

//����Ʒ���Ϊ����ɾ����Ϣ
  public void deleteGoods(Integer id) {
    try {
      ps = connection.prepareStatement(FinalConstants.goods_delete);
      ps.setInt(1, id.intValue());
      ps.executeUpdate();
      ps.close();
    }
    catch (SQLException ex) {
    }
  }

//����Ʒ�ı��Ϊ������ѯ��Ϣ
  public GoodsForm selectOneGoods(Integer id) {
    GoodsForm goods = null;
    try {
      ps = connection.prepareStatement(FinalConstants.goods_selectOne);
      ps.setInt(1, id.intValue());
      ResultSet rs = ps.executeQuery();
      while (rs.next()) {
        goods = new GoodsForm();
        goods.setId(Integer.valueOf(rs.getString(1)));
        goods.setBig(Integer.valueOf(rs.getString(2)));
        goods.setSmall(Integer.valueOf(rs.getString(3)));
        goods.setName(rs.getString(4));
        goods.setFrom(rs.getString(5));
        goods.setIntroduce(rs.getString(6));
        goods.setCreaTime(rs.getString(7));
        goods.setNowPrice(Float.valueOf(rs.getString(8)));
        goods.setFreePrice(Float.valueOf(rs.getString(9)));
        goods.setNumber(Integer.valueOf(rs.getString(10)));
        goods.setPriture(rs.getString(11));
        goods.setMark(Integer.valueOf(rs.getString(12)));
      }
    }
    catch (SQLException ex) {
    }
    return goods;
  }

  //����Ʒ��С���ı��Ϊ������ѯ��Ϣ
  public List selectSmall(Integer small) {
    List list = new ArrayList();
    GoodsForm goods = null;
    try {
      ps = connection.prepareStatement(FinalConstants.goods_selectSmall);
      ps.setInt(1, small.intValue());
      ResultSet rs = ps.executeQuery();
      while (rs.next()) {
        goods = new GoodsForm();
        goods.setId(Integer.valueOf(rs.getString(1)));
        goods.setBig(Integer.valueOf(rs.getString(2)));
        goods.setSmall(Integer.valueOf(rs.getString(3)));
        goods.setName(rs.getString(4));
        goods.setFrom(rs.getString(5));
        goods.setIntroduce(rs.getString(6));
        goods.setCreaTime(rs.getString(7));
        goods.setNowPrice(Float.valueOf(rs.getString(8)));
        goods.setFreePrice(Float.valueOf(rs.getString(9)));
        goods.setNumber(Integer.valueOf(rs.getString(10)));
        goods.setPriture(rs.getString(11));
        goods.setMark(Integer.valueOf(rs.getString(12)));
        list.add(goods);
      }
    }
    catch (SQLException ex) {
    }
    return list;
  }

  //����Ʒ�Ĵ����ı��Ϊ������ѯ��Ϣ
  public List selectBig(Integer big) {
    List list = new ArrayList();
    GoodsForm goods = null;
    try {
      ps = connection.prepareStatement(FinalConstants.goods_selectBig);
      ps.setInt(1, big.intValue());
      ResultSet rs = ps.executeQuery();
      while (rs.next()) {
        goods = new GoodsForm();
        goods.setId(Integer.valueOf(rs.getString(1)));
        goods.setBig(Integer.valueOf(rs.getString(2)));
        goods.setSmall(Integer.valueOf(rs.getString(3)));
        goods.setName(rs.getString(4));
        goods.setFrom(rs.getString(5));
        goods.setIntroduce(rs.getString(6));
        goods.setCreaTime(rs.getString(7));
        goods.setNowPrice(Float.valueOf(rs.getString(8)));
        goods.setFreePrice(Float.valueOf(rs.getString(9)));
        goods.setNumber(Integer.valueOf(rs.getString(10)));
        goods.setPriture(rs.getString(11));
        goods.setMark(Integer.valueOf(rs.getString(12)));
        list.add(goods);
      }
    }
    catch (SQLException ex) {
    }
    return list;
  }

//ȫ����ѯ
  public List selectGoods() {
    List list = new ArrayList();
    GoodsForm goods = null;
    try {
      ps = connection.prepareStatement(FinalConstants.goods_select);
      ResultSet rs = ps.executeQuery();
      while (rs.next()) {
        goods = new GoodsForm();
        goods.setId(Integer.valueOf(rs.getString(1)));
        goods.setBig(Integer.valueOf(rs.getString(2)));
        goods.setSmall(Integer.valueOf(rs.getString(3)));
        goods.setName(rs.getString(4));
        goods.setFrom(rs.getString(5));
        goods.setIntroduce(rs.getString(6));
        goods.setCreaTime(rs.getString(7));
        goods.setNowPrice(Float.valueOf(rs.getString(8)));
        goods.setFreePrice(Float.valueOf(rs.getString(9)));
        goods.setNumber(Integer.valueOf(rs.getString(10)));
        goods.setPriture(rs.getString(11));
        goods.setMark(Integer.valueOf(rs.getString(12)));
        list.add(goods);
      }
    }
    catch (SQLException ex) {
    }
    return list;
  }

  //ȫ����ѯ
  public List selectGoodsNumber() {
    List list = new ArrayList();
    GoodsForm goods = null;
    try {
      ps = connection.prepareStatement(FinalConstants.goods_selectNumber);
      ResultSet rs = ps.executeQuery();
      while (rs.next()) {
        goods = new GoodsForm();
        goods.setId(Integer.valueOf(rs.getString(1)));
        goods.setBig(Integer.valueOf(rs.getString(2)));
        goods.setSmall(Integer.valueOf(rs.getString(3)));
        goods.setName(rs.getString(4));
        goods.setFrom(rs.getString(5));
        goods.setIntroduce(rs.getString(6));
        goods.setCreaTime(rs.getString(7));
        goods.setNowPrice(Float.valueOf(rs.getString(8)));
        goods.setFreePrice(Float.valueOf(rs.getString(9)));
        goods.setNumber(Integer.valueOf(rs.getString(10)));
        goods.setPriture(rs.getString(11));
        goods.setMark(Integer.valueOf(rs.getString(12)));
        list.add(goods);
      }
    }
    catch (SQLException ex) {
    }
    return list;
  }
  public int UpdateGoods(GoodsForm form){
	  int i=0;
	  try {
	      ps = connection.prepareStatement(FinalConstants.goods_update);
	      ps.setString(1, form.getName());
	      ps.setInt(2, form.getBig());
	      ps.setInt(3, form.getSmall());
	      ps.setInt(4, form.getId());
	      i=ps.executeUpdate();
	      ps.close();
	    }
	    catch (SQLException ex) {
	    }
	    return i;
  }

}
