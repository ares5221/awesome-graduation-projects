package com.Listener;
import java.util.Vector;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
public class CheckUser {
	private static MyListener listener=new MyListener();
	public static boolean check(String id,HttpServletRequest request){
		listener.setId(id);
		boolean mark=true;
		Vector vector=listener.getVc();
		if(vector.contains(id)){
			HttpSession session=request.getSession();
			session.removeAttribute("addlogoutuser");
			mark=false;
		}
		else{
			HttpSession session=request.getSession();
			session.setAttribute("addlogoutuser", listener);
			mark=true;
		}
		return mark;
	}
}
