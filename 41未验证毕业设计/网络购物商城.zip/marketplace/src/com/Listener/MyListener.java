package com.Listener;
import java.util.Vector;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
public class MyListener implements HttpSessionBindingListener{
	private String id;
	private Vector vc=new Vector();
	public MyListener(){
		id="";
	}
	public void valueBound(HttpSessionBindingEvent arg0) {
		// TODO �Զ����ɷ������
		HttpSession session=arg0.getSession();
		ServletContext sct=session.getServletContext();
		vc=(Vector)sct.getAttribute("userlist");
		if(vc==null||vc.size()==0){
			vc=new Vector();
			vc.add(id);
		}
		else{
			if(!vc.contains(id)){
				vc.add(id);
			}
		}
		sct.setAttribute("userlist", vc);
	}
	public void valueUnbound(HttpSessionBindingEvent arg0) {
		// TODO �Զ����ɷ������
		if(id!=null||id!=""){
			HttpSession session=arg0.getSession();
			ServletContext sct=session.getServletContext();
			vc=(Vector)sct.getAttribute("userlist");
			if(vc!=null||vc.size()!=0)
				vc.removeElement(id);
			sct.setAttribute("userlist", vc);
		}
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Vector getVc() {
		return vc;
	}

	public void setVc(Vector vc) {
		this.vc = vc;
	}
}
