package action;

import java.io.IOException;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import orm.Tcatelog;
import orm.Tdongman;

import dao.DB;


public class dongman_servlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException, IOException 
	{
        String type=req.getParameter("type");
		
		
		if(type.endsWith("dongmanAdd"))
		{
			dongmanAdd(req, res);
		}
		if(type.endsWith("dongmanMana"))
		{
			dongmanMana(req, res);
		}
		if(type.endsWith("dongmanDel"))
		{
			dongmanDel(req, res);
		}
		
		if(type.endsWith("dongmanByCatelog"))
		{
			dongmanByCatelog(req, res);
		}
		if(type.endsWith("dongmanSearch"))
		{
			dongmanSearch(req, res);
		}
		if(type.endsWith("dongmanDetailQian"))
		{
			dongmanDetailQian(req, res);
		}
	}
	
	
	public void dongmanAdd(HttpServletRequest req,HttpServletResponse res)
	{
		String id=String.valueOf(new Date().getTime());
		String catelog_id=req.getParameter("catelog_id").trim();
		String name=req.getParameter("name").trim();
		String fujian=req.getParameter("fujian").trim();
		
		String fujianYuanshiming=req.getParameter("fujianYuanshiming").trim();
		String zhujiao=req.getParameter("zhujiao").trim();
		String shijian=new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date());
		
		String sql="insert into t_dongman(id,catelog_id,name,fujian,fujianYuanshiming,zhujiao,shijian) values(?,?,?,?,?,?,?)";
		Object[] params={id,catelog_id,name,fujian,fujianYuanshiming,zhujiao,shijian};
		DB mydb=new DB();
		mydb.doPstm(sql, params);
		mydb.closed();
		
		req.setAttribute("msg", "�����ɹ�");
		
        String targetURL = "/common/msg.jsp";
		dispatch(targetURL, req, res);
        
	}
	
	
	public void dongmanDel(HttpServletRequest req,HttpServletResponse res)
	{
		String sql="delete from t_dongman where id="+req.getParameter("id");
		Object[] params={};
		DB mydb=new DB();
		mydb.doPstm(sql, params);
		mydb.closed();
		
        req.setAttribute("msg", "�����ɹ�");
		
        String targetURL = "/common/msg.jsp";
		dispatch(targetURL, req, res);
	}

	public void dongmanMana(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		List dongmanList=new ArrayList();
		String sql="select * from t_dongman order by shijian desc";
		Object[] params={};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				Tdongman dongman=new Tdongman();
				
				dongman.setId(rs.getString("id"));
				dongman.setCatelog_id(rs.getString("catelog_id"));
				dongman.setName(rs.getString("name"));
				dongman.setFujian(rs.getString("fujian"));
				
				dongman.setFujianYuanshiming(rs.getString("fujianYuanshiming"));
				dongman.setzhujiao(rs.getString("zhujiao"));
				dongman.setShijian(rs.getString("shijian"));
				
				dongmanList.add(dongman);
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		
		req.setAttribute("dongmanList", dongmanList);
		req.getRequestDispatcher("admin/dongman/dongmanMana.jsp").forward(req, res);
	}
	
	
	public void dongmanByCatelog(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
	String catelog_id=req.getParameter("catelog_id");
		
		List dongmanList=new ArrayList();
		String sql="select * from t_dongman where catelog_id="+catelog_id;
		Object[] params={};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				Tdongman dongman=new Tdongman();
				
				dongman.setId(rs.getString("id"));
				dongman.setCatelog_id(rs.getString("catelog_id"));
				dongman.setName(rs.getString("name"));
				dongman.setFujian(rs.getString("fujian"));
				
				dongman.setFujianYuanshiming(rs.getString("fujianYuanshiming"));
				dongman.setzhujiao(rs.getString("zhujiao"));
				dongman.setShijian(rs.getString("shijian"));
				
				dongmanList.add(dongman);
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		
		req.setAttribute("dongmanList", dongmanList);
		req.getRequestDispatcher("qiantai/index.jsp").forward(req, res);
	}
	
	
	public void dongmanSearch(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
        String name=req.getParameter("name");
		
		List dongmanList=new ArrayList();
		String sql="select * from t_dongman where name like '%"+name.trim()+"%'";
		Object[] params={};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				Tdongman dongman=new Tdongman();
				
				dongman.setId(rs.getString("id"));
				dongman.setCatelog_id(rs.getString("catelog_id"));
				dongman.setName(rs.getString("name"));
				dongman.setFujian(rs.getString("fujian"));
				
				dongman.setFujianYuanshiming(rs.getString("fujianYuanshiming"));
				dongman.setzhujiao(rs.getString("zhujiao"));
				dongman.setShijian(rs.getString("shijian"));
				
				dongmanList.add(dongman);
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		
		req.setAttribute("dongmanList", dongmanList);
		req.getRequestDispatcher("qiantai/index.jsp").forward(req, res);
	}
	
	
	public void dongmanDetailQian(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
        String id=req.getParameter("id");
		
		Tdongman dongman=new Tdongman();
		
		String sql="select * from t_dongman where id="+id;
		Object[] params={};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				dongman.setId(rs.getString("id"));
				dongman.setCatelog_id(rs.getString("catelog_id"));
				dongman.setName(rs.getString("name"));
				dongman.setFujian(rs.getString("fujian"));
				
				dongman.setFujianYuanshiming(rs.getString("fujianYuanshiming"));
				dongman.setzhujiao(rs.getString("zhujiao"));
				dongman.setShijian(rs.getString("shijian"));
				
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();   
		
		req.setAttribute("dongman", dongman);
		req.getRequestDispatcher("qiantai/dongman/dongmanDetailQian.jsp").forward(req, res);
	}
	
	public void dispatch(String targetURI,HttpServletRequest request,HttpServletResponse response) 
	{
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(targetURI);
		try 
		{
		    dispatch.forward(request, response);
		    return;
		} 
		catch (ServletException e) 
		{
                    e.printStackTrace();
		} 
		catch (IOException e) 
		{
			
		    e.printStackTrace();
		}
	}
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
	}
	
	public void destroy() 
	{
		
	}
}
