package action;

import java.io.IOException;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import orm.Tcatelog;
import orm.Tdongman;
import orm.Ttupian;
import orm.Tuser;
import service.liuService;

import dao.DB;


public class tupian_servlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException, IOException 
	{
        String type=req.getParameter("type");
		
		
		if(type.endsWith("tupianAdd"))
		{
			tupianAdd(req, res);
		}
		if(type.endsWith("tupianMana"))
		{
			tupianMana(req, res);
		}
		if(type.endsWith("tupianDel"))
		{
			tupianDel(req, res);
		}
		if(type.endsWith("tupianShenhe"))
		{
			tupianShenhe(req, res);
		}
		
		
		if(type.endsWith("tupianAll"))
		{
			tupianAll(req, res);
		}
		if(type.endsWith("tupianDetailQian"))
		{
			tupianDetailQian(req, res);
		}
	}
	
	
	public void tupianAdd(HttpServletRequest req,HttpServletResponse res)
	{
		HttpSession session=req.getSession();
		Tuser user=(Tuser)session.getAttribute("user");
		
		String id=String.valueOf(new Date().getTime());
		String biaoti=req.getParameter("biaoti").trim();
		String fujian=req.getParameter("fujian").trim();
		String fujianYuanshiming=req.getParameter("fujianYuanshiming").trim();
		
		String shijian=new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date());
		String user_id=user.getId();
		String zt="�����";
		
		
		String sql="insert into t_tupian(id,biaoti,fujian,fujianYuanshiming,shijian,user_id,zt) values(?,?,?,?,?,?,?)";
		Object[] params={id,biaoti,fujian,fujianYuanshiming,shijian,user_id,zt};
		DB mydb=new DB();
		mydb.doPstm(sql, params);
		mydb.closed();
		
		req.setAttribute("msg", "�ϴ���ϣ��ȴ�����Ա���");
		
        String targetURL = "/common/msg.jsp";
		dispatch(targetURL, req, res);
        
	}
	
	
	public void tupianMana(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		List tupianList=new ArrayList();
		String sql="select * from t_tupian order by zt";
		Object[] params={};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				Ttupian tupian=new Ttupian();
				
				tupian.setId(rs.getString("id"));
				tupian.setBiaoti(rs.getString("biaoti"));
				tupian.setFujian(rs.getString("fujian"));
				tupian.setFujianYuanshiming(rs.getString("fujianYuanshiming"));
				
				tupian.setShijian(rs.getString("shijian"));
				tupian.setUser_id(rs.getString("user_id"));
				tupian.setZt(rs.getString("zt"));
				
				tupian.setUser(liuService.getUser(rs.getString("user_id")));
				
				tupianList.add(tupian);
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		
		req.setAttribute("tupianList", tupianList);
		req.getRequestDispatcher("admin/tupian/tupianMana.jsp").forward(req, res);
	}
	
	public void tupianDel(HttpServletRequest req,HttpServletResponse res)
	{
		String sql="delete from t_tupian where id="+req.getParameter("id");
		Object[] params={};
		DB mydb=new DB();
		mydb.doPstm(sql, params);
		mydb.closed();
		
        req.setAttribute("msg", "�����ɹ�");
		
        String targetURL = "/common/msg.jsp";
		dispatch(targetURL, req, res);
	}
	
	
	
	public void tupianShenhe(HttpServletRequest req,HttpServletResponse res)
	{
		String sql="update t_tupian set zt='��ͨ��' where id="+req.getParameter("id");
		Object[] params={};
		DB mydb=new DB();
		mydb.doPstm(sql, params);
		mydb.closed();
		
        req.setAttribute("msg", "�����ɹ�");
		
        String targetURL = "/common/msg.jsp";
		dispatch(targetURL, req, res);
	}

	
	public void tupianAll(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		List tupianList=new ArrayList();
		String sql="select * from t_tupian where zt='��ͨ��'";
		Object[] params={};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				Ttupian tupian=new Ttupian();
				
				tupian.setId(rs.getString("id"));
				tupian.setBiaoti(rs.getString("biaoti"));
				tupian.setFujian(rs.getString("fujian"));
				tupian.setFujianYuanshiming(rs.getString("fujianYuanshiming"));
				
				tupian.setShijian(rs.getString("shijian"));
				tupian.setUser_id(rs.getString("user_id"));
				tupian.setZt(rs.getString("zt"));
				
				tupian.setUser(liuService.getUser(rs.getString("user_id")));
				
				tupianList.add(tupian);
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		
		req.setAttribute("tupianList", tupianList);
		req.getRequestDispatcher("qiantai/tupian/tupianAll.jsp").forward(req, res);
	}
	
	
	public void tupianDetailQian(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
        String id=req.getParameter("id");
		
		Ttupian tupian=new Ttupian();
		
		String sql="select * from t_tupian where id="+id;
		Object[] params={};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				tupian.setId(rs.getString("id"));
				tupian.setBiaoti(rs.getString("biaoti"));
				tupian.setFujian(rs.getString("fujian"));
				tupian.setFujianYuanshiming(rs.getString("fujianYuanshiming"));
				
				tupian.setShijian(rs.getString("shijian"));
				tupian.setUser_id(rs.getString("user_id"));
				tupian.setZt(rs.getString("zt"));
				
				tupian.setUser(liuService.getUser(rs.getString("user_id")));
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();   
		
		req.setAttribute("tupian", tupian);
		req.getRequestDispatcher("qiantai/tupian/tupianDetailQian.jsp").forward(req, res);
	}
	
	public void dispatch(String targetURI,HttpServletRequest request,HttpServletResponse response) 
	{
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(targetURI);
		try 
		{
		    dispatch.forward(request, response);
		    return;
		} 
		catch (ServletException e) 
		{
                    e.printStackTrace();
		} 
		catch (IOException e) 
		{
			
		    e.printStackTrace();
		}
	}
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
	}
	
	public void destroy() 
	{
		
	}
}
