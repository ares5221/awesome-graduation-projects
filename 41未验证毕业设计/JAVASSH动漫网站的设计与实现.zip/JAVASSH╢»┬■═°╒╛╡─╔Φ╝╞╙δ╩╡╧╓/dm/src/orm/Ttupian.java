package orm;

public class Ttupian
{
	private String id;
	private String biaoti;
	private String fujian;
	private String fujianYuanshiming;
	
	private String shijian;
	private String user_id;
	private String zt;//�����-δͨ��-��ͨ��
	
	private Tuser user;
	
	public String getBiaoti()
	{
		return biaoti;
	}
	public void setBiaoti(String biaoti)
	{
		this.biaoti = biaoti;
	}
	public String getFujian()
	{
		return fujian;
	}
	public void setFujian(String fujian)
	{
		this.fujian = fujian;
	}
	public String getFujianYuanshiming()
	{
		return fujianYuanshiming;
	}
	public void setFujianYuanshiming(String fujianYuanshiming)
	{
		this.fujianYuanshiming = fujianYuanshiming;
	}
	
	public Tuser getUser()
	{
		return user;
	}
	public void setUser(Tuser user)
	{
		this.user = user;
	}
	public String getId()
	{
		return id;
	}
	
	public String getZt()
	{
		return zt;
	}
	public void setZt(String zt)
	{
		this.zt = zt;
	}
	public void setId(String id)
	{
		this.id = id;
	}
	public String getShijian()
	{
		return shijian;
	}
	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}
	public String getUser_id()
	{
		return user_id;
	}
	public void setUser_id(String user_id)
	{
		this.user_id = user_id;
	}
	
}
