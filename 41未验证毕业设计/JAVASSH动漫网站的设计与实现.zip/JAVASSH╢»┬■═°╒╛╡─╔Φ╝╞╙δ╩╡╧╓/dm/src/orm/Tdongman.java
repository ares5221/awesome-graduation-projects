package orm;

public class Tdongman
{
	private String id;
	private String catelog_id;
	private String name;
	private String fujian;
	
	private String fujianYuanshiming;
	private String zhujiao;
	private String shijian;
	
	
	
	public String getCatelog_id()
	{
		return catelog_id;
	}
	public void setCatelog_id(String catelog_id)
	{
		this.catelog_id = catelog_id;
	}
	
	public String getzhujiao()
	{
		return zhujiao;
	}
	public void setzhujiao(String zhujiao)
	{
		this.zhujiao = zhujiao;
	}
	public String getFujian()
	{
		return fujian;
	}
	public void setFujian(String fujian)
	{
		this.fujian = fujian;
	}
	public String getFujianYuanshiming()
	{
		return fujianYuanshiming;
	}
	public void setFujianYuanshiming(String fujianYuanshiming)
	{
		this.fujianYuanshiming = fujianYuanshiming;
	}
	public String getId()
	{
		return id;
	}
	public void setId(String id)
	{
		this.id = id;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getShijian()
	{
		return shijian;
	}
	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}

}
