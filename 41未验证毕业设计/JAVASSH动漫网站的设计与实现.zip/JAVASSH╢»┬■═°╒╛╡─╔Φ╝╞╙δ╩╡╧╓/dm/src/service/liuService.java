package service;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import orm.Tcatelog;
import orm.Tdongman;
import orm.Tuser;


import dao.DB;

public class liuService
{
	public static Tuser getUser(String id)
	{
		Tuser user=new Tuser();
		String sql="select * from t_user where id=?";
		Object[] params={id};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				user.setId(rs.getString("id"));
				user.setLoginname(rs.getString("loginname"));
				user.setLoginpw(rs.getString("loginpw"));
				user.setLoginpw(rs.getString("loginpw"));
				user.setName(rs.getString("name"));
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		return user;
	}
	
	
	public static List catelogList()
	{
		List catelogList=new ArrayList();
		String sql="select * from t_catelog where del='no'";
		Object[] params={};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				Tcatelog catelog=new Tcatelog();
				catelog.setId(rs.getString("id"));
				catelog.setName(rs.getString("name"));
				catelogList.add(catelog);
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		return catelogList;
	}
	
	
	public static List dongmanList()
	{
		List dongmanList=new ArrayList();
		String sql="select * from t_dongman order by shijian desc";
		Object[] params={};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				Tdongman dongman=new Tdongman();
				
				dongman.setId(rs.getString("id"));
				dongman.setCatelog_id(rs.getString("catelog_id"));
				dongman.setName(rs.getString("name"));
				dongman.setFujian(rs.getString("fujian"));
				
				dongman.setFujianYuanshiming(rs.getString("fujianYuanshiming"));
				dongman.setzhujiao(rs.getString("zhujiao"));
				dongman.setShijian(rs.getString("shijian"));
				
				dongmanList.add(dongman);
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		return dongmanList;
	}
	
}
