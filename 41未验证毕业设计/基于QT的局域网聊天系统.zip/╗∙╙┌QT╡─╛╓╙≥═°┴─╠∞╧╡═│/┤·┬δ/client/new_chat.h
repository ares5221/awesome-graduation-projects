#ifndef		__NEW_CHAT_H__
#define		__NEW_CHAT_H__

#include	<QWidget>
#include	<QPushButton>
#include	<QLabel>
#include	<QTextEdit>
#include	<QTextBrowser>
#include	<QLineEdit>
#include	<QThread>


/*声明用来读数据的线程类*/
class ReadThread;

/*声明用来写数据的线程类*/
class WriteThread;


/*自定义的窗口类*/
class QChatWindow : public QWidget
{
        Q_OBJECT
        public:
			QLabel			*hostIpLabel;
            QLineEdit		*hostIpLine;
            QLabel			*hostPortLabel;
            QLineEdit		*hostPortLine;
            QPushButton		*connectBtn;
            QPushButton		*resetBtn;
            QTextBrowser	*onlineIpBrowser;
            QPushButton		*reloadBtn;
            QLabel			*destIpLabel;
            QLineEdit		*destIpLine;
            QPushButton		*okBtn;
            QPushButton		*cancelBtn;
            QTextBrowser	*chatBrowser;
            QLineEdit		*sendMsgText;
            QPushButton		*clearBtn;
			QPushButton		*recordBtn;
            QPushButton		*sendBtn;
            QPushButton		*offBtn;
            QPushButton		*closeBtn;
			ReadThread		*readTh;
			WriteThread		*writeTh;
			FILE*			log;

			bool	isSendAddr;
			bool	isResetAddr;
			bool	isReload;
			bool	isConnect;
			bool	isResetIp;
			bool	isOffClient;
			bool	isRecord;
			bool	isClearWindow;
			bool	isExit;
			bool	isSendChatMsg;
			bool	connectStatus;
			bool	conSerStatus;
            int		serverFd;
			void	rcvServerMsg();

            QChatWindow( QWidget *parent = 0 );

		protected slots:
            void	connectServerSlots();
            void	resetServerSlots();
            void	reloadSlots();
            void	connectClientSlots();
            void	cancelSlots();
            void	clearChatWindowSlots();
            void	sendSlots();
			void	recordSlots();
            void	offSlots();
            void	exitSlots();
			void	setConSerSucc();
			void	setConCliSucc();
			void	setOffSuccInfor();
			void	setConSerFail();
			void	setConCliFail();
			void	setEmptyMsg();
			void	setFriendExit();
			void	setConCliWarning();
			void	setServerExit();
			void	setSaveRecord();
			void	setRecorded();
			void	setAccepter( char* );
			void	setClientMsg( char* );
			void	setReloadInfor( char* );
};


class ReadThread : public QThread
{
	Q_OBJECT

	public:
		QChatWindow *w;	

		ReadThread( QChatWindow *window )
		{
			w = window;	
		}
		
		void	run();

	signals:
		void	conSerSucc();
		void	conCliSucc();
		void	offSuccInfor();
		void	conCliFail();
		void	conCliWarning();
		void	serverExit();
		void	friendExit();
		void	saveRecord();
		void	recorded();
		void	accepter( char* );
		void	clientMsg( char* );
		void	reloadInfor( char* );
};


class WriteThread : public QThread
{
	Q_OBJECT

	public:
		QChatWindow *ww;

		WriteThread( QChatWindow *window )	
		{
			ww = window;
		}

		void run();

	signals:
		void	conSerFail();
		void	emptyMsg();
};


#endif
