#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<signal.h>
#include	<fcntl.h>
#include	<unistd.h>
#include	<netinet/in.h>
#include	<sys/socket.h>
#include	<arpa/inet.h>
#include	"new_chat.h"
#include	<QVBoxLayout>
#include	<QHBoxLayout>
#include	<QByteArray>


QChatWindow::QChatWindow( QWidget *parent ) : QWidget( parent )
{
        serverFd		=	-1;
		log				=	NULL;
		isSendAddr		=	false;
		isResetAddr		=	false;
		isReload		=	false;
		isConnect		=	false;
		isResetIp		=	false;
		isOffClient		=	false;
		isClearWindow	=	false;
		isSendChatMsg	=	false;
		isExit			=	false;
		isRecord		=	false;
		connectStatus   =   false;
		conSerStatus    =	false;

        hostIpLabel = new QLabel( "SERVER         IP:" );
        hostIpLine = new QLineEdit;
        hostPortLabel = new QLabel( "SERVER  PORT:" );
        hostPortLine = new QLineEdit;
        connectBtn = new QPushButton( "Connect" ) ;
		connectBtn->setFont( QFont( tr( "Connect" ), 12, QFont::Bold ) );
        resetBtn = new QPushButton( "Reset" );
		resetBtn->setFont( QFont( tr( "Reset" ), 12, QFont::Bold ) );
        onlineIpBrowser = new QTextBrowser( this );
        reloadBtn = new QPushButton( "Reload" );
		reloadBtn->setFont( QFont( tr( "Reload" ), 12, QFont::Bold ) );
		reloadBtn->setEnabled( false );
        destIpLabel = new QLabel( "DEST IP:");
        destIpLine = new QLineEdit( this );
		destIpLine->setEnabled( false );
        okBtn = new QPushButton( "Ok" );
		okBtn->setFont( QFont( tr( "Ok" ), 12, QFont::Bold ) );
		okBtn->setEnabled( false );
        cancelBtn = new QPushButton( "Cancel" );
		cancelBtn->setFont( QFont( tr( "Cancel" ), 12, QFont::Bold ) );
		cancelBtn->setEnabled( false );
        chatBrowser = new QTextBrowser( this );
        sendMsgText = new QLineEdit( this );
        sendMsgText->setEnabled( false );
        clearBtn = new QPushButton( "Clear" );
		clearBtn->setFont( QFont( tr( "Clear" ), 12, QFont::Bold ) );
		clearBtn->setEnabled( false );
        sendBtn = new QPushButton( "Send" );
		sendBtn->setFont( QFont( tr( "Send" ), 12, QFont::Bold ) );
		sendBtn->setEnabled( false );
        offBtn = new QPushButton( "Off");
		offBtn->setFont( QFont( tr( "Off" ), 12, QFont::Bold ) );
		offBtn->setEnabled( false );
		recordBtn = new QPushButton( "Save" );
		recordBtn->setFont( QFont( tr( "Save" ), 12, QFont::Bold ) );
		recordBtn->setEnabled( false );
        closeBtn = new QPushButton( "Exit" );
		closeBtn->setFont( QFont( tr( "Exit" ), 12, QFont::Bold ) );
		readTh = new ReadThread( this );
		writeTh = new WriteThread( this );

        QHBoxLayout *serverIpLayout = new QHBoxLayout;
        QHBoxLayout *serverHostLayout = new QHBoxLayout;
        QHBoxLayout *connectServerLayout = new QHBoxLayout;
        QHBoxLayout *destIpLayout = new QHBoxLayout;
        QHBoxLayout *destIpOperLayout = new QHBoxLayout;
        QVBoxLayout *leftLayout = new QVBoxLayout;
        destIpLayout->addWidget( destIpLabel );
        destIpLayout->addWidget( destIpLine );
        destIpOperLayout->addWidget( okBtn );
        destIpOperLayout->addWidget( cancelBtn );
        serverIpLayout->addWidget( hostIpLabel );
        serverIpLayout->addWidget( hostIpLine );
        serverHostLayout->addWidget( hostPortLabel );
        serverHostLayout->addWidget( hostPortLine );
        connectServerLayout->addWidget( connectBtn );
        connectServerLayout->addWidget( resetBtn );
        leftLayout->addLayout( serverIpLayout );
        leftLayout->addLayout( serverHostLayout );
        leftLayout->addLayout( connectServerLayout );
        leftLayout->addWidget( onlineIpBrowser );
        leftLayout->addWidget( reloadBtn );
        leftLayout->addLayout( destIpLayout );
        leftLayout->addLayout( destIpOperLayout );


        QHBoxLayout *btnLayout = new QHBoxLayout;
        QVBoxLayout *rightLayout = new QVBoxLayout;
        btnLayout->addWidget( clearBtn );
		btnLayout->addWidget( recordBtn );
        btnLayout->addWidget( sendBtn );
        btnLayout->addWidget( offBtn );
        btnLayout->addWidget( closeBtn );
        rightLayout->addWidget( chatBrowser );
        rightLayout->addWidget( sendMsgText );
        rightLayout->addLayout( btnLayout );


        QHBoxLayout *mainLayout = new QHBoxLayout;
        mainLayout->addLayout( leftLayout );
        mainLayout->addLayout( rightLayout );
        this->setLayout( mainLayout );


        connect( connectBtn, SIGNAL( clicked() ), this, SLOT( connectServerSlots() ) );
        connect( resetBtn, SIGNAL( clicked() ), this, SLOT( resetServerSlots() ) );
        connect( reloadBtn, SIGNAL( clicked() ), this, SLOT( reloadSlots() ) );
        connect( okBtn, SIGNAL( clicked() ), this, SLOT( connectClientSlots() ) );
        connect( cancelBtn, SIGNAL( clicked() ), this, SLOT( cancelSlots() ) );
        connect( clearBtn, SIGNAL( clicked() ), this, SLOT( clearChatWindowSlots() ) );
        connect( sendBtn, SIGNAL( clicked() ), this, SLOT( sendSlots() ) );
		connect( recordBtn, SIGNAL( clicked() ), this, SLOT( recordSlots() ) );
        connect( offBtn, SIGNAL( clicked() ), this, SLOT( offSlots() ) );
        connect( closeBtn, SIGNAL( clicked() ), this, SLOT( exitSlots() ) );
		connect( readTh, SIGNAL( conSerSucc() ), this, SLOT( setConSerSucc() ) );
		connect( readTh, SIGNAL( conCliSucc() ), this, SLOT( setConCliSucc() ) );
		connect( writeTh, SIGNAL( conSerFail() ), this, SLOT( setConSerFail() ) );
		connect( readTh, SIGNAL( conCliFail() ), this, SLOT( setConCliFail() ) );
		connect( readTh, SIGNAL( offSuccInfor() ), this, SLOT( setOffSuccInfor() ) );
		connect( readTh, SIGNAL( conCliWarning() ), this, SLOT( setConCliWarning() ) );
		connect( readTh, SIGNAL( serverExit() ), this, SLOT( setServerExit() ) );
		connect( readTh, SIGNAL( friendExit() ), this, SLOT( setFriendExit() ) );
		connect( readTh, SIGNAL( saveRecord() ), this, SLOT( setSaveRecord() ) );
		connect( readTh, SIGNAL( recorded() ), this, SLOT( setRecorded() ) );
		connect( readTh, SIGNAL( clientMsg( char* )), this, SLOT( setClientMsg( char* ) ) );
		connect( readTh, SIGNAL( accepter( char* ) ), this, SLOT( setAccepter( char* ) ) );
		connect( readTh, SIGNAL(reloadInfor(char*)), this, SLOT(setReloadInfor(char*)) );
		connect( writeTh, SIGNAL( emptyMsg() ), this, SLOT( setEmptyMsg() ) );

		readTh->start();
		writeTh->start();
}


void QChatWindow::setRecorded()
{
	chatBrowser->setTextColor( Qt::red );
	chatBrowser->append( "--------------------System Has Save Chat Record-------------------" );							
	chatBrowser->append( "" );
	chatBrowser->setTextColor( Qt::blue );
	clearBtn->setEnabled( true );
	offBtn->setEnabled( true );
	sendBtn->setEnabled( true );
	closeBtn->setEnabled( true );
}


void QChatWindow::setSaveRecord()
{
	recordBtn->setEnabled( true );		
}

void QChatWindow::setFriendExit()
{
	if( connectStatus == true )
	{
		connectStatus = false;			
		reloadBtn->setEnabled( true );	
		okBtn->setEnabled( true );
		cancelBtn->setEnabled( true );
		destIpLine->clear();	
		destIpLine->setEnabled( true );
		chatBrowser->setTextColor( Qt::red );
		chatBrowser->append( "------------------Your Friend Exit System----------------" );
		chatBrowser->append( "" );
		chatBrowser->setTextColor( Qt::blue );
		chatBrowser->setEnabled( true );
		clearBtn->setEnabled( false );
		recordBtn->setEnabled( false );
		offBtn->setEnabled( false );
		sendBtn->setEnabled( false );
		sendMsgText->setEnabled( false );
	}
}


void QChatWindow::setServerExit()
{
	if( serverFd != -1 )
	{
		::close( serverFd );
	}

	serverFd = -1;

	connectStatus = false;
	conSerStatus = false;

	::exit( 1 );
}


void QChatWindow::setConCliWarning()
{
	chatBrowser->clear();
	chatBrowser->setTextColor( Qt::red );
	chatBrowser->append( "----------------You Cannot Connect Yourself-----------------" );
	chatBrowser->setTextColor( Qt::blue );
}


void QChatWindow::setAccepter( char* msg )
{
	connectStatus = true;

	char buf[ 4096 ] = { 0 };
	strcpy( buf, msg + 5 );

	reloadBtn->setEnabled( false );
	destIpLine->setEnabled( false );
	okBtn->setEnabled( false );
	cancelBtn->setEnabled( false );
	chatBrowser->setEnabled( true );
	sendMsgText->setEnabled( true );
    clearBtn->setEnabled( true ); 
	clearBtn->setEnabled( true );
	sendBtn->setEnabled( true );
	offBtn->setEnabled( true );

	chatBrowser->clear();
	chatBrowser->setTextColor( Qt::red );
	chatBrowser->append("--------------Your Friend Have Connected You---------------");
	chatBrowser->setTextColor( Qt::blue );
	chatBrowser->append( "" );
	chatBrowser->append( buf );
	chatBrowser->append( "" );
}


void QChatWindow::setEmptyMsg()
{
	chatBrowser->setTextColor( Qt::red );
	chatBrowser->append( "----------------You Cannot Send Empty Message---------------" );
	chatBrowser->append( "" );
	chatBrowser->setTextColor( Qt::blue );
}


void QChatWindow::setConCliFail()
{
	chatBrowser->clear();
	chatBrowser->setTextColor( Qt::red );
	chatBrowser->append( "------------------Connect Your Friend Fail-------------------" );
	chatBrowser->setTextColor( Qt::blue );
}


void QChatWindow::setConSerFail()
{
	onlineIpBrowser->clear();
	onlineIpBrowser->setTextColor( Qt::red );
	onlineIpBrowser->append( "Connect Server Fail!" );
	serverFd = -1;
	isSendAddr = false;
}


void QChatWindow::setOffSuccInfor()
{
	chatBrowser->clear();
	chatBrowser->setTextColor( Qt::red );
	chatBrowser->append( "------------------------You Are At Off Status!----------------------" );
	chatBrowser->append( "" );
	chatBrowser->setTextColor( Qt::blue );
	reloadBtn->setEnabled( true );
	okBtn->setEnabled( true );
	cancelBtn->setEnabled( true );
	destIpLine->setEnabled( true );
	destIpLine->clear();
	onlineIpBrowser->setEnabled( true );
    sendMsgText->setEnabled( false ); 
	offBtn->setEnabled( false );
	clearBtn->setEnabled( false );
	recordBtn->setEnabled( false );
	sendBtn->setEnabled( false );
	connectStatus = false;
}


void QChatWindow::setClientMsg( char* msg )
{
	char buf[ 4096 ] = { 0 };	
	strcpy( buf, msg );
	chatBrowser->append( buf + 5 );									
	chatBrowser->append( "" );
	sendMsgText->setEnabled( true );
}


void QChatWindow::setConCliSucc()
{
	chatBrowser->clear();
	chatBrowser->setTextColor( Qt::red );
	chatBrowser->append("------------------Connect Your Friend Success------------------" );
	chatBrowser->setTextColor( Qt::blue );
	chatBrowser->append( "" );
	connectStatus = true;
	okBtn->setEnabled( false );
	cancelBtn->setEnabled( false );
	sendMsgText->setEnabled( true );
	clearBtn->setEnabled( true );
	offBtn->setEnabled( true );
	sendBtn->setEnabled( true );
	closeBtn->setEnabled( true );
	reloadBtn->setEnabled( false );
	destIpLine->setEnabled( false ); 
	onlineIpBrowser->setEnabled( false );
}


void QChatWindow::setConSerSucc()
{
	onlineIpBrowser->clear();
	onlineIpBrowser->setTextColor( Qt::red );
	onlineIpBrowser->append( "Connect Server Success!" );
}


void QChatWindow::setReloadInfor( char* serverMsg )
{
	onlineIpBrowser->setTextColor( Qt::blue );
	char ip[ 17 ] = { '\0' };
	char recvBuf[ 4096 ] = { '\0' };
	strcpy( recvBuf, serverMsg + 10 );
	strcpy( ip, strtok( recvBuf, "^" ) );
	onlineIpBrowser->append( "Your Online Friends:" );
	onlineIpBrowser->append( "" );
	onlineIpBrowser->append( ip );

	while( 1 )
	{
		memset( ip, 0, sizeof( ip ) );
		char *temp = NULL;
		if( ( temp = strtok( NULL, "^" ) ) == NULL )
		{
			break;
		}

		strcpy( ip, temp );
		onlineIpBrowser->append( ip );
	}
}


void QChatWindow::connectServerSlots()
{
	isSendAddr = true;
}


void QChatWindow::resetServerSlots()
{
	isResetAddr = true;
}


void QChatWindow::reloadSlots()
{
	onlineIpBrowser->clear();
	isReload = true;
}


void QChatWindow::connectClientSlots()
{
	isConnect = true;
}


void QChatWindow::cancelSlots()
{
	isResetIp = true;
}



void QChatWindow::clearChatWindowSlots()
{
	chatBrowser->clear();
	if( connectStatus )			
	{
		chatBrowser->setTextColor( Qt::red );
		chatBrowser->append( "-----------------You Are Connecting Your Friend----------------" );
		chatBrowser->append( "" );
		chatBrowser->setTextColor( Qt::blue );
	}
}


void QChatWindow::recordSlots()
{
	chatBrowser->setTextColor( Qt::red );
	chatBrowser->append( "-------------------System Is Saveing Chat Record-------------------" );
	chatBrowser->append( "" );
	chatBrowser->append( "please wait..." );
	chatBrowser->append( "" );
	chatBrowser->setTextColor( Qt::blue );
	recordBtn->setEnabled( false );
	clearBtn->setEnabled( false );
	offBtn->setEnabled( false );
	sendBtn->setEnabled( false );
	closeBtn->setEnabled( false );
	isRecord = true;
}


void QChatWindow::sendSlots()
{
	isSendChatMsg = true;
}



void QChatWindow::offSlots()
{
	connectStatus = false;
	isOffClient = true;
}



void QChatWindow::exitSlots()
{
	isExit = true;
}



void ReadThread::run()
{

	int serFd = -1;
	char serverMsg[ 4096 ] = { '\0' };

	/*
	if( NULL == ( w->log = ::fopen( "Record.txt", "w" ) ) )
	{
		printf( "fopen error!" );	
		return;
	}
	*/
		
	while( 1 )
	{
		msleep( 350 );
		if( w->conSerStatus )
		{
			serFd = w->serverFd;
			break;
		}
		else
		{
			continue;
		}
	}

	while( 1 )
	{
		memset( serverMsg, '\0', sizeof( serverMsg ) );

		if( ::read( serFd, serverMsg, 4096 ) < 0 )
		{
			msleep( 500 );
			//printf( "thread read server error!\n" );	
			continue;	
		}

		msleep( 200 );

		if( strcmp( serverMsg, "<connectServer>SUCC</connectServer>" ) == 0 )
		{
			emit conSerSucc();
			continue;
		}

		if( strncmp( serverMsg, "<reloadIp>", 10 ) == 0 )
		{
			char buf[ 1024 ] = { '\0' };
			strcpy( buf, serverMsg );
			emit reloadInfor( buf );

			continue;
		}

		if( strncmp( serverMsg, "<connectClient>", 15 ) == 0 )
		{
			if( w->connectStatus )
			{
				w->chatBrowser->append( "---------------You Have Connected Your Friend---------------" );
				w->chatBrowser->append( "" );
				continue;
			}

			if( strncmp( serverMsg + 15, "SUCC", 4 ) == 0 )
			{
				emit conCliSucc();
				continue;
			}

			if( strncmp( serverMsg + 15, "FAIL", 4 ) == 0 )
			{
				emit conCliFail();
				continue;
			}

			if( 0 == strncmp( serverMsg + 15, "WARNING", 7 ) )
			{
				emit conCliWarning();
				continue;
			}
		}

		if( 0 == strcmp( serverMsg, "<friend>exit</friend>" ) )
		{
			printf( "-----friend:%s\n", serverMsg );
			emit friendExit();		
			continue;
		}


		if( 0 == strncmp( serverMsg, "<recording>", 11 ) )
		{
			printf( "-----recording:%s\n", serverMsg );

			fputs( serverMsg + 11, w->log );					
			continue;
		}

		if( 0 == strncmp( serverMsg, "<recorded>", 10 ) )
		{
			msleep( 200 );
			printf( "<recorded success>\n" );
			emit recorded();
			msleep( 200 );
			fclose( w->log );
			continue;		
		}

		if( strncmp( serverMsg, "<Msg>", 5 ) == 0 )
		{

			if( NULL == ( w->log = ::fopen( "Record.txt", "w" ) ) )
			{
				printf( "fopen error!" );	
				return;
			}

			char buf[ 4096 ] = { 0 };
			strcpy( buf, serverMsg );

			emit saveRecord();

			if( w->connectStatus == false )
			{
				printf( "-----------test----------\n" );
				emit accepter( buf );
				continue;
			}

			emit clientMsg( buf );
			continue;
		}

		if( strcmp( serverMsg, "<off>SUCC</off>" ) == 0 )
		{
			emit offSuccInfor();
			continue;
		}

		if( 0 == strcmp( serverMsg, "<serverExit>STOP</serverExit>" ) )
		{
			emit serverExit();
			continue;
		}
	}
}



void WriteThread::run()
{
	while( 1 )	
	{
		if( ww->isSendChatMsg )
		{
			/*
			char sendMsg[ 4096 ] = { '\0' };
			QByteArray tempMsg = ww->sendMsgText->text().toLatin1();
			strcpy( sendMsg, ( const char* )( tempMsg.data() ) );
			*/
			char sendMsg[ 4096 ] = { '\0' };
			strcpy( sendMsg, ( const char* )ww->sendMsgText->text().toUtf8().data() );

			char sendMessage[ 4096 ] = { '\0' };
			sprintf(sendMessage,"%s%s%s","<toClientMessage>",sendMsg,"</toClientMessage>");



			printf( "-----------%s\n", sendMsg );


			if( 0 == strlen( sendMsg ) )
			{
				emit emptyMsg();
				ww->isSendChatMsg = false;
				continue;
			}

			if( ::write( ww->serverFd, sendMessage, 4096 ) < 0 )
			{
                ww->chatBrowser->append( "Send Message Fail!" );
				ww->isSendChatMsg = false;
				continue;	
			}

			ww->sendMsgText->clear();
			ww->isSendChatMsg = false;
		}


		if( ww->isSendAddr )
		{
			char ip[ 17 ] = { '\0' };
			char port[ 8 ] = { '\0' };


			QByteArray tempIp = ww->hostIpLine->text().toLatin1();
			strcpy( ip, ( const char* )( tempIp.data() ) );
			QByteArray tempPort = ww->hostPortLine->text().toLatin1();
			strcpy( port, ( const char* )( tempPort.data() ) );


			if( ( ww->serverFd = ::socket( AF_INET, SOCK_STREAM, 0 ) ) < 0 )
			{
				emit conSerFail();
                continue;
	        }


			struct sockaddr_in serverAddr;
			memset( &serverAddr, 0, sizeof( serverAddr ) );
			serverAddr.sin_family = AF_INET;
			serverAddr.sin_port = htons( atoi( port ) );
			::inet_pton( AF_INET, ip, &( serverAddr.sin_addr.s_addr ) );

			if(::connect(ww->serverFd,(struct sockaddr*)&serverAddr,sizeof(serverAddr)) < 0 )
			{
				emit conSerFail();
				ww->isSendAddr = false;
                continue;
			}


			ww->connectBtn->setEnabled( false );
			ww->hostIpLine->setEnabled( false );
			ww->hostPortLine->setEnabled( false );
			ww->resetBtn->setEnabled( false );
			ww->reloadBtn->setEnabled( true );
			ww->destIpLine->setEnabled( true );
			ww->okBtn->setEnabled( true );
			ww->cancelBtn->setEnabled( true );
			ww->isSendAddr = false;
			ww->conSerStatus = true;

			continue;
		}

		if( ww->isResetAddr )
		{
			ww->hostIpLine->clear();
			ww->hostPortLine->clear();
			ww->isResetAddr = false;
			continue;
		}

		if( ww->isReload )
		{
			char sendMessage[ 30 ] = { "<reloadCmd>reload</reloadCmd>" };

			if( ::write( ww->serverFd, sendMessage, sizeof( sendMessage ) ) < 0 )
			{
			     ww->onlineIpBrowser->append( "Reload Fail!" );
				 continue;
			}

			ww->isReload = false;
			continue;
		}

		if( ww->isConnect )
		{		
			char ip[ 17 ] = { '\0' };
			QByteArray tempIp = ww->destIpLine->text().toLatin1();
			strcpy( ip, ( const char* )( tempIp.data() ) );
			char sendMessage[ 50 ] = { '\0' };
			sprintf( sendMessage, "%s%s%s", "<clientIp>", ip, "</clientIp>" );

			if( ::write( ww->serverFd, sendMessage, sizeof( sendMessage ) ) < 0 )
			{
			     ww->chatBrowser->append( "Connect Fail!" );
			     continue;
			}

			ww->isConnect = false;
			continue;
		}

		if( ww->isResetIp )
		{
			ww->destIpLine->clear();
			ww->isResetIp = false;	
			continue;
		}

		if( ww->isOffClient )
		{
			char sendMsg[ 50 ] = "<offClient>OFF</offClient>";

			if( ::write( ww->serverFd, sendMsg, sizeof( sendMsg ) ) < 0 )
			{
                ww->chatBrowser->append( "Off Fail!" );
                continue;
			}

			ww->isOffClient = false;
			continue;
		}

		if( ww->isRecord )
		{
			if( ::write( ww->serverFd, "<record>chat msg</record>", 40 ) < 0 )
			{
				ww->chatBrowser->append( "Record Fail!" );
				continue;
			}

			ww->isRecord = false;
			continue;
		}

		if( ww->isExit )
		{
			write( ww->serverFd, "<exit>login out</exit>", 30 );
			::exit( 1 );
		}

	}

}
