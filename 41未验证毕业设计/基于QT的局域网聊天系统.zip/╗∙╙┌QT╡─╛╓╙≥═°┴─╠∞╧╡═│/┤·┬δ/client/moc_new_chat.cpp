/****************************************************************************
** Meta object code from reading C++ file 'new_chat.h'
**
** Created: Wed May 9 01:03:22 2012
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "new_chat.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'new_chat.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_QChatWindow[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      24,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x09,
      34,   12,   12,   12, 0x09,
      53,   12,   12,   12, 0x09,
      67,   12,   12,   12, 0x09,
      88,   12,   12,   12, 0x09,
     102,   12,   12,   12, 0x09,
     125,   12,   12,   12, 0x09,
     137,   12,   12,   12, 0x09,
     151,   12,   12,   12, 0x09,
     162,   12,   12,   12, 0x09,
     174,   12,   12,   12, 0x09,
     190,   12,   12,   12, 0x09,
     206,   12,   12,   12, 0x09,
     224,   12,   12,   12, 0x09,
     240,   12,   12,   12, 0x09,
     256,   12,   12,   12, 0x09,
     270,   12,   12,   12, 0x09,
     286,   12,   12,   12, 0x09,
     305,   12,   12,   12, 0x09,
     321,   12,   12,   12, 0x09,
     337,   12,   12,   12, 0x09,
     351,   12,   12,   12, 0x09,
     370,   12,   12,   12, 0x09,
     390,   12,   12,   12, 0x09,

       0        // eod
};

static const char qt_meta_stringdata_QChatWindow[] = {
    "QChatWindow\0\0connectServerSlots()\0"
    "resetServerSlots()\0reloadSlots()\0"
    "connectClientSlots()\0cancelSlots()\0"
    "clearChatWindowSlots()\0sendSlots()\0"
    "recordSlots()\0offSlots()\0exitSlots()\0"
    "setConSerSucc()\0setConCliSucc()\0"
    "setOffSuccInfor()\0setConSerFail()\0"
    "setConCliFail()\0setEmptyMsg()\0"
    "setFriendExit()\0setConCliWarning()\0"
    "setServerExit()\0setSaveRecord()\0"
    "setRecorded()\0setAccepter(char*)\0"
    "setClientMsg(char*)\0setReloadInfor(char*)\0"
};

const QMetaObject QChatWindow::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_QChatWindow,
      qt_meta_data_QChatWindow, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QChatWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QChatWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QChatWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QChatWindow))
        return static_cast<void*>(const_cast< QChatWindow*>(this));
    return QWidget::qt_metacast(_clname);
}

int QChatWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: connectServerSlots(); break;
        case 1: resetServerSlots(); break;
        case 2: reloadSlots(); break;
        case 3: connectClientSlots(); break;
        case 4: cancelSlots(); break;
        case 5: clearChatWindowSlots(); break;
        case 6: sendSlots(); break;
        case 7: recordSlots(); break;
        case 8: offSlots(); break;
        case 9: exitSlots(); break;
        case 10: setConSerSucc(); break;
        case 11: setConCliSucc(); break;
        case 12: setOffSuccInfor(); break;
        case 13: setConSerFail(); break;
        case 14: setConCliFail(); break;
        case 15: setEmptyMsg(); break;
        case 16: setFriendExit(); break;
        case 17: setConCliWarning(); break;
        case 18: setServerExit(); break;
        case 19: setSaveRecord(); break;
        case 20: setRecorded(); break;
        case 21: setAccepter((*reinterpret_cast< char*(*)>(_a[1]))); break;
        case 22: setClientMsg((*reinterpret_cast< char*(*)>(_a[1]))); break;
        case 23: setReloadInfor((*reinterpret_cast< char*(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 24;
    }
    return _id;
}
static const uint qt_meta_data_ReadThread[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      12,       // signalCount

 // signals: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x05,
      25,   11,   11,   11, 0x05,
      38,   11,   11,   11, 0x05,
      53,   11,   11,   11, 0x05,
      66,   11,   11,   11, 0x05,
      82,   11,   11,   11, 0x05,
      95,   11,   11,   11, 0x05,
     108,   11,   11,   11, 0x05,
     121,   11,   11,   11, 0x05,
     132,   11,   11,   11, 0x05,
     148,   11,   11,   11, 0x05,
     165,   11,   11,   11, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_ReadThread[] = {
    "ReadThread\0\0conSerSucc()\0conCliSucc()\0"
    "offSuccInfor()\0conCliFail()\0conCliWarning()\0"
    "serverExit()\0friendExit()\0saveRecord()\0"
    "recorded()\0accepter(char*)\0clientMsg(char*)\0"
    "reloadInfor(char*)\0"
};

const QMetaObject ReadThread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_ReadThread,
      qt_meta_data_ReadThread, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ReadThread::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ReadThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ReadThread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ReadThread))
        return static_cast<void*>(const_cast< ReadThread*>(this));
    return QThread::qt_metacast(_clname);
}

int ReadThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: conSerSucc(); break;
        case 1: conCliSucc(); break;
        case 2: offSuccInfor(); break;
        case 3: conCliFail(); break;
        case 4: conCliWarning(); break;
        case 5: serverExit(); break;
        case 6: friendExit(); break;
        case 7: saveRecord(); break;
        case 8: recorded(); break;
        case 9: accepter((*reinterpret_cast< char*(*)>(_a[1]))); break;
        case 10: clientMsg((*reinterpret_cast< char*(*)>(_a[1]))); break;
        case 11: reloadInfor((*reinterpret_cast< char*(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void ReadThread::conSerSucc()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void ReadThread::conCliSucc()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void ReadThread::offSuccInfor()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void ReadThread::conCliFail()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void ReadThread::conCliWarning()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}

// SIGNAL 5
void ReadThread::serverExit()
{
    QMetaObject::activate(this, &staticMetaObject, 5, 0);
}

// SIGNAL 6
void ReadThread::friendExit()
{
    QMetaObject::activate(this, &staticMetaObject, 6, 0);
}

// SIGNAL 7
void ReadThread::saveRecord()
{
    QMetaObject::activate(this, &staticMetaObject, 7, 0);
}

// SIGNAL 8
void ReadThread::recorded()
{
    QMetaObject::activate(this, &staticMetaObject, 8, 0);
}

// SIGNAL 9
void ReadThread::accepter(char * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void ReadThread::clientMsg(char * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void ReadThread::reloadInfor(char * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}
static const uint qt_meta_data_WriteThread[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x05,
      26,   12,   12,   12, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_WriteThread[] = {
    "WriteThread\0\0conSerFail()\0emptyMsg()\0"
};

const QMetaObject WriteThread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_WriteThread,
      qt_meta_data_WriteThread, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &WriteThread::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *WriteThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *WriteThread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_WriteThread))
        return static_cast<void*>(const_cast< WriteThread*>(this));
    return QThread::qt_metacast(_clname);
}

int WriteThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: conSerFail(); break;
        case 1: emptyMsg(); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void WriteThread::conSerFail()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void WriteThread::emptyMsg()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}
QT_END_MOC_NAMESPACE
