#include	<QApplication>
#include	<QTextCodec>
#include	<stdio.h>
#include	<stdlib.h>
#include	<signal.h>
#include	"new_chat.h"


void myhandler( int signo )
{
	if( ( signo == SIGINT ) || ( signo == SIGQUIT ) )
	{
		printf( "\nYou cannot use this key to stop system, please press Exit button!\n" );	
	}
}


int main( int argc, char *argv[] )
{
	if( signal( SIGINT, myhandler ) == SIG_ERR )
	{
		perror( "signal sigint error!" );
		return -1;
	}

	if( signal( SIGQUIT, myhandler ) == SIG_ERR )
	{
		perror( "signal sigquit error!" );
		return -1;
	}

    QApplication app( argc, argv );

	QChatWindow *window = new QChatWindow;
	QTextCodec *codec = QTextCodec::codecForName( "UTF-8" );
	QTextCodec::setCodecForLocale( codec );
	QTextCodec::setCodecForCStrings( codec );
	QTextCodec::setCodecForTr( codec );

    window->setGeometry( 320, 150, 710, 500 );
    window->show();

    return app.exec();
}
