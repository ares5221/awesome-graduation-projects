#include	"server.h"


/*********************** 
功能   ： 创建链表
参数   ： 空
返回值 ： 链表头指针
***********************/
Node*	createTable()
{
	Node *head;		
	if( NULL == ( head = malloc( sizeof( Node ) ) ) )
	{
		return NULL;
	}

	head->clientFd = -1;		
	memset( head->clientIp, '\0', sizeof( head->clientIp ) ); 
	head->next = NULL;

	return head;
}


/*****************************
功能	：  向链表中添加新用户  
参数	：  head - 链表头指针
            fd - 新用户套接字
			ip - 新用户Ip地址
返回值	：	-1 - 失败 0 - 成功
******************************/
int		addClient( Node *head, int fd, char *ip )
{
	Node *save = head;	
	Node *new;

	if( NULL == ( new = malloc( sizeof( Node ) ) ) )
	{
		return -1;
	}

	new->clientFd = -1;
	memset( new->clientIp, '\0', sizeof( new->clientIp ) );	
	new->next = NULL;
	
	new->clientFd = fd;		
	strcpy( new->clientIp, ip );
	new->next = NULL;

	while( save->next != NULL )
	{
		save = save->next;		
	}

	save->next = new;

	return 0;
}


/********************************
功能	：	从链表中删除指定用户
参数	：	head - 链表头指针
            fd - 新用户套接字
返回值	：	-1 - 失败 0 - 成功
*********************************/
int		delClient( Node *head, int fd )
{
	Node *save = head;
	if( NULL == save->next )
	{
		return -1;
	}

	Node *last = save;
	Node *cur = save->next;

	while( 1 )
	{
		if( NULL == cur->next )				
		{
			if( cur->clientFd == fd )
			{
				printf( "删除好友！\n" );
				last->next = NULL;	
				free( cur );
				break;
			}

			return -1;
		}

		if( cur->clientFd == fd )
		{
			printf( "删除好友！\n" );
			last->next = cur->next;		
			free( cur );
			break;
		}

		last = cur;
		cur = cur->next;
	}

	return 0;
}


/*******************************
功能	：	获取指定用户的套接字
参数	：	head - 链表头指针
			ip - 指定用户IP地址
返回值	：	-1 - 失败
			其他 - 用户套接字
********************************/
int		getClient( Node *head, char *ip )
{
	Node *save = head;	
	if( NULL == save->next )
	{
		return -1;
	}

	while( save->next != NULL )	
	{
		if( 0 == strcmp( save->clientIp, ip ) )
		{
			return save->clientFd;
		}

		save = save->next;	
	}

	if( 0 == strcmp( save->clientIp, ip ) )
	{
		return save->clientFd;
	}

	return -1;
}



/*************************************
功能	：	从链表中获取指定用户IP地址
参数	：	head - 链表头指针
			fd - 指定用户套接字
返回值	：	NULL - 失败
			其他 - 用户IP地址
*************************************/
char	*getClientIp( Node *head, int fd ) 
{
	Node *save = head;	
	if( NULL == save->next )
	{
		return NULL;
	}

	while( save->next != NULL )	
	{
		if( save->clientFd == fd )
		{
			return save->clientIp;
		}

		save = save->next;	
	}

	if( save->clientFd == fd )
	{
		return save->clientIp;
	}

	return NULL;
}


/****************************
功能	：	销毁链表
参数	：	链表头指针
返回值	：	无
****************************/
void	destroyTable( Node *head )
{
	Node *cur = head;
	Node *temp = NULL;

	while( cur->next != NULL )
	{
		temp = cur->next;
		free( cur );
		cur = temp;
	}		

	free( cur );
}


/********************************
功能	：	获取系统当前时间
参数	：	无
返回值	：	当前时间的字符串形式
********************************/
char	*getCurTime()
{
	time_t sec = time( NULL );	
	struct tm *sysTime = localtime( &sec );

	static char resTime[ 70 ];
	memset( resTime, 0, sizeof( resTime ) );
	sprintf( resTime, "%d-%d-%d    %d:%d:%d", sysTime->tm_year + 1900, sysTime->tm_mon + 1, \
			 sysTime->tm_mday, sysTime->tm_hour, sysTime->tm_min, sysTime->tm_sec );

	return resTime;
}


/****************************
功能	：	创建日志文件
参数	：	将用户IP作为文件名
返回值	：	文件指针
*****************************/
FILE	*creatFile( char *ip )
{
	FILE *file = fopen( ip, "ar" );					

	if( NULL == file )
	{
		perror( "Create Log error!" );
		return NULL;
	}

	return file;
}



/****************************************
功能	：	将聊天消息保存到日志文件中
参数	：	file - 日志文件指针
			otherIp - 聊天的对方IP地址
			time - 当前时间
			msg - 聊天信息
			flag - 消息的方向（来/去）
返回值	：	无
*****************************************/
void	saveMsg( FILE *file, char *otherIp, char *time, char *msg, int flag )
{
	if( TO == flag )
	{
		printf( "---------------to %s\n", otherIp );
		fprintf( file, "To   %s %s\n\n", otherIp, msg + 7 );
	}

	if( FROM == flag )
	{
		printf( "--------------from %s\n", otherIp );
		fprintf( file, "From %s %s\n\n", otherIp, msg + 7 );
	}
}
