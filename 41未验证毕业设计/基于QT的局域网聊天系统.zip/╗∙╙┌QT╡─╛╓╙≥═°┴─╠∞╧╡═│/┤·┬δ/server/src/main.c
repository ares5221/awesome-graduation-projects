#include	"server.h"


/*用来存放用户信息的结构体*/
Node *socketTable = NULL;

/*用来存放正在通讯的两个用户*/
SaveFd sFd;

/*发送方套接字描述符*/
int sender = -1; 
/*服务端套接字*/
int serverFd = -1;		


void myhandler( int signo )
{

	if( ( signo == SIGINT ) || ( signo == SIGQUIT ) )
	{
		if( sFd.firstFd != -1 )
		{
			sFd.firstFd = -1;
			if( sFd.firstLog != NULL )
			{
				fclose( sFd.firstLog );
				sFd.firstLog = NULL;
			}
		}

		if( sFd.secondFd != -1 )
		{
			sFd.secondFd = -1;
			if( sFd.secondLog != NULL )
			{
				fclose( sFd.secondLog );
				sFd.secondLog = NULL;
			}
		}

		Node *save = socketTable;
		int counter = 0;

		while( 1 )
		{
			if( NULL == save->next )
			{
				if( write( save->clientFd, "<serverExit>STOP</serverExit>", 100 ) < 0 )	
				{
					if( 0 != counter )
					{
						perror( "write server stop infor error!" );
					}
				}

				if( -1 != save->clientFd )
				{
					close( save->clientFd );
				}
				break;
			}
		
			if( write( save->clientFd, "<serverExit>STOP</serverExit>", 100 ) < 0 )	
			{
				if( 0 != counter )
				{
					perror( "write server stop infor error!" );
				}
			}

			if( -1 != save->clientFd )
			{
				close( save->clientFd );
			}

			save = save->next;
			counter++;
		}

		close( serverFd );

		if( socketTable != NULL )
		{
			destroyTable( socketTable );
		}

		printf( "\nSignal Clean Succ\n" );
		exit( 1 );
	}
}


int main( int argc, char *argv[] )
{
	if( signal( SIGINT, myhandler ) == SIG_ERR )
	{
		perror( "signal sigint error!" );
		return -1;
	}

	if( signal( SIGQUIT, myhandler ) == SIG_ERR )
	{
		perror( "signal sigquit error!" );
		return -1;
	}

	/*提醒用户输入端口*/
	if( 2 != argc )
	{
		fprintf( stderr, "Usage:<Port>\n" );
		return -1;
	}

	memset( &sFd, 0, sizeof( sFd ) );


	/*客户端套接字*/
	int clientFd = -1;

	/*服务端地址*/
	struct sockaddr_in serverAddr;

	/*客户端地址*/
	struct sockaddr_in clientAddr;

	/*客户端地址长度*/ 
	int clientAddrLen = sizeof( clientAddr );

	/*客户端地址的字符串形式*/
	char clientIp[ 17 ] = { '\0' };

	/*线程标识符*/
	pthread_t th[ 10 ] = { -1 };

	/*当前线程个数*/
	int thNum = 0;

	sFd.firstFd = -1;
	sFd.secondFd = -1;
	sFd.firstLog = NULL;
	sFd.secondLog = NULL;


	/*客户端套接字管理链表*/
	if( ( socketTable = createTable() ) == NULL )
	{
		perror( "createTable error!" );
		return -1;
	}


	/*初始化服务端地址*/
	memset( &serverAddr, 0, sizeof( serverAddr ) );
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons( atoi( argv[ 1 ] ) );
	inet_pton( AF_INET, "192.168.206.133", &( serverAddr.sin_addr.s_addr ) );


	/*设置线程属性为分离属性*/
	pthread_attr_t attr;
	pthread_attr_init( &attr );
	pthread_attr_setdetachstate( &attr, PTHREAD_CREATE_DETACHED );


	/*1.创建套接字*/
	if( ( serverFd = socket( AF_INET, SOCK_STREAM, 0 ) ) < 0 )
	{
		perror( "socket error!" );
		return -1;
	}

	/*2.绑定套接字*/
	if( bind( serverFd, ( struct sockaddr* )&serverAddr, sizeof( serverAddr ) ) < 0 )
	{
		perror( "bind error!" );
		return -1;
	}

	/*3.监听*/
	if( listen( serverFd, 10 ) < 0 )
	{
		perror( "listen error!" );
		return -1;
	}

	/*开始等待客户的连接*/
	printf( "Server start accept......\n" );


	/*一直等待客户的链接*/
	while( 1 )
	{
		/*初始化工作*/
		memset( &clientAddr, 0, sizeof( clientAddr ) );
		memset( clientIp, 0, sizeof( clientIp ) );

		/*4.接收客户端*/
		if( ( clientFd = accept( serverFd, ( struct sockaddr* )&clientAddr, \
						&clientAddrLen ) ) < 0 )
		{
			printf( "clientFd:%d\n", clientFd );
			perror( "accept error!" );
			return -1;
		}


		/*将连接成功的消息发送给客户端*/
		if( write( clientFd, "<connectServer>SUCC</connectServer>", 50 ) < 0 )
		{
			perror( "write connect information error!" );
			return -1;
		}
			
		
		/*保存用户的IP地址*/
		inet_ntop( AF_INET, &( clientAddr.sin_addr.s_addr), clientIp, sizeof( clientIp ) );


		/*将客户端加入到套接字管理列表中*/
		if( addClient( socketTable, clientFd, clientIp ) < 0 )
		{
			perror( "addCient error!" );
			return -1;
		}

			
		/*创建线程*/
		if( pthread_create( &( th[ thNum++ ] ), &attr, pthread_handler, \
						  ( void* )clientFd ) != 0 )
		{
			perror( "pthread_create error!" );
			return -1;
		}
	}

	return 0;
}



/*线程处理函数的实现*/
void *pthread_handler( void *argv )
{

	/*用来标记是否为接收者*/
	int		isAccepter = -1;
	
	/*接收用户信息的缓冲区*/
	char	recvBuf[ 4096 ] = { '\0' };			

	/*给用户发送消息的缓冲区*/
	char	sendBuf[ 4096 ] = { '\0' };

	/*用户套接字描述符*/
	int		myFd = ( int )argv;	
	
	/*聊天对象的IP地址*/
	char	destIp[ 17 ] = { '\0' };			

	/*聊天对象的套接字描述符*/
	int		destFd = -1;
	
	/*线程开始工作*/
	while( 1 )
	{
		memset( recvBuf, '\0', sizeof( recvBuf ) );
		memset( sendBuf, '\0', sizeof( sendBuf ) );
		
		/*读取用户消息*/
		if( read( myFd, recvBuf, 4096 ) < 0 )
		{
			perror( "read client error!" );
			continue;
		}


		printf( "%s\n", recvBuf );


		/*如果收到的是刷新在线好友请求*/
		if( 0 == strcmp( recvBuf, "<reloadCmd>reload</reloadCmd>" ) )
		{
			assert( socketTable != NULL );

			char myIp[ 20 ] = { 0 };
			strcpy( myIp, getClientIp( socketTable, myFd ) );

			/*封装信息，用^特殊标志分割*/
			strcpy( sendBuf, "<reloadIp>" );
			strcat( sendBuf, myIp );
			strcat( sendBuf, "^" );
			Node *save = socketTable->next;	
			while( save->next != NULL )
			{
				/*如果是自己的IP则不进行封装*/
				if( 0 == strcmp( save->clientIp, myIp ) )
				{
					save = save->next;
					continue;
				}

				strcat( sendBuf, save->clientIp );				
				strcat( sendBuf, "^" );
				save = save->next;
			}

			/*对链表尾节点的处理*/
			if( 0 != strcmp( save->clientIp, myIp ) )
			{
				strcat( sendBuf, save->clientIp );
				strcat( sendBuf, "^" );
			}

			/*将信息写给客户端*/
			if( write( myFd, sendBuf, sizeof( sendBuf ) ) < 0 ) {
				perror( "write reload information error!" );
				continue;
			}

			printf( "sendMsg:%s\n", sendBuf );
		}


		/*如果收到的是连接聊天的对象的用户请求*/
		if( 0 == strncmp( recvBuf, "<clientIp>", 10 ) )
		{
			sender = myFd;
			isAccepter = 0;

			/*解析出聊天对象的IP地址*/
			char myIp[ 20 ] = { 0 };
			strcpy( myIp, getClientIp( socketTable, myFd ) );
			strtok( recvBuf, ">" );	
			strcpy( destIp, strtok( NULL, "</" ) );


			/*通过聊天对象的IP地址来获取到聊天对象的套接字描述符*/
			if( ( destFd = getClient( socketTable, destIp ) ) < 0 )
			{
				if( write( myFd, "<connectClient>FAIL</connectClient>", 100 ) < 0 ) 		
				{
					perror( "write client getClient false informatiion error!" );
				}
				printf( "FAIL\n" );
				continue;
			}
			else if( 0 == strcmp( myIp, destIp ) )//如果连接的是用户自己
			{
				if( write( myFd, "<connectClient>WARNING</connectClient>", 100 ) < 0 ) 		
				{
					perror( "write client getClient false informatiion error!" );
				}

				printf( "WARNING\n");
				continue;
			}
			else
			{
				if( write( myFd, "<connectClient>SUCC</connectClient>", 100 ) < 0 )
				{
					perror( "write client getClient true information error!" );
				}

				printf( "%s\n", "SUCC" );
			}

			/*设置正在通讯的两个用户*/
			sFd.firstFd = myFd;
			sFd.secondFd = destFd;

			if( NULL == (sFd.firstLog = creatFile(getClientIp( socketTable, sFd.firstFd ))))
			{
				perror( "creat firstLog error!" );		
				continue;
			}

			if( NULL == (sFd.secondLog = creatFile(getClientIp(socketTable,sFd.secondFd))))
			{
				perror( "creat secondLog error!" );
				continue;
			}

			isAccepter = 0;
		}
		

		/*如果收到的聊天信息*/
		if( 0 == strncmp( recvBuf, "<toClientMessage>", 17 ) )
		{
			if( 0 != isAccepter )
			{
				sFd.firstFd = sender;		
				sFd.secondFd = myFd;
				destFd = sFd.firstFd;
			}

			/*获取当前时间*/
			char curTime[ 70 ] = { 0 };
			strcpy( curTime, getCurTime() );

			char dstIp[ 20 ] = { 0 };
			if( myFd == sFd.firstFd )	
			{
				strcpy( dstIp, getClientIp( socketTable, sFd.firstFd ) );
			}
			else
			{
				strcpy( dstIp, getClientIp( socketTable, sFd.secondFd ) );
			}


			/*开始设置消息的头标识*/
			char msgToOther[ 4096 ] = "<Msg>";
			strcat( msgToOther, dstIp );
			strcat( msgToOther, "   " );
			strcat( msgToOther, curTime );
			strcat( msgToOther, "\n" );
			char msgToMe[ 4096 ] = "<Msg>Me   ";
			strcat( msgToMe, curTime );
			strcat( msgToMe, "\n" );
			char msg[ 4096 ] = { '\0' }; 

			/*解析接受到的聊天信息*/
			strtok( recvBuf, ">" );
			strcpy( msg, strtok( NULL, "</" ) );

			/*封装聊天信息*/
			strcat( msgToOther, msg );
			strcat( msgToMe, msg );


			/*将不同的消息写给对应的聊天用户*/
			if( myFd == sFd.firstFd )
			{
				if( write( sFd.secondFd, msgToOther, 4096 ) < 0 )
				{
					perror( "1.write msg to client error!" );
					continue;	
				}

				if( write( sFd.firstFd, msgToMe, 4096 ) < 0 )
				{
					perror( "2.write msg to self error!" );
					continue;
				}

				/*将聊天消息保存到日志文件中*/
				saveMsg(sFd.firstLog,getClientIp(socketTable,sFd.secondFd),curTime,msgToMe,TO);
				saveMsg(sFd.secondLog,getClientIp(socketTable,sFd.firstFd),curTime,msgToMe,FROM);
			}


			if( myFd == sFd.secondFd )
			{
				if( write( sFd.firstFd, msgToOther, 4096 ) < 0 )
				{
					perror( "3.write msg to client error!" );
					continue;	
				}

				if( write( sFd.secondFd, msgToMe, 4096 ) < 0  )
				{
					perror( "4.write msg to self error!" );
					continue;
				}

				/*将消息保存到日志中*/
				saveMsg(sFd.firstLog,getClientIp(socketTable,sFd.secondFd),curTime,msgToMe,FROM);
				saveMsg(sFd.secondLog,getClientIp(socketTable,sFd.firstFd),curTime,msgToMe,TO );
			}
		}



		/*如果收到的是用户断开聊天的请求*/
		if( 0 == strcmp( recvBuf, "<offClient>OFF</offClient>" ) )
		{
			/*
			if( -1 == isAccepter )
			{
				sFd.firstFd = sender;
				sFd.secondFd = myFd;
			}
			*/


			/*断开成功的消息*/
			char succMsg[ 20 ] = "<off>SUCC</off>";

			/*写给通讯的两个用户*/
			if( myFd == sFd.firstFd )
			{
				//if( write( myFd, succMsg, sizeof( succMsg ) ) < 0 )
				if( write( sFd.firstFd, succMsg, sizeof( succMsg ) ) < 0 )
				{
					perror( "1.write client off information error!" );
					continue;
				}

				//if( write( destFd, succMsg, sizeof( succMsg ) ) < 0 )
				if( write( sFd.secondFd, succMsg, sizeof( succMsg ) ) < 0 )
				{
					perror( "2.write client off information error!" );
					continue;
				}

				/*设置sFd中的通讯状态*/
				sFd.secondFd = -1;
				fclose( sFd.secondLog );
			}

			if( myFd == sFd.secondFd )
			{
				if( write( sFd.firstFd, succMsg, sizeof( succMsg ) ) < 0 )
				{
					perror( "3.write client off information error!" );
					continue;
				}

				if( write( sFd.secondFd, succMsg, sizeof( succMsg ) ) < 0 )
				{
					perror( "4.write client off information error!" );
					continue;
				}

				/*设置sFd中的通讯状态*/
				sFd.firstFd = -1;
				fclose( sFd.firstLog );
			}

			/*清除聊天对象*/
			destFd = -1;
		}


		if( 0 == strcmp( recvBuf, "<record>chat msg</record>" ) )
		{
			printf( "!!!!!!!!!!!!!!!!!\n" );
			if( myFd == sFd.firstFd )
			{
				printf( "111111111111111\n" );
				fclose( sFd.firstLog );
			}
			else
			{
				printf( "222222222222222222222\n" );
				fclose( sFd.secondLog );
			}

			FILE *myLog = NULL; 
			
			if( NULL == ( myLog = fopen( getClientIp( socketTable, myFd ), "r" ) ) )
			{
				perror( "fopen myLog error!" );	
				continue;
			}

			printf( "33333333333333333333\n" );

			char buf[ 1024 ] = { 0 };
			char buffer[ 1024 ] = "<recording>";

			while( !feof( myLog ) )
			{
				sleep( 1 );
				memset( buf, 0, 1024 );
				memset( buffer, 0, 1024 );
				strcpy( buffer, "<recording>" );

				fgets( buf, 1024, myLog );								

				printf( "------gets:%s\n", buf );

				strcat( buffer, buf );
				if( write( myFd, buffer, 1024 ) < 0 )
				{
					perror( "write myLog error!" );
					break;
				}
				printf( "recored-----:%s\n", buffer );
			}

			sleep( 1 );
			if( write( myFd, "<recorded>", 20 ) < 0 )
			{
				perror( "write myLog end error!" );	
				continue;
			}

			printf( "write record finish!\n" );
		}


		/*如果收到的是退出系统的用户请求*/
		if( 0 == strcmp( recvBuf, "<exit>login out</exit>" ) )
		{

			if( myFd == sFd.firstFd )
			{
				printf( "-------friend exit\n" );
				if( write( sFd.secondFd, "<friend>exit</friend>", 30 ) < 0 )
				{
					perror( "write <friend> exit infor error!" );
					continue;
				}
			}

			if( myFd == sFd.secondFd )
			{
				printf( "-------friend exit\n" );
				if( write( sFd.firstFd, "<friend>exit</friend>", 30 ) < 0 )
				{
					perror( "write <friend> exit infor error!" );
					continue;
				}
			}
				
			int temp = myFd;

			/*从链表中删除用户*/
			if( delClient( socketTable, myFd ) < 0 )			
			{
				perror( "del client fd error!" );					
				continue;
			}

			/*
			if( NULL != sFd.firstLog)
			{
				fclose( sFd.firstLog );
				sFd.firstLog = NULL;
			}

			if( NULL != sFd.secondLog )
			{
				fclose( sFd.secondLog );
				sFd.secondLog = NULL;
			}
			*/


			/*关闭用户套接字*/
			close( temp );


			/*关闭日志文件*/
			sFd.firstFd = -1;
			sFd.secondFd = -1;

			break;
		}

	}
}

