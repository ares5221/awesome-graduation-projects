#ifndef		__SERVER_H__
#define		__SERVER_H__

/*标识聊天消息的方向*/
#define		TO		1
#define		FROM	2

#include	<stdio.h>
#include	<string.h>
#include	<stdlib.h>
#include	<assert.h>
#include	<ctype.h>
#include	<fcntl.h>
#include	<unistd.h>
#include	<signal.h>
#include	<time.h>
#include	<pthread.h>
#include	<sys/socket.h>
#include	<netinet/in.h>
#include	<arpa/inet.h>


/*******************************
定义一个用来保存用户信息的结构体
clientFd : 用户套接字描述符
clientIp : 用户Ip地址
*******************************/
typedef struct _Node
{
	int				clientFd;
	char			clientIp[ 17 ];
	struct _Node	*next;
}Node;


/************************************
定义一个保存正在通讯的两个用户的结构体
firstFd  : 用户1
secondFd : 用户2
*************************************/
typedef struct _SaveFd
{
	int		firstFd;
	int		secondFd;
	FILE	*firstLog;
	FILE	*secondLog;
}SaveFd;


/*通过链表来保存用户信息*/
Node*	createTable(); 

/*将新接受的客户添加到链表中*/
int		addClient( Node *head, int fd, char *ip );

/*删除指定用户*/
int		delClient( Node *head, int fd );

/*获取指定用户套接字*/
int		getClient( Node *head, char *ip );

/*获取指定用户的IP地址*/
char	*getClientIp( Node *head, int fd );

/*销毁链表*/
void	destroyTable( Node *head );

/*获取系统的当前时间*/
char    *getCurTime();

/*线程处理函数*/
void	*pthread_handler( void *argv );

/*创建日志文件*/
FILE	*creatFile( char *ip );

/*保存消息记录*/
void	saveMsg( FILE *file, char *otherIp, char *time, char *msg, int flag );


#endif
